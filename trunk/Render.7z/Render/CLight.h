#pragma once
#include "RenderWare.h"
#include <d3d9.h>
#include <d3dx9.h>

class CLight
{
public:
	static RwV3d pos,dir;
	static float radius, red, green, blue;
	static BYTE type; /*
						0  Omni/Point   Using position and radius.
						1  Directional  Using position, radius and direction.
						2  Shadow       It's black!
						4  Global       Using only position.
						*/
	static BYTE subType; /*
								0 Default.
								1 Car headlights.
								2 Car backlights.
								3 Car LED 
								*/
	static BYTE fogType, generateShadows;
};