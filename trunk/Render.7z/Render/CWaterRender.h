#pragma once

class CWaterRender
{
public:

}