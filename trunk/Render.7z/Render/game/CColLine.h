/*
    SA::Render source file
    CColLine structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CColLine
{
    RwV3D m_vStart;
    int m_fStartSize;
    RwV3D m_vEnd;
    int m_fEndSize;
};
#pragma pack(pop)