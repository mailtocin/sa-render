/*
    SA::Render source file
    CPedIntelligence__struct_18C structure
*/
#pragma once
#include "CAiTimer.h"
#include "CPedIntelligence__struct_3.h"

#pragma pack(push, 1)
struct CPedIntelligence__struct_18C
{
    int field_0;
    CAiTimer field_4;
    CAiTimer field_10;
    CPedIntelligence__struct_3 field_1C;
    CAiTimer field_AC;
    char field_B8;
    char field_B9;
    char field_BA;
    char gap_bb[1];
    CAiTimer field_BC;
    CAiTimer field_C8;
};
#pragma pack(pop)