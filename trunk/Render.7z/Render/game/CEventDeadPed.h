/*
    SA::Render source file
    CEventDeadPed structure
*/
#pragma once
#include "CPed.h"

#pragma pack(push, 1)
struct CEventDeadPed
{
    unsigned int vmt;
    unsigned int dword4;
    unsigned char byte8;
    unsigned char f9[3];
    unsigned char byteC;
    unsigned char fD[1];
    unsigned short possiblyTime;
    unsigned short word10;
    unsigned char f12[2];
    CPed *m_pPed;
    unsigned char byte18;
    unsigned char f19[3];
    unsigned int dword1C;
};
#pragma pack(pop)