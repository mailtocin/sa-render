/*
    SA::Render source file
    RwObject structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwObject
{
    char type;
    char subType;
    char flags;
    char privateFlags;
    RwFrame *parent;
};
#pragma pack(pop)