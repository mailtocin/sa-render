/*
    SA::Render source file
    CTaskComplexWander structure
*/
#pragma once
#include "CTaskComplex.h"

#pragma pack(push, 1)
struct CTaskComplexWander
{
    CTaskComplex __parent;
    int field_C;
    char field_10;
    char gap_11[3];
    int field_14;
    short field_18;
    char gap_1a[2];
    short field_1C;
    char gap_1e[2];
    int field_20;
    char field_24;
    char field_25[3];
};
#pragma pack(pop)