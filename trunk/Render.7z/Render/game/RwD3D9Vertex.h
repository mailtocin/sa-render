/*
    SA::Render source file
    RwD3D9Vertex structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwD3D9Vertex
{
    RwV3D pos;
    float rhw;
    int color;
    RwTexCoords texCoors;
};
#pragma pack(pop)