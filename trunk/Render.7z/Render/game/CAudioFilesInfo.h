/*
    SA::Render source file
    CAudioFilesInfo structure
*/
#pragma once
#include "CBankSlotInfo.h"
#include "CBankLkup.h"
#include "CBankSlotBankAssignment.h"

#pragma pack(push, 1)
struct CAudioFilesInfo
{
    CBankSlotInfo *m_pBankSlotsInfos;
    CBankLkup *m_pBankLkups;
    void *m_pPakFileName;
    short m_nNumBankSlotsInfos;
    short m_nNumBankLkup;
    short m_nNumPakFiles;
    short __pad1;
    unsigned char m_bAudioFileInfoInitialized;
    char __pad2[3];
    int m_dwBankSlotsSize;
    int m_pBankSlots;
    int *m_pPakFilesStreamIndex;
    CBankSlotBankAssignment m_aBankSlotBankAssignment[50];
    short field_664;
    short field_666;
    short m_nNumBanksAssigned;
    unsigned short m_nStreamNum;
    short field_66C[60];
};
#pragma pack(pop)