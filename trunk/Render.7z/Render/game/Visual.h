/*
    SA::Render source file
    Visual enumeration
*/
#pragma once

enum Visual Fx Quality
{
    FX_LOW = 0x0,
    FX_MEDIUM = 0x1,
    FX_HIGH = 0x2,
    FX_VERY_HIGH = 0x3,
};