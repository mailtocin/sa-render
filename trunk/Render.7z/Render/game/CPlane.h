/*
    SA::Render source file
    CPlane structure
*/
#pragma once
#include "CAutomobileBase.h"

#pragma pack(push, 1)
struct CPlane
{
    int _vmt;
    CAutomobileBase automobile;
    char field_988[32];
    int field_9A8;
    char field_9AC[4];
    int field_9B0;
    int field_9B4;
    int field_9B8;
    char field_9BC[16];
    int landingGearStatus;
    char field_9D0[24];
    int pJettrusParticles[4];
    int field_9F8;
    int field_9FC;
    int field_A00;
};
#pragma pack(pop)