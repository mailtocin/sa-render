/*
    SA::Render source file
    struc_C1DF30 structure
*/
#pragma once
#include "struc_C1DF30_internal.h"

#pragma pack(push, 1)
struct struc_C1DF30
{
    struc_C1DF30_internal field_0[128];
    int field_1A00[3];
    int field_1A0C[3];
    int field_1A18;
};
#pragma pack(pop)