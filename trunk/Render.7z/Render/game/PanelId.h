/*
    SA::Render source file
    PanelId enumeration
*/
#pragma once

enum PanelId
{
    PANEL_WING_LF = 0x0,
    PANEL_WING_RF = 0x1,
    PANEL_WINDSCREEN = 0x4,
    PANEL_BUMP_FRONT = 0x5,
    PANEL_BUMP_REAR = 0x6,
};