/*
    SA::Render source file
    CStaticShadow structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CStaticShadow
{
    int id;
    int field_4;
    int timeCreated;
    RwV3D pos;
    int X1;
    int Y1;
    int X2;
    int Y2;
    int zDistance;
    int scale;
    int texture;
    short intensity;
    char blendType;
    char red;
    char green;
    char blue;
    char field_3A;
    char field_3B;
    char field_3C;
    char field_3D;
    short field_3E;
};
#pragma pack(pop)