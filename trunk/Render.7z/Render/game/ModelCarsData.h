/*
    SA::Render source file
    ModelCarsData structure
*/
#pragma once
#include "CVehicleModelInfo.h"

#pragma pack(push, 1)
struct ModelCarsData
{
    int count;
    CVehicleModelInfo objects[212];
};
#pragma pack(pop)