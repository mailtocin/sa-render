/*
    SA::Render source file
    CFxInfoForceDataInternal structure
*/
#pragma once

#pragma pack(push, 1)
struct CFxInfoForceDataInternal
{
    unsigned int _vmt;
    unsigned char m_cLooped;
    char m_cNumKeys;
    char m_cNumInterpDatas;
    char field_7;
    short *m_pTimeKeys;
    short **m_pValKeysPtrList;
};
#pragma pack(pop)