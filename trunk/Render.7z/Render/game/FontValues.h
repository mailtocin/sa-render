/*
    SA::Render source file
    FontValues structure
*/
#pragma once

#pragma pack(push, 1)
struct FontValues
{
    char proportionalValues[208];
    char replacementSpaceChar;
    char unproportionalValue;
};
#pragma pack(pop)