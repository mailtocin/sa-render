/*
    SA::Render source file
    CProjectileInfo structure
*/
#pragma once
#include "CEntity.h"
#include "CVector.h"
#include "CParticle.h"

#pragma pack(push, 1)
struct CProjectileInfo
{
    int m_dwWeaponType;
    CEntity *m_pLauncher;
    CEntity *m_pTarget;
    int m_dwTimeToDestroy;
    char m_bState;
    char _pad[3];
    CVector m_vLastPos;
    CParticle *m_pParticle;
};
#pragma pack(pop)