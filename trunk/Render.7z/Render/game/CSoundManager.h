/*
    SA::Render source file
    CSoundManager structure
*/
#pragma once
#include "CSound.h"

#pragma pack(push, 1)
struct CSoundManager
{
    unsigned short m_nCountSounds;
    unsigned short field_2;
    CSound m_aSounds[300];
    unsigned short *field_87F4;
    unsigned short *field_87F8;
    unsigned short *field_87FC;
    short field_8800[300];
    short field_8A58[300];
    unsigned int m_dwTimeInitialized;
    unsigned char field_8CB4;
    unsigned char field_8CB5;
    unsigned char field_8CB6[2];
    unsigned int field_8CB8;
};
#pragma pack(pop)