/*
    SA::Render source file
    RwFrame structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwFrame
{
    RwObject object;
    RwLLLink inDirtyListLink;
    RwMatrix modelling;
    RwMatrix ltm;
    RwLinkList objectList;
    RwFrame *child;
    RwFrame *next;
    RwFrame *root;
    char pluginData[8];
    char nodeName[16];
};
#pragma pack(pop)