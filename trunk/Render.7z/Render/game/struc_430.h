/*
    SA::Render source file
    struc_430 structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct struc_430
{
    RwV3D pos;
    RwV3D objNormal;
    int color;
    float u;
    float v;
};
#pragma pack(pop)