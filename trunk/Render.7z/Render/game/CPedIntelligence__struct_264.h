/*
    SA::Render source file
    CPedIntelligence__struct_264 structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CPedIntelligence__struct_264
{
    RwV3D field_0;
    short field_C;
    short field_E;
};
#pragma pack(pop)