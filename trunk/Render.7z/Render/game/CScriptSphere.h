/*
    SA::Render source file
    CScriptSphere structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CScriptSphere
{
    char bUsed;
    char field_1;
    short wUniqueID;
    int field_4;
    RwV3D vCoords;
    int fRadius;
};
#pragma pack(pop)