/*
    SA::Render source file
    CTaskSimpleDriveCar_obj1 structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CTaskSimpleDriveCar_obj1
{
    RwV3D field_0;
    int field_C;
    int m_nTime;
    int field_14;
    int field_18;
};
#pragma pack(pop)