/*
    SA::Render source file
    CText__Tabl structure
*/
#pragma once
#include "TablEntry.h"

#pragma pack(push, 1)
struct CText__Tabl
{
    TablEntry data[200];
    short size;
    short __pad;
};
#pragma pack(pop)