/*
    SA::Render source file
    CPedModelInfo structure
*/
#pragma once
#include "CClumpModelInfo.h"
#include "CColModel.h"

#pragma pack(push, 1)
struct CPedModelInfo
{
    CClumpModelInfo clump;
    int m_nAnimType;
    int m_nPedType;
    int m_nStatType;
    short m_nCarsCanDriveMask;
    short m_nPedFlags;
    CColModel *m_pHitColModel;
    char m_nRadio1;
    char m_nRadio2;
    char pedModel;
    char field_3B;
    short m_nVoiceType;
    short m_nVoice1;
    short m_nVoice2;
    short m_nVoice3;
};
#pragma pack(pop)