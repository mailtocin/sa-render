/*
    SA::Render source file
    CDirectory structure
*/
#pragma once

#pragma pack(push, 1)
struct CDirectory
{
    int m_pEntries;
    int m_dwSize;
    int m_dwCount;
    char m_bDynamicAllocated;
    char __pad[3];
};
#pragma pack(pop)