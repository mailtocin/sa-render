/*
    SA::Render source file
    CAudioFile structure
*/
#pragma once

#pragma pack(push, 1)
struct CAudioFile
{
    int __vmt__;
    int stream;
};
#pragma pack(pop)