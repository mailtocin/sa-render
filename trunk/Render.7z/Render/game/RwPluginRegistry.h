/*
    SA::Render source file
    RwPluginRegistry structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwPluginRegistry
{
    int sizeOfStruct;
    int origSizeOfStruct;
    int maxSizeOfStruct;
    int staticAlloc;
    int firstRegEntry;
    RwPluginRegistry **lastRegEntry;
};
#pragma pack(pop)