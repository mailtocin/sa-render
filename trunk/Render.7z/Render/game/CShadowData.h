/*
    SA::Render source file
    CShadowData structure
*/
#pragma once
#include "CPhysical.h"
#include "CShadowImage.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct CShadowData
{
    CPhysical *physical;
    char existFlag;
    char ucIntensity;
    short _pad1;
    CShadowImage image;
    char bIsBlurred;
    char _pad2[3];
    CShadowImage imageBlurred;
    int nBlurPasses;
    char bDrawMoreBlur;
    char _pad3[3];
    int objectType;
    int light;
    RwSphere boundingSphere;
    RwSphere baseSphere;
};
#pragma pack(pop)