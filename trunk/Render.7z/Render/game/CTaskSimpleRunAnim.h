/*
    SA::Render source file
    CTaskSimpleRunAnim structure
*/
#pragma once
#include "CTaskSimpleAnim.h"

#pragma pack(push, 1)
struct CTaskSimpleRunAnim
{
    CTaskSimpleAnim __parent;
    int field_10;
    int m_dwAnimId;
    int field_18;
    short m_eTaskId;
    short __pad;
};
#pragma pack(pop)