/*
    SA::Render source file
    AtomicRenderer structure
*/
#pragma once
#include "CEntity.h"

#pragma pack(push, 1)
struct AtomicRenderer
{
    CEntity *entity;
    void *renderCB;
    float distance;
};
#pragma pack(pop)