/*
    SA::Render source file
    CRect structure
*/
#pragma once

#pragma pack(push, 1)
struct CRect
{
    int l;
    int t;
    int r;
    int b;
};
#pragma pack(pop)