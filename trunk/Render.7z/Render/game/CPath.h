/*
    SA::Render source file
    CPath structure
*/
#pragma once

#pragma pack(push, 1)
struct CPath
{
    int number;
    int pData;
    int field_8;
    char usageCount;
    char __pad[3];
};
#pragma pack(pop)