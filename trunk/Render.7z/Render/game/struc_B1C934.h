/*
    SA::Render source file
    struc_B1C934 structure
*/
#pragma once
#include "obj_85BC70.h"

#pragma pack(push, 1)
struct struc_B1C934
{
    int count;
    obj_85BC70 objects;
};
#pragma pack(pop)