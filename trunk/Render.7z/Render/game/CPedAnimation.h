/*
    SA::Render source file
    CPedAnimation structure
*/
#pragma once

#pragma pack(push, 1)
struct CPedAnimation
{
    int ifpFile;
    int field_4;
    int field_8;
    int field_C;
    int field_10;
};
#pragma pack(pop)