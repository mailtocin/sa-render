/*
    SA::Render source file
    CString structure
*/
#pragma once

#pragma pack(push, 1)
struct CString
{
    char field_0[8];
};
#pragma pack(pop)