/*
    SA::Render source file
    CDecisionMakerMgr structure
*/
#pragma once
#include "CPedEvent_DM_List.h"
#include "CPedEventList.h"

#pragma pack(push, 1)
struct CDecisionMakerMgr
{
    int field_0;
    CPedEvent_DM_List decisionMakers[20];
    CPedEventList pedEventList;
    CPedEvent_DM_List field_C1B4;
    CPedEvent_DM_List field_CB50;
    CPedEvent_DM_List field_D4EC;
    CPedEvent_DM_List field_DE88;
    CPedEvent_DM_List field_E824;
};
#pragma pack(pop)