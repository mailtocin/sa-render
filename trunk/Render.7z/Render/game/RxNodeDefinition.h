/*
    SA::Render source file
    RxNodeDefinition structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RxNodeDefinition
{
    char *name;
    RxNodeMethods nodeMethods;
    RxIoSpec io;
    int pipelineNodePrivateDataSize;
    int editable;
    int InputPipesCnt;
};
#pragma pack(pop)