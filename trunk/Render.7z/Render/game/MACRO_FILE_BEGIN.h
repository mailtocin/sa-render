/*
    SA::Render source file
    MACRO_FILE_BEGIN enumeration
*/
#pragma once

enum MACRO_FILE_BEGIN
{
    FILE_BEGIN = 0,
    FILE_CURRENT = 1,
    FILE_END = 2,
    TIME_ZONE_ID_INVALID = -1,
};