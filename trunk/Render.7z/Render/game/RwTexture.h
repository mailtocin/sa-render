/*
    SA::Render source file
    RwTexture structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwTexture
{
    RwRaster *raster;
    RwTexDictionary *dict;
    RwLLLink lInDictionary;
    char name[32];
    char mask[32];
    char filterAddressing;
    char _f51;
    char field_52;
    char field_53;
    int m_bCounter;
};
#pragma pack(pop)