/*
    SA::Render source file
    CPlaceName structure
*/
#pragma once
#include "CZone.h"

#pragma pack(push, 1)
struct CPlaceName
{
    CZone *m_pZone;
    unsigned short m_wAdditionalTimer;
    char _padding[2];
};
#pragma pack(pop)