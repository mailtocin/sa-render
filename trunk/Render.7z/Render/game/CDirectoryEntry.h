/*
    SA::Render source file
    CDirectoryEntry structure
*/
#pragma once

#pragma pack(push, 1)
struct CDirectoryEntry
{
    int field_0;
    int field_4;
    char field_8[24];
};
#pragma pack(pop)