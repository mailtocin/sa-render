/*
    SA::Render source file
    CTaskSimplePause structure
*/
#pragma once
#include "CTask.h"
#include "CAiTimer.h"

#pragma pack(push, 1)
struct CTaskSimplePause
{
    CTask __parent;
    CAiTimer m_timer;
    int m_nTime;
};
#pragma pack(pop)