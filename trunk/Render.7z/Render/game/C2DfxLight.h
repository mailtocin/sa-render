/*
    SA::Render source file
    C2dfxLight structure
*/
#pragma once
#include "C2dfx.h"
#include "RenderWare.h"
#include "union.h"

#pragma pack(push, 1)
struct C2dfxLight
{
    C2dfx base;
    RwRGBA color;
    float coronaFarClip;
    float pointlightRange;
    float coronaSize;
    float shadowSize;
    union flagsInfo;
    char coronaFlashType;
    char coronaEnableReflection;
    char coronaFlareType;
    char shadowColorMultiplier;
    char shadowZDistance;
    char offsetX;
    char offsetY;
    char offsetZ;
    char __pad[2];
    RwTexture *coronaTex;
    RwTexture *shadowTex;
    int field_38;
    int field_3C;
};
#pragma pack(pop)