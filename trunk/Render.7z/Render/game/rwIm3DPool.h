/*
    SA::Render source file
    rwIm3DPool structure
*/
#pragma once
#include "_rwIm3DPoolStash.h"

#pragma pack(push, 1)
struct rwIm3DPool
{
    short numElements;
    short pad;
    void *elements;
    int stride;
    _rwIm3DPoolStash stash;
};
#pragma pack(pop)