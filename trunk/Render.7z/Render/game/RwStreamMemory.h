/*
    SA::Render source file
    RwStreamMemory structure
*/
#pragma once

#pragma pack(push, 1)
struct RwStreamMemory
{
    int type;
    int accessType;
    int position;
    int memPosition;
    int memSize;
    int memPtr;
    int field_18;
    int field_1C;
    int rwOwned;
};
#pragma pack(pop)