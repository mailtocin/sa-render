/*
    SA::Render source file
    IDirectInput8A structure
*/
#pragma once

#pragma pack(push, 1)
struct IDirectInput8A
{
    void *lpVtbl;
};
#pragma pack(pop)