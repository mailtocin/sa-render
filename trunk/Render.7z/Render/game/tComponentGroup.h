/*
    SA::Render source file
    tComponentGroup enumeration
*/
#pragma once

enum tComponentGroup
{
    GROUP_PANEL = 0x0,
    GROUP_WHEEL = 0x1,
    GROUP_DOOR = 0x2,
    GROUP_BONNET = 0x3,
    GROUP_BOOT = 0x4,
    GROUP_LIGHT = 0x5,
    GROUP_NA = 0x6,
};