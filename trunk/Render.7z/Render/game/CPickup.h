/*
    SA::Render source file
    CPickup structure
*/
#pragma once
#include "CObject.h"
#include "CCompressedVector.h"

#pragma pack(push, 1)
struct CPickup
{
    float field_0;
    CObject *m_pObject;
    int m_dwAmmo;
    int m_dwRegenerationTime;
    CCompressedVector m_vPos;
    short field_16;
    short m_wModelId;
    short m_wGeneration;
    char m_cPickupType;
    char m_cFlags;
    char field_1E;
    char field_1F;
};
#pragma pack(pop)