/*
    SA::Render source file
    CAudioFileWav structure
*/
#pragma once
#include "CAudioFile.h"

#pragma pack(push, 1)
struct CAudioFileWav
{
    CAudioFile __parent;
    char initialized;
    char __pad[3];
    int stream_;
    char headerBuf[44];
};
#pragma pack(pop)