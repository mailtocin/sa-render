/*
    SA::Render source file
    CBankLkup structure
*/
#pragma once

#pragma pack(push, 1)
struct CBankLkup
{
    char m_nPakFileNumber;
    char __pad0[3];
    int m_dwOffset;
    int m_dwLength;
};
#pragma pack(pop)