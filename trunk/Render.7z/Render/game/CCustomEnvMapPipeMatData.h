/*
    SA::Render source file
    CCustomEnvMapPipeMatData structure
*/
#pragma once

#pragma pack(push, 1)
struct CCustomEnvMapPipeMatData
{
    void *pPlgData;
    unsigned int dword4;
    unsigned int dword8;
};
#pragma pack(pop)