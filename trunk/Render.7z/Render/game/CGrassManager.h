/*
    SA::Render source file
    CGrassManager structure
*/
#pragma once
#include "CGrass.h"

#pragma pack(push, 1)
struct CGrassManager
{
    unsigned int numActive;
    CGrass structs[32];
    unsigned int type;
    void *pObjectList[4];
};
#pragma pack(pop)