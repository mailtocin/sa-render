/*
    SA::Render source file
    CReferences structure
*/
#pragma once
#include "SReference.h"

#pragma pack(push, 1)
struct CReferences
{
    SReference m_refs[3000];
    int pEmptyList;
};
#pragma pack(pop)