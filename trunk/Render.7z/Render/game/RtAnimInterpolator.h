/*
    SA::Render source file
    RtAnimInterpolator structure
*/
#pragma once
#include "RenderWare.h"
#include "bool.h"
#include "struct.h"

#pragma pack(push, 1)
struct RtAnimInterpolator
{
    RtAnimAnimation *pCurrentAnim;
    float currentTime;
    void *pNextFrame;
    void *pAnimCallBack;
    void *pAnimCallBackData;
    float animCallBackTime;
    void *pAnimLoopCallBack;
    void *pAnimLoopCallBackData;
    int maxInterpKeyFrameSize;
    int currentInterpKeyFrameSize;
    int currentAnimKeyFrameSize;
    int numNodes;
    bool isSubInterpolator;
    int offsetInParent;
    struct RtAnimInterpolator;
    void *keyFrameApplyCB;
    void *keyFrameBlendCB;
    void *keyFrameInterpolateCB;
    void *keyFrameAddCB;
};
#pragma pack(pop)