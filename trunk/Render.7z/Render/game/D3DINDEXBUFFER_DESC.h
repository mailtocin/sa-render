/*
    SA::Render source file
    D3DINDEXBUFFER_DESC structure
*/
#pragma once

#pragma pack(push, 1)
struct D3DINDEXBUFFER_DESC
{
    int Format;
    int Type;
    int Usage;
    int Pool;
    int Size;
};
#pragma pack(pop)