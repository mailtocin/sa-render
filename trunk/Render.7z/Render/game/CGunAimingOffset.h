/*
    SA::Render source file
    CGunAimingOffset structure
*/
#pragma once

#pragma pack(push, 1)
struct CGunAimingOffset
{
    float AimX;
    float AimZ;
    float DuckX;
    float DuckZ;
    short RLoadA;
    short RLoadB;
    short CrouchRLoadA;
    short CrouchRLoadB;
};
#pragma pack(pop)