/*
    SA::Render source file
    DIOBJECTDATAFORMAT structure
*/
#pragma once

#pragma pack(push, 1)
struct DIOBJECTDATAFORMAT
{
    void *pguid;
    int dwOfs;
    int dwType;
    int dwFlags;
};
#pragma pack(pop)