/*
    SA::Render source file
    RwStringFunctions structure
*/
#pragma once

#pragma pack(push, 1)
struct RwStringFunctions
{
    int (*vecSprintf)(_DWORD,;
    int vecVsprintf;
    void (__cdecl;
    int vecStrncpy;
    int (__cdecl;
    int vecStrncat;
    int vecStrrchr;
    int vecStrchr;
    int vecStrstr;
    int (__cdecl;
    int vecStrncmp;
    int vecStricmp;
    int (__cdecl;
    int vecStrupr;
    int vecStrlwr;
    int vecStrtok;
    int vecSscanf;
};
#pragma pack(pop)