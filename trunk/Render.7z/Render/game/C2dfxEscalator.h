/*
    SA::Render source file
    C2dfxEscalator structure
*/
#pragma once
#include "C2dfx.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct C2dfxEscalator
{
    C2dfx base;
    RwV3D bottom;
    RwV3D top;
    RwV3D end;
    char direction;
    char __pad[3];
};
#pragma pack(pop)