/*
    SA::Render source file
    CSurface structure
*/
#pragma once
#include "CSurfaceType.h"

#pragma pack(push, 1)
struct CSurface
{
    int surface[36];
    CSurfaceType surfType[179];
};
#pragma pack(pop)