/*
    SA::Render source file
    PsGlobalType structure
*/
#pragma once

#pragma pack(push, 1)
struct PsGlobalType
{
    int window;
    int instance;
    int fullscreen;
    int lastMousePos_X;
    int lastMousePos_Y;
    int field_14;
    int diInterface;
    int diMouse;
    int diDevice1;
    int diDevice2;
};
#pragma pack(pop)