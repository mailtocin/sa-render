/*
    SA::Render source file
    RectX2Y2 structure
*/
#pragma once

#pragma pack(push, 1)
struct RectX2Y2
{
    int x1;
    int y1;
    int x2;
    int y2;
};
#pragma pack(pop)