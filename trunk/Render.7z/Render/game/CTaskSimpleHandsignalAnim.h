/*
    SA::Render source file
    CTaskSimpleHandsignalAnim structure
*/
#pragma once
#include "CTaskSimpleAnim.h"

#pragma pack(push, 1)
struct CTaskSimpleHandsignalAnim
{
    CTaskSimpleAnim __parent;
    int field_10;
    int field_14;
    char field_18;
    char gap_19[3];
    int field_1C;
    int field_20;
};
#pragma pack(pop)