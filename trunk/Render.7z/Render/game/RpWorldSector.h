/*
    SA::Render source file
    RpWorldSector structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpWorldSector
{
    int type;
    int triangles;
    int vertices;
    int normals;
    int texCoords[8];
    RwRGBA preLitLum;
    int repEntry;
    RwLLLink collAtomicsInWorldSector;
    RwLLLink lightsInWorldSector;
    RwBBox boundingBox;
    RwBBox tightBoundingBox;
    int mesh;
    int pipeline;
    short matListWindowBase;
    short numVertices;
    short numTriangles;
    short pad;
};
#pragma pack(pop)