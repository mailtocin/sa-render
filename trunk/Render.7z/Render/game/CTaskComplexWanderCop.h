/*
    SA::Render source file
    CTaskComplexWanderCop structure
*/
#pragma once
#include "CTaskComplexWander.h"
#include "CAiTimer.h"

#pragma pack(push, 1)
struct CTaskComplexWanderCop
{
    CTaskComplexWander __parent;
    int field_28;
    CAiTimer field_2C;
    int field_38;
    int field_3C;
    int field_40;
    CAiTimer field_44;
};
#pragma pack(pop)