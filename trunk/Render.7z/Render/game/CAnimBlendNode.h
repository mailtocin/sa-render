/*
    SA::Render source file
    CAnimBlendNode structure
*/
#pragma once

#pragma pack(push, 1)
struct CAnimBlendNode
{
    float field_0;
    float field_4;
    unsigned short field_8;
    unsigned short field_A;
    float field_C;
    unsigned int field_10;
    unsigned int m_pAnimBlendAssociation;
};
#pragma pack(pop)