/*
    SA::Render source file
    COccluder structure
*/
#pragma once

#pragma pack(push, 1)
struct COccluder
{
    short midX;
    short midY;
    short midZ;
    short widthY;
    short widthX;
    short height;
    char rotation;
    char rotation2;
    char rotation3;
    char field_F;
    short flags;
};
#pragma pack(pop)