/*
    SA::Render source file
    CPadConfig structure
*/
#pragma once

#pragma pack(push, 1)
struct CPadConfig
{
    int field_0;
    char present;
    char zaxisPresent;
    char rzAxisPresent;
    char __align;
    int vendorId;
    int productId;
};
#pragma pack(pop)