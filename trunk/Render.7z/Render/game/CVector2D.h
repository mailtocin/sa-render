/*
    SA::Render source file
    CVector2D structure
*/
#pragma once

#pragma pack(push, 1)
struct CVector2D
{
    float x;
    float y;
};
#pragma pack(pop)