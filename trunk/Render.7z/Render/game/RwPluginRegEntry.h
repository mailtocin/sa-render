/*
    SA::Render source file
    RwPluginRegEntry structure
*/
#pragma once

#pragma pack(push, 1)
struct RwPluginRegEntry
{
    int offset;
    int sizeOfStruct;
    int pluginID;
    int readCB;
    int writeCB;
    int getSizeCB;
    int alwaysCB;
    int rightsCB;
    int constructCB;
    int destructCB;
    int copyCB;
    int errStrCB;
    int nextRegEntry;
    int prevregEntry;
    int parentRegistry;
};
#pragma pack(pop)