/*
    SA::Render source file
    ColInitData structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct ColInitData
{
    int field_0;
    int animID;
    int field_4;
    RwV3D center;
    float radius;
};
#pragma pack(pop)