/*
    SA::Render source file
    CFxSystem structure
*/
#pragma once
#include "CFxSystem.h"
#include "CFxPrimEmitterData.h"
#include "CBoundingSphere.h"

#pragma pack(push, 1)
struct CFxSystem
{
    CFxSystem *m_pNext;
    CFxSystem *m_pPrev;
    int m_dwKey;
    int m_fLength;
    float m_fLoopIntervalMin;
    float m_fLoopLength;
    short m_sCullDist;
    char m_cPlayMode;
    char m_cNumPrims;
    CFxPrimEmitterData **m_pPrimsPtrList;
    CBoundingSphere *m_pBoundingSphere;
};
#pragma pack(pop)