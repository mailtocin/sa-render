/*
    SA::Render source file
    unkColStruct structure
*/
#pragma once

#pragma pack(push, 1)
struct unkColStruct
{
    short x;
    short y;
    short z;
    int field_6;
};
#pragma pack(pop)