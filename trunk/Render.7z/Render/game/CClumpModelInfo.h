/*
    SA::Render source file
    CClumpModelInfo structure
*/
#pragma once
#include "CBaseModelInfo.h"

#pragma pack(push, 1)
struct CClumpModelInfo
{
    CBaseModelInfo base;
    int _ifp;
};
#pragma pack(pop)