/*
    SA::Render source file
    CModelObjs structure
*/
#pragma once
#include "CBaseModelInfo.h"

#pragma pack(push, 1)
struct CModelObjs
{
    CBaseModelInfo __parent;
};
#pragma pack(pop)