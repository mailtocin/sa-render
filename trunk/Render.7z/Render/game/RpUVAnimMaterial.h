/*
    SA::Render source file
    RpUVAnimMaterial structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpUVAnimMaterial
{
    RwMatrix *matrices[2];
    RtAnimInterpolator *interpolators[8];
};
#pragma pack(pop)