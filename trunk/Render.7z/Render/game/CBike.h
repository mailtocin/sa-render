/*
    SA::Render source file
    CBike structure
*/
#pragma once
#include "CVehicle.h"
#include "CMatrix.h"

#pragma pack(push, 1)
struct CBike
{
    CVehicle vehicle;
    void *frameArray[10];
    unsigned char byte5C8;
    unsigned char f5C9[3];
    CMatrix dynamicMatrix;
    unsigned char byte614;
    unsigned char f615[27];
    unsigned int dword630;
    unsigned int dword634;
    unsigned int dword638;
    unsigned int dword63C;
    unsigned char ifpData[256];
    float dword740;
    unsigned char f744[76];
    unsigned int dword790;
    unsigned int dword794;
    unsigned int dword798;
    unsigned int dword79C;
    unsigned int dword7A0;
    float float7A4;
    unsigned short word7A8;
    unsigned char f7AA[2];
    unsigned int dword7AC;
    unsigned int dword7B0;
    unsigned char byte7B4;
    unsigned char byte7B5;
    unsigned char f7B6[2];
    unsigned int dword7B8;
    unsigned int dword7BC;
    int f7C0[4];
    char field_7D0[48];
    unsigned int dword800;
    unsigned char byte804;
    unsigned char byte805;
    unsigned char byte806;
    unsigned char f807[1];
    unsigned int dword808;
};
#pragma pack(pop)