/*
    SA::Render source file
    IDirectInputDeviceA structure
*/
#pragma once

#pragma pack(push, 1)
struct IDirectInputDeviceA
{
    void *lpVtbl;
};
#pragma pack(pop)