/*
    SA::Render source file
    eNameState enumeration
*/
#pragma once

enum eNameState
{
    NAME_DONT_SHOW = 0x0,
    NAME_SHOW = 0x1,
    NAME_FADE_IN = 0x2,
    NAME_FADE_OUT = 0x3,
    NAME_SWITCH = 0x4,
};