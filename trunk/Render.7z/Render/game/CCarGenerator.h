/*
    SA::Render source file
    CCarGenerator structure
*/
#pragma once

#pragma pack(push, 1)
struct CCarGenerator
{
    short model;
    char color1;
    char color2;
    short x;
    short y;
    short z;
    char angle;
    char alarm;
    char doorLock;
    char flags;
    short minDelay;
    short maxDelay;
    short field_12;
    int nextGen;
    short field_18;
    short enabled;
    char field_1C;
    char isUsed;
    short field_1E;
};
#pragma pack(pop)