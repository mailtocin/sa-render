/*
    SA::Render source file
    MACRO_WS_OVERLAPPEDWINDOW enumeration
*/
#pragma once

enum MACRO_WS_OVERLAPPEDWINDOW
{
    WS_OVERLAPPEDWINDOW = 13565952,
    WS_POPUPWINDOW = -2138570752,
};