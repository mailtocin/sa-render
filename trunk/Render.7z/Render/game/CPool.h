/*
    SA::Render source file
    CPool structure
*/
#pragma once

#pragma pack(push, 1)
struct CPool
{
    int objects;
    char *flags;
    int size;
    int top;
    char initialized;
    char field_11;
    short _pad;
};
#pragma pack(pop)