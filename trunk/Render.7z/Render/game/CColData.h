/*
    SA::Render source file
    CColData structure
*/
#pragma once
#include "CColSphere.h"
#include "CColBox.h"
#include "CColLine.h"
#include "CCompressedVector.h"
#include "CColTriangle.h"
#include "CColTrianglePlane.h"

#pragma pack(push, 1)
struct CColData
{
    short m_wNumSpheres;
    short m_wNumBoxes;
    short m_wNumTriangles;
    char m_bNumLines;
    char m_bFlags;
    CColSphere *m_pSpheres;
    CColBox *m_pBoxes;
    CColLine *m_pLines;
    CCompressedVector *m_pVertices;
    CColTriangle *m_pTriangles;
    CColTrianglePlane *m_pTrianglePlanes;
    int m_dwNumShadowTriangles;
    int m_dwNumShadowVertices;
    int m_pShadowVertices;
    int m_pShadowTriangles;
};
#pragma pack(pop)