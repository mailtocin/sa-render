/*
    SA::Render source file
    MACRO_E enumeration
*/
#pragma once

enum MACRO_E
{
    E_NOTIMPL = 0x80004001,
    E_OUTOFMEMORY = 0x8007000E,
    E_INVALIDARG = 0x80070057,
};