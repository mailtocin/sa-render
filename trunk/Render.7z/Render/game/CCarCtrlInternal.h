/*
    SA::Render source file
    CCarCtrlInternal structure
*/
#pragma once

#pragma pack(push, 1)
struct CCarCtrlInternal
{
    int field_0[11];
    short field_2C;
};
#pragma pack(pop)