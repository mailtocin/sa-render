/*
    SA::Render source file
    CInputEvents__EventName structure
*/
#pragma once

#pragma pack(push, 1)
struct CInputEvents__EventName
{
    char name[40];
};
#pragma pack(pop)