/*
    SA::Render source file
    gtaHAnimIFrame structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct gtaHAnimIFrame
{
    RtQuat m_qOrient;
    RwV3D m_vOffset;
};
#pragma pack(pop)