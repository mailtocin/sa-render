/*
    SA::Render source file
    XYZStore structure
*/
#pragma once
#include "XYZ.h"

#pragma pack(push, 1)
struct XYZStore
{
    XYZ _l1Head;
    XYZ _l1Tail;
    XYZ allocatedListHead;
    XYZ allocatedListTail;
    XYZ freeListHead;
    XYZ freeListTail;
    int pool;
};
#pragma pack(pop)