/*
    SA::Render source file
    CTaskSimpleSetCharDecisionMaker structure
*/
#pragma once
#include "CTask.h"

#pragma pack(push, 1)
struct CTaskSimpleSetCharDecisionMaker
{
    CTask __parent;
    int m_dwDmHandle;
};
#pragma pack(pop)