/*
    SA::Render source file
    RpAtomicVisibility enumeration
*/
#pragma once

enum RpAtomicVisibility
{
    VISIBILITY_OK = 0x1,
    VISIBILITY_DAM = 0x2,
};