/*
    SA::Render source file
    STICKYKEYS structure
*/
#pragma once

#pragma pack(push, 1)
struct STICKYKEYS
{
    int cbSize;
    int dwFlags;
};
#pragma pack(pop)