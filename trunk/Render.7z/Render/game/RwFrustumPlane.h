/*
    SA::Render source file
    RwFrustumPlane structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwFrustumPlane
{
    RwPlane plane;
    char closestX;
    char closestY;
    char closestZ;
    char pad;
};
#pragma pack(pop)