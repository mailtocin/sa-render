/*
    SA::Render source file
    DIDATAFORMAT structure
*/
#pragma once

#pragma pack(push, 1)
struct DIDATAFORMAT
{
    int dwSize;
    int dwObjSize;
    int dwFlags;
    int dwDataSize;
    int dwNumObjs;
    void *rgodf;
};
#pragma pack(pop)