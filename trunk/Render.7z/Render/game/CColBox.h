/*
    SA::Render source file
    CColBox structure
*/
#pragma once
#include "RenderWare.h"
#include "CColSurface.h"

#pragma pack(push, 1)
struct CColBox
{
    RwBBox m_Box;
    CColSurface m_Surface;
};
#pragma pack(pop)