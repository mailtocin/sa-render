/*
    SA::Render source file
    RpMatFxDualPass structure
*/
#pragma once

#pragma pack(push, 1)
struct RpMatFxDualPass
{
    void *m_pTexture[2];
    unsigned int m_dwDstBlend;
    int field_C;
    int field_10;
    int m_dwType;
};
#pragma pack(pop)