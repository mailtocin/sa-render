/*
    SA::Render source file
    CPedIntelligence__struct_3 structure
*/
#pragma once
#include "CAiTimer.h"

#pragma pack(push, 1)
struct CPedIntelligence__struct_3
{
    char field_0;
    char gap_1[3];
    CAiTimer field_4;
    int field_10;
    int field_14;
    int field_18[10];
    int field_40[10];
    int field_68[10];
};
#pragma pack(pop)