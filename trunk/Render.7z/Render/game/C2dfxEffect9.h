/*
    SA::Render source file
    C2dfxEffect9 structure
*/
#pragma once
#include "C2dfx.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct C2dfxEffect9
{
    C2dfx base;
    RwV2D field_10;
    char field_18;
    char __pad[3];
};
#pragma pack(pop)