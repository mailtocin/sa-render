/*
    SA::Render source file
    CScriptTrigger structure
*/
#pragma once

#pragma pack(push, 1)
struct CScriptTrigger
{
    short IMG_index;
    char AttachType;
    char Type;
    int Status?;
    int Radius;
    short modelID;
    short priority;
    int field_10;
};
#pragma pack(pop)