/*
    SA::Render source file
    eHelpBoxState enumeration
*/
#pragma once

enum eHelpBoxState
{
    HELPBOX_FADING = 0x3,
};