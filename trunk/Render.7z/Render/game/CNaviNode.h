/*
    SA::Render source file
    CNaviNode structure
*/
#pragma once
#include "CNodeInfo.h"

#pragma pack(push, 1)
struct CNaviNode
{
    short x;
    short y;
    CNodeInfo info;
    char dirX;
    char dirY;
    char flags1;
    char flags2;
    char flags3;
    char flags4;
};
#pragma pack(pop)