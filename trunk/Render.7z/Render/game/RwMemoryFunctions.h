/*
    SA::Render source file
    RwMemoryFunctions structure
*/
#pragma once

#pragma pack(push, 1)
struct RwMemoryFunctions
{
    void *(__cdecl;
    int (__cdecl;
    int (__cdecl;
    int rwcalloc;
};
#pragma pack(pop)