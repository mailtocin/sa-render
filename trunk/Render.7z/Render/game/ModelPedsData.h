/*
    SA::Render source file
    ModelPedsData structure
*/
#pragma once
#include "CModelPeds.h"

#pragma pack(push, 1)
struct ModelPedsData
{
    int count;
    CModelPeds objects[278];
};
#pragma pack(pop)