/*
    SA::Render source file
    CAnimBlock structure
*/
#pragma once

#pragma pack(push, 1)
struct CAnimBlock
{
    char szName[16];
    char bLoaded;
    char pad;
    short usRefs;
    int startAnimation;
    int animationCount;
    int animationStyle;
};
#pragma pack(pop)