/*
    SA::Render source file
    CModelBaseVtbl structure
*/
#pragma once
#include "CBaseModelInfo.h"

#pragma pack(push, 1)
struct CModelBaseVtbl
{
    void *__destructor;
    CBaseModelInfo *(__thiscall;
    void *_m08;
    void *_m0C;
    int (__thiscall;
    int (*getTimeinfo)(void);
    void *init;
    int clear;
    int deleteRwObject;
    int (__thiscall;
    int createInstanceSetMM;
    int (__thiscall;
    int initIfpName;
    int initIfp;
    int (__thiscall;
};
#pragma pack(pop)