/*
    SA::Render source file
    IShellDetailsVtbl structure
*/
#pragma once

#pragma pack(push, 1)
struct IShellDetailsVtbl
{
    void *QueryInterface;
    void *AddRef;
    void *Release;
    void *GetDetailsOf;
    void *ColumnClick;
};
#pragma pack(pop)