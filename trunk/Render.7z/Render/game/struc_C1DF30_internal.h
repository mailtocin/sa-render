/*
    SA::Render source file
    struc_C1DF30_internal structure
*/
#pragma once

#pragma pack(push, 1)
struct struc_C1DF30_internal
{
    int field_0;
    int field_4;
    int field_8;
    int field_C;
    int field_10;
    int field_14;
    int field_18;
    int field_1C;
    int field_20;
    int field_24;
    int field_28;
    int field_2C;
    int field_30;
};
#pragma pack(pop)