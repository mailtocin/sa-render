/*
    SA::Render source file
    RxPipeline structure
*/
#pragma once

#pragma pack(push, 1)
struct RxPipeline
{
    int locked;
    int numNodes;
    void *nodes;
    int packetNumClusterSlots;
    int embeddedPacketState;
    int embeddedPacket;
    int numInputRequirements;
    int inputRequirements;
    int superBlock;
    int superBlockSize;
    int entryPoint;
    int pluginId;
    int pluginData;
};
#pragma pack(pop)