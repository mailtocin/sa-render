/*
    SA::Render source file
    struct_C92140 structure
*/
#pragma once

#pragma pack(push, 1)
struct struct_C92140
{
    int field_0;
    int field_4;
    char field_8;
    char field_9;
    char field_A;
    char field_B;
    int field_C;
};
#pragma pack(pop)