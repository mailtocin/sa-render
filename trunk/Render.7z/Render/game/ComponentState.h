/*
    SA::Render source file
    ComponentState enumeration
*/
#pragma once

enum ComponentState
{
    STATE_OK = 0x0,
    STATE_OPENED = 0x1,
    STATE_DAMAGED = 0x2,
    STATE_OPENED_DAMAGED = 0x3,
    STATE_NOTPRESENT = 0x4,
};