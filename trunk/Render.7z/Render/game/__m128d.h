/*
    SA::Render source file
    __m128d structure
*/
#pragma once

struct __m128d
{
    double m128d_f64[2];
};