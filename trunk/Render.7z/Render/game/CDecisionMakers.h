/*
    SA::Render source file
    CDecisionMakers structure
*/
#pragma once

#pragma pack(push, 1)
struct CDecisionMakers
{
    char field_0[20];
    short m_awUniqueID[20];
    char m_abUsed[20];
    int m_pMgr;
};
#pragma pack(pop)