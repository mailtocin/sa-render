/*
    SA::Render source file
    CTaskComplexEvasiveDiveAndGetUp structure
*/
#pragma once
#include "CTaskComplex.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct CTaskComplexEvasiveDiveAndGetUp
{
    CTaskComplex __parent;
    int m_pEntity;
    int m_nTimeOnGround;
    RwV3D m_vDirection;
    char field_20;
};
#pragma pack(pop)