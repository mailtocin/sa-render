/*
    SA::Render source file
    RwPluginId enumeration
*/
#pragma once

enum RwPluginId
{
    rwID_STRUCT = 0x1,
    rwID_STRING = 0x2,
    rwID_EXTENSION = 0x3,
    rwID_CAMERA = 0x5,
    rwID_TEXTURE = 0x6,
    rwID_MATERIAL = 0x7,
    rwID_MATLIST = 0x8,
    rwID_ATOMICSECT = 0x9,
    rwID_PLANESECT = 0xA,
    rwID_WORLD = 0xB,
    rwID_SPLINE = 0xC,
    rwID_MATRIX = 0xD,
    rwID_FRAMELIST = 0xE,
    rwID_GEOMETRY = 0xF,
    rwID_CLUMP = 0x10,
    rwID_LIGHT = 0x12,
    rwID_UNICODESTRING = 0x13,
    rwID_ATOMIC = 0x14,
    rwID_TEXTURENATIVE = 0x15,
    rwID_ANISOTPLUGIN = 0x127,
};