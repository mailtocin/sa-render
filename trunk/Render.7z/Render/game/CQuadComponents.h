/*
    SA::Render source file
    CQuadComponents structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CQuadComponents
{
    RwFrame *_dummy;
    RwFrame *chassis;
    RwFrame *wheel_rf_dummy;
    RwFrame *wheel_rm_dummy;
    RwFrame *wheel_rb_dummy;
    RwFrame *wheel_lf_dummy;
    RwFrame *wheel_lm_dummy;
    RwFrame *wheel_lb_dummy;
    RwFrame *door_rf_dummy;
    RwFrame *door_rr_dummy;
    RwFrame *door_lf_dummy;
    RwFrame *door_lr_dummy;
    RwFrame *body_front_dummy;
    RwFrame *body_rear_dummy;
    RwFrame *suspension_rf;
    RwFrame *suspension_lf;
    RwFrame *rear_axle;
    RwFrame *handlebars;
    RwFrame *misc_a;
    RwFrame *misc_b;
    int field_50[5];
};
#pragma pack(pop)