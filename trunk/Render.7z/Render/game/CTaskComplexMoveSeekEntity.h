/*
    SA::Render source file
    CTaskComplexMoveSeekEntity structure
*/
#pragma once
#include "CTaskComplex.h"

#pragma pack(push, 1)
struct CTaskComplexMoveSeekEntity
{
    CTaskComplex __parent;
    int m_pEntity;
    int m_nTime;
    int field_14;
    int m_nRadius;
    int field_1C;
    int field_20;
    int field_24;
    int field_28;
    int field_2C;
    char field_30;
    char field_31;
    char gap_32[2];
    int field_34;
    int field_38;
    char field_3C;
    char field_3D;
    char gap_3e[2];
    int m_posCalc;
    int field_44;
    char field_48;
    char field_49[3];
};
#pragma pack(pop)