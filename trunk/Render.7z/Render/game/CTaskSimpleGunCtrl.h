/*
    SA::Render source file
    CTaskSimpleGunCtrl structure
*/
#pragma once
#include "CTask.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct CTaskSimpleGunCtrl
{
    CTask __parent;
    char field_8;
    char gap_9[3];
    int field_C;
    RwV3D field_10;
    RwV3D field_1C;
    int field_28;
    short field_2C;
    char field_2E;
    char gap_2f[1];
    int field_30;
    int field_34;
    char field_38;
    char field_39;
    char field_3A;
    char field_3B;
};
#pragma pack(pop)