/*
    SA::Render source file
    CollisionLink structure
*/
#pragma once
#include "CollisionLink.h"

#pragma pack(push, 1)
struct CollisionLink
{
    int ptr;
    CollisionLink *next;
    CollisionLink *prev;
};
#pragma pack(pop)