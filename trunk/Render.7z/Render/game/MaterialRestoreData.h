/*
    SA::Render source file
    MaterialRestoreData structure
*/
#pragma once

#pragma pack(push, 1)
struct MaterialRestoreData
{
    int pMaterialField;
    int OldData;
};
#pragma pack(pop)