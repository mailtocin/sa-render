/*
    SA::Render source file
    IDirect3DSurface9 structure
*/
#pragma once
#include "IDirect3DSurface9Vtbl.h"

#pragma pack(push, 1)
struct IDirect3DSurface9
{
    IDirect3DSurface9Vtbl *lpVtbl;
};
#pragma pack(pop)