/*
    SA::Render source file
    RpAtomicFlag enumeration
*/
#pragma once

enum RpAtomicFlag
{
    rpATOMICCOLLISIONTEST = 0x1,
    rpATOMICRENDER = 0x4,
};