/*
    SA::Render source file
    CHandlingData structure
*/
#pragma once
#include "CHandlingVehicle.h"
#include "CHandlingBike.h"
#include "CHandlingFlying.h"
#include "CHandlingBoat.h"

#pragma pack(push, 1)
struct CHandlingData
{
    int field_0;
    int field_4;
    int field_8;
    int field_C;
    int field_10;
    CHandlingVehicle vehicleHandling[210];
    CHandlingBike bikeHandling[13];
    CHandlingFlying flyingHandling[24];
    CHandlingBoat boatHandling[12];
};
#pragma pack(pop)