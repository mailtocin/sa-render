/*
    SA::Render source file
    CPedTasks structure
*/
#pragma once

#pragma pack(push, 1)
struct CPedTasks
{
    int m_primaryTasks[5];
    int m_secondaryTasks[6];
    int m_pPed;
};
#pragma pack(pop)