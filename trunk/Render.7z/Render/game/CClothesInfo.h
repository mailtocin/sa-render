/*
    SA::Render source file
    CClothesInfo structure
*/
#pragma once

#pragma pack(push, 1)
struct CClothesInfo
{
    int modelHash[10];
    int textureHash[18];
    int field_70;
    int field_74;
};
#pragma pack(pop)