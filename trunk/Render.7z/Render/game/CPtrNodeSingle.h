/*
    SA::Render source file
    CPtrNodeSingle structure
*/
#pragma once

#pragma pack(push, 1)
struct CPtrNodeSingle
{
    int ptr;
    int next;
};
#pragma pack(pop)