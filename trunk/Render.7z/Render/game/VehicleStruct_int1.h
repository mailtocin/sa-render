/*
    SA::Render source file
    VehicleStruct_int1 structure
*/
#pragma once

#pragma pack(push, 1)
struct VehicleStruct_int1
{
    int field_0;
    int field_4;
    int field_8;
};
#pragma pack(pop)