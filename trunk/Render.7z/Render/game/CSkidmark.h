/*
    SA::Render source file
    CSkidmark structure
*/
#pragma once
#include "CVector.h"

#pragma pack(push, 1)
struct CSkidmark
{
    CVector m_vPosn[16];
    unsigned int dwordC0;
    unsigned char fC4[60];
    unsigned int dword100;
    unsigned char f104[60];
    unsigned int dword140;
    unsigned int dword144;
    int time1;
    int time2;
    unsigned int m_nSurfaceType;
    unsigned short m_nNumParts;
    unsigned char m_nState;
    unsigned char byte157;
};
#pragma pack(pop)