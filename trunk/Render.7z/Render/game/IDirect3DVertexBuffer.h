/*
    SA::Render source file
    IDirect3DVertexBuffer structure
*/
#pragma once
#include "IDirect3DVertexBufferVtbl.h"

#pragma pack(push, 1)
struct IDirect3DVertexBuffer
{
    IDirect3DVertexBufferVtbl *lpVtbl;
};
#pragma pack(pop)