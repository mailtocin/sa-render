/*
    SA::Render source file
    fake_CTimeShadow structure
*/
#pragma once

#pragma pack(push, 2)
struct fake_CTimeShadow
{
    float float0;
    unsigned char f4[42];
    unsigned char type;
};
#pragma pack(pop)