/*
    SA::Render source file
    CTaskSimpleStandStill structure
*/
#pragma once
#include "CTask.h"
#include "CAiTimer.h"

#pragma pack(push, 1)
struct CTaskSimpleStandStill
{
    CTask __parent;
    int m_nTime;
    CAiTimer m_timer;
    char field_18;
    char field_19;
    char gap_1a[2];
    int field_1C;
};
#pragma pack(pop)