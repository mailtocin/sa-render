/*
    SA::Render source file
    D3DLIGHT9 structure
*/
#pragma once
#include "D3DLIGHTTYPE.h"
#include "D3DCOLORVALUE.h"
#include "D3DVECTOR.h"

#pragma pack(push, 1)
struct D3DLIGHT9
{
    D3DLIGHTTYPE Type;
    D3DCOLORVALUE Diffuse;
    D3DCOLORVALUE Specular;
    D3DCOLORVALUE Ambient;
    D3DVECTOR Position;
    D3DVECTOR Direction;
    float Range;
    float Falloff;
    float Attenuation0;
    float Attenuation1;
    float Attenuation2;
    float Theta;
    float Phi;
};
#pragma pack(pop)