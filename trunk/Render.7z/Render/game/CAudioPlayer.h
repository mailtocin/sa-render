/*
    SA::Render source file
    CAudioPlayer structure
*/
#pragma once
#include "CAudioFilesInfo.h"

#pragma pack(push, 1)
struct CAudioPlayer
{
    unsigned char byte0;
    char field_1;
    char gap_2[2];
    char field_4;
    unsigned char f5[1];
    unsigned short word6;
    unsigned char f8[132];
    unsigned short word8C;
    unsigned short word8E;
    short field_90[454];
    int field_41C;
    char field_420[16];
    short m_aBankSlotIds[300];
    short m_aSoundTypes[300];
    short field_8E0[300];
    short field_B38[300];
    int field_D90;
    char gap_D94[4];
    CAudioFilesInfo *m_pPakFilesInfo;
    unsigned int m_pTraksInfo;
    unsigned char fDA0[12];
    unsigned int dwordDAC;
    unsigned char fDB0[52];
    unsigned int dwordDE4;
    unsigned char fDE8[40];
    unsigned int dwordE10;
    char charE14;
    unsigned char fE15[79];
    int dwordE64[2];
};
#pragma pack(pop)