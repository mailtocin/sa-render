/*
    SA::Render source file
    MACRO_E_NOINTERFACE enumeration
*/
#pragma once

enum MACRO_E_NOINTERFACE
{
    E_NOINTERFACE = 0x80004002,
    E_POINTER = 0x80004003,
    E_HANDLE = 0x80070006,
};