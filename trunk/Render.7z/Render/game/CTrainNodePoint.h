/*
    SA::Render source file
    CTrainNodePoint structure
*/
#pragma once

#pragma pack(push, 1)
struct CTrainNodePoint
{
    short x;
    short y;
    short z;
    short distanceFromStart;
    short field_8;
};
#pragma pack(pop)