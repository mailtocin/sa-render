/*
    SA::Render source file
    JumptableLabel structure
*/
#pragma once

#pragma pack(push, 1)
struct JumptableLabel
{
    int field_0;
    int field_4;
};
#pragma pack(pop)