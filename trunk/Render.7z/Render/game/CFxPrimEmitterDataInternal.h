/*
    SA::Render source file
    CFxPrimEmitterDataInternal structure
*/
#pragma once
#include "CFxInfoNoiseData.h"

#pragma pack(push, 1)
struct CFxPrimEmitterDataInternal
{
    int m_dwNumInfos;
    CFxInfoNoiseData **m_pInfos;
    char m_cNumInfos;
    char field_9;
    char _pad[2];
};
#pragma pack(pop)