/*
    SA::Render source file
    gtaVertexColorPlugin structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct gtaVertexColorPlugin
{
    RwRGBA *m_pNightColors;
    RwRGBA *m_pDayColors;
    float intensity;
};
#pragma pack(pop)