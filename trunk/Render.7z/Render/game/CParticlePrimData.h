/*
    SA::Render source file
    CParticlePrimData structure
*/
#pragma once
#include "CParticlePrimData_VMT.h"
#include "CFxPrimEmitterData.h"
#include "CParticle.h"

#pragma pack(push, 1)
struct CParticlePrimData
{
    CParticlePrimData_VMT *vmt;
    CFxPrimEmitterData *m_pFxPrimData;
    CParticle *m_pParticle;
    unsigned char field_C;
    char _padding[3];
    int field_10;
};
#pragma pack(pop)