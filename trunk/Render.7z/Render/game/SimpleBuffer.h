/*
    SA::Render source file
    SimpleBuffer structure
*/
#pragma once

#pragma pack(push, 1)
struct SimpleBuffer
{
    int ptr;
    int size;
    int position;
};
#pragma pack(pop)