/*
    SA::Render source file
    CVehicleStruct structure
*/
#pragma once
#include "RenderWare.h"
#include "CUpgradeComponent.h"

#pragma pack(push, 1)
struct CVehicleStruct
{
    RwV3D m_vDummyPos[15];
    CUpgradeComponent m_sUpgrade[18];
    RpAtomic *m_pExtra[6];
    char m_cNumExtras;
    char _pad[3];
    int m_iMaskComponentsDamagable;
};
#pragma pack(pop)