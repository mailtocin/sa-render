/*
    SA::Render source file
    RwImage structure
*/
#pragma once

#pragma pack(push, 1)
struct RwImage
{
    int flags;
    int width;
    int height;
    int depth;
    int stride;
    int cpPixels;
    int palette;
};
#pragma pack(pop)