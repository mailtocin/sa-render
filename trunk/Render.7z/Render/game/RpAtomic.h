/*
    SA::Render source file
    RpAtomic structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpAtomic
{
    RwObjectHasFrame object;
    int repEntry;
    RpGeometry *geometry;
    RwSphere boundingSphere;
    void *worldBoundingSphere[4];
    RpClump *clump;
    RwLLLink inClumpLink;
    int (__cdecl;
    RpInterpolator interpolator;
    short renderFrame;
    short pad;
    RwLinkList llWorldSectorsInAtomic;
    int pipeline;
    char field_70;
};
#pragma pack(pop)