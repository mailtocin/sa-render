/*
    SA::Render source file
    RwCameraClearMode enumeration
*/
#pragma once

enum RwCameraClearMode
{
    rwCAMERACLEARIMAGE = 0x1,
    rwCAMERACLEARZ = 0x2,
    rwCAMERACLEARSTENCIL = 0x4,
};