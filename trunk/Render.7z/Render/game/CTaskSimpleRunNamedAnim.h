/*
    SA::Render source file
    CTaskSimpleRunNamedAnim structure
*/
#pragma once
#include "CTaskSimpleAnim.h"
#include "CAiTimer.h"

#pragma pack(push, 1)
struct CTaskSimpleRunNamedAnim
{
    CTaskSimpleAnim __parent;
    char m_szAnimName[24];
    int field_28;
    int field_2C;
    int field_30;
    int field_34;
    float field_38;
    int animation;
    int field_40;
    CAiTimer field_44;
    int field_50;
    int field_54;
    int field_58;
    int field_5C;
    int field_60;
};
#pragma pack(pop)