/*
    SA::Render source file
    CPhysical_vtbl structure
*/
#pragma once
#include "CEntity_vtbl.h"

#pragma pack(push, 1)
struct CPhysical_vtbl
{
    CEntity_vtbl __parent;
    int processEntityCollision;
};
#pragma pack(pop)