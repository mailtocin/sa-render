/*
    SA::Render source file
    MD5_Ctx structure
*/
#pragma once

#pragma pack(push, 1)
struct MD5_Ctx
{
    int countLow;
    int countHi;
    int state[4];
};
#pragma pack(pop)