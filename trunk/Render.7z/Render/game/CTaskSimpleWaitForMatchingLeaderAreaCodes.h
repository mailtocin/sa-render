/*
    SA::Render source file
    CTaskSimpleWaitForMatchingLeaderAreaCodes structure
*/
#pragma once
#include "CTaskSimpleWaitUntilAreaCodesMatch.h"

#pragma pack(push, 1)
struct CTaskSimpleWaitForMatchingLeaderAreaCodes
{
    CTaskSimpleWaitUntilAreaCodesMatch __parent;
    char field_24;
    char field_25[15];
    char field_34;
    char field_35[3];
};
#pragma pack(pop)