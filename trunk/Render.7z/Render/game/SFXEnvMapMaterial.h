/*
    SA::Render source file
    SFXEnvMapMaterial structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct SFXEnvMapMaterial
{
    RwFrame *pFrame;
    int pTexture;
    float fCoefficient;
    int dwFrameBufferAlpha;
    int fSize;
    int nEffectType;
};
#pragma pack(pop)