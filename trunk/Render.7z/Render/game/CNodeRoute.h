/*
    SA::Render source file
    CNodeRoute structure
*/
#pragma once

#pragma pack(push, 1)
struct CNodeRoute
{
    int field_0;
    int field_4;
    int field_8;
    int field_C;
    int field_10;
    int field_14;
    int field_18;
    int field_1C;
    int field_20;
};
#pragma pack(pop)