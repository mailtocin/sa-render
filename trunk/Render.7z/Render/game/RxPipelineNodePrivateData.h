/*
    SA::Render source file
    RxPipelineNodePrivateData structure
*/
#pragma once

#pragma pack(push, 1)
struct RxPipelineNodePrivateData
{
    int D3D9AtomicDefaultInstanceCallback;
    int D3D9AtomicDefaultReinstanceCallback;
    int rwD3D9AtomicDefaultLightingCallback;
    int rxD3D9DefaultRenderCallback;
};
#pragma pack(pop)