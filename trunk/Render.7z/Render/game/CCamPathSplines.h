/*
    SA::Render source file
    CCamPathSplines structure
*/
#pragma once

#pragma pack(push, 1)
struct CCamPathSplines
{
    float *m_arr_PathData;
};
#pragma pack(pop)