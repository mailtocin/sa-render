/*
    SA::Render source file
    CScriptParticle structure
*/
#pragma once

#pragma pack(push, 1)
struct CScriptParticle
{
    char bUsed;
    char gap_1[1];
    short wUniqueID;
    int pParticleData;
};
#pragma pack(pop)