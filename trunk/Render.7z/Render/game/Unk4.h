/*
    SA::Render source file
    Unk4 structure
*/
#pragma once

#pragma pack(push, 1)
struct Unk4
{
    short m_nBankId;
    short m_nUsageCount;
};
#pragma pack(pop)