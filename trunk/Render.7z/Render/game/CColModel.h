/*
    SA::Render source file
    CColModel structure
*/
#pragma once
#include "RenderWare.h"
#include "CColData.h"

#pragma pack(push, 1)
struct CColModel
{
    RwBBox bbox;
    RwSphere sphere;
    char field_28;
    char flags;
    char field_2A;
    char field_2B;
    CColData *m_pColData;
};
#pragma pack(pop)