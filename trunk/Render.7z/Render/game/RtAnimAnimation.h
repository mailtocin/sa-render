/*
    SA::Render source file
    RtAnimAnimation structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RtAnimAnimation
{
    RtAnimInterpolatorInfo *interpInfo;
    int numFrames;
    int flags;
    float duration;
    void *pFrames;
    void *customData;
};
#pragma pack(pop)