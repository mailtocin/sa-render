/*
    SA::Render source file
    CPedAttractors structure
*/
#pragma once

#pragma pack(push, 1)
struct CPedAttractors
{
    int field_0[40];
};
#pragma pack(pop)