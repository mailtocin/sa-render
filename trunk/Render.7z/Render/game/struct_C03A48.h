/*
    SA::Render source file
    struct_C03A48 structure
*/
#pragma once

#pragma pack(push, 1)
struct struct_C03A48
{
    unsigned int dword0;
    unsigned int dword4;
    unsigned int dword8;
    unsigned int dwordC;
    unsigned int dword10;
    unsigned int dword14;
    unsigned int dword18;
    unsigned int dword1C;
    unsigned int dword20;
    unsigned int dword24;
    unsigned int dword28;
    unsigned int dword2C;
    unsigned char f30[16];
    unsigned int dword40;
    unsigned short word44;
    unsigned char byte46;
    char _padding;
    int field_48;
    int next;
    int prev;
};
#pragma pack(pop)