/*
    SA::Render source file
    CPedEvent_DM_List structure
*/
#pragma once
#include "CPedEvent_DM_EventData.h"

#pragma pack(push, 1)
struct CPedEvent_DM_List
{
    CPedEvent_DM_EventData field_0[41];
};
#pragma pack(pop)