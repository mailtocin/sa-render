/*
    SA::Render source file
    CStreamSector structure
*/
#pragma once

#pragma pack(push, 1)
struct CStreamSector
{
    int pEntities1;
    int pEntities2;
};
#pragma pack(pop)