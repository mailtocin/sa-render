/*
    SA::Render source file
    struc_C71AA0 structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct struc_C71AA0
{
    int field_0;
    float m_fX;
    float m_fY;
    int m_fWidth;
    float m_fHeigth;
    RwRGBA m_sColor;
    int field_18;
    int field_1C;
    int field_20;
    int field_24;
    char m_cIsBlip;
    char m_cFontCharsStyle;
    char m_cPropOn;
    char field_2B;
    short m_wFontTextureId;
    char m_cOutline2;
    char _pad;
};
#pragma pack(pop)