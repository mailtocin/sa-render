/*
    SA::Render source file
    MACRO_FILE_GENERIC_EXECUTE enumeration
*/
#pragma once

enum MACRO_FILE_GENERIC_EXECUTE
{
    FILE_SHARE_READ = 1,
    FILE_GENERIC_EXECUTE = 1179808,
};