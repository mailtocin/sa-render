/*
    SA::Render source file
    CPedAttractorSitOnBench structure
*/
#pragma once
#include "CPedAttractor.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct CPedAttractorSitOnBench
{
    unsigned int vmt;
    CPedAttractor *m_pEffect;
    unsigned int m_pEntity;
    unsigned char fC[4];
    unsigned int dword10;
    unsigned int dword14;
    unsigned int dword18;
    unsigned char f1C[4];
    unsigned int dword20;
    unsigned int dword24;
    unsigned int dword28;
    unsigned char f2C[4];
    unsigned int dword30;
    unsigned int dword34;
    unsigned int dword38;
    unsigned int m_unkType;
    unsigned int dword40;
    unsigned int dword44;
    unsigned int dword48;
    unsigned char f4C[8];
    unsigned int dword54;
    float field_58;
    RwV3D field_5C;
    RwV3D field_68;
    RwV3D field_74;
    int field_80;
    char m_acExternalScript[8];
};
#pragma pack(pop)