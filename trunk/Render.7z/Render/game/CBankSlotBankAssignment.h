/*
    SA::Render source file
    CBankSlotBankAssignment structure
*/
#pragma once
#include "CBankSlotsInfos.h"

#pragma pack(push, 1)
struct CBankSlotBankAssignment
{
    CBankSlotsInfos *m_pBankSlotInfo;
    int m_dwBankOffset;
    int m_dwBankLength;
    int m_pStreamOffset;
    int m_pStreamBuffer;
    int m_dwState;
    short m_nBankId;
    short m_nBankSlotId;
    short m_nNumSounds;
    char m_nPakFileNumber;
    char __pad;
};
#pragma pack(pop)