/*
    SA::Render source file
    IDirect3DBaseTexture9 structure
*/
#pragma once
#include "IDirect3DTexture9Vtbl.h"

#pragma pack(push, 1)
struct IDirect3DBaseTexture9
{
    IDirect3DTexture9Vtbl *lpVtbl;
};
#pragma pack(pop)