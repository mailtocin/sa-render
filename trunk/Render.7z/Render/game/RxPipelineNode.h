/*
    SA::Render source file
    RxPipelineNode structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RxPipelineNode
{
    RxNodeDefinition *nodeDef;
    int numOutputs;
    int *outputs;
    int slotClusterRefs;
    int *slotsContinue;
    RxPipelineNodePrivateData *privateData;
    int *inputToClusterSlot;
    void *topSortData;
    void *initializationData;
    int initializationDataSize;
};
#pragma pack(pop)