/*
    SA::Render source file
    RpMorphTarget structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpMorphTarget
{
    int parentGeom;
    RwSphere boundingSphere;
    void *verts;
    int normals;
};
#pragma pack(pop)