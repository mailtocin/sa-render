/*
    SA::Render source file
    RwStreamType enumeration
*/
#pragma once

enum RwStreamType
{
    rwNASTREAM = 0x0,
    rwSTREAMFILE = 0x1,
    rwSTREAMFILENAME = 0x2,
    rwSTREAMMEMORY = 0x3,
    rwSTREAMCUSTOM = 0x4,
};