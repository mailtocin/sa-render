/*
    SA::Render source file
    XYZ structure
*/
#pragma once
#include "CMatrix.h"

#pragma pack(push, 1)
struct XYZ
{
    CMatrix field_0;
    int ptr;
    int pPrev;
    int pNext;
};
#pragma pack(pop)