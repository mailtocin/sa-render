/*
    SA::Render source file
    _2dfxRoadsign_rwStream structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct _2dfxRoadsign_rwStream
{
    RwV2D size;
    RwV3D rotation;
    short flags;
    char text[16][4];
};
#pragma pack(pop)