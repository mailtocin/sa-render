/*
    SA::Render source file
    RxObjSpace3dVertex structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RxObjSpace3dVertex
{
    RwV3D pos;
    RwV3D objNormal;
    int color;
    float u;
    float v;
};
#pragma pack(pop)