/*
    SA::Render source file
    RpHAnimHierarchy structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpHAnimHierarchy
{
    int flags;
    int numNodes;
    RwMatrix *pMatrixArray;
    void *pMatrixArrayUnaligned;
    RpHAnimNodeInfo *pNodeInfo;
    RwFrame *parentFrame;
    RpHAnimHierarchy *parentHierarchy;
    int rootParentOffset;
    RtAnimInterpolator *currentAnim;
};
#pragma pack(pop)