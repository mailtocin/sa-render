/*
    SA::Render source file
    CRegisteredCorona structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CRegisteredCorona
{
    RwV3D m_vPos;
    int m_dwId;
    int m_pTexture;
    float m_fSize;
    float m_fAngle;
    float m_fFarClip;
    float m_fNearClip;
    unsigned int m_fHeightAboveGround;
    float m_fFadeSpeed;
    RwRGBA m_sColor;
    unsigned char m_bFadeState;
    char m_bRegisteredThisFrame;
    char m_bFlare;
    char m_bUsesReflection;
    unsigned char m_bFlags1;
    char m_bJustCreated;
    unsigned char m_bFlags2;
    char __padding0;
    int m_pAttachedTo;
};
#pragma pack(pop)