/*
    SA::Render source file
    RwGlobals structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwGlobals
{
    RwCamera *curCamera;
    int curWorld;
    short renderFrame;
    short lightFrame;
    int pad;
    RwDevice dOpenDevice;
    int field_48;
    int _cameraBeginUpdate;
    int _rgbToPixel;
    int _pixelToRgb;
    int _rasterCreate;
    int (__cdecl;
    int _getImageFromRaster;
    int (__cdecl;
    int _textureSetRaster;
    int _findRasterFormat;
    int _cameraEndUpdate;
    int _setRasterContext;
    int _rasterSubraster;
    int _rasterClearRect;
    int _rasterClear;
    int (__cdecl;
    int _rasterUnlock;
    int (__cdecl;
    int _rasterRenderScaled;
    int (__cdecl;
    int _rasterShowRaster;
    int _cameraClear;
    int _hintRenderF2B;
    int _rasterLockPalette;
    int _rasterUnlockPalette;
    int _nativeTextureGetSize;
    int (__cdecl;
    int _nativeTextureWrite;
    int _rasterGetMipLevels;
    RwLinkList dirtyFrameList;
    RwFileFunction fileFuncs;
    RwStringFunctions stringFuncs;
    RwMemoryFunctions memoryFuncs;
    void *(__cdecl;
    int (__cdecl;
    int metrics;
    int engineStatus;
    int resArenaSize;
};
#pragma pack(pop)