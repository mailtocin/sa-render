/*
    SA::Render source file
    Specular structure
*/
#pragma once

#pragma pack(push, 1)
struct Specular
{
    float m_fLevel;
    int m_pTexture;
};
#pragma pack(pop)