/*
    SA::Render source file
    IDirect3DSwapChain9 structure
*/
#pragma once
#include "IDirect3DSwapChain9Vtbl.h"

#pragma pack(push, 1)
struct IDirect3DSwapChain9
{
    IDirect3DSwapChain9Vtbl *lpVtbl;
};
#pragma pack(pop)