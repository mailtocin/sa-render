/*
    SA::Render source file
    IDirectInputDevice8_Methods structure
*/
#pragma once

#pragma pack(push, 1)
struct IDirectInputDevice8_Methods
{
    int QueryInterface;
    int AddRef;
    int Release;
    int GetCapabilities;
    int EnumObjects;
    int GetProperty;
    int SetProperty;
    int Acquire;
    int Unacquire;
    int GetDeviceState;
    int GetDeviceData;
    int SetDataFormat;
    int SetEventNotification;
    int SetCooperativeLevel;
    int GetObjectInfo;
    int GetDeviceInfo;
    int RunControlPanel;
    int Initialize;
    int CreateEffect;
    int EnumEffects;
    int GetEffectInfo;
    int GetForceFeedbackState;
    int SendForceFeedbackCommand;
    int EnumCreatedEffectObjects;
    int Escape;
    int Poll;
    int SendDeviceData;
    int EnumEffectsInFile;
    int WriteEffectToFile;
    int BuildActionMap;
    int SetActionMap;
    int GetImageInfo;
};
#pragma pack(pop)