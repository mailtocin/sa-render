/*
    SA::Render source file
    CBankSlotInfo structure
*/
#pragma once
#include "Unk12.h"

#pragma pack(push, 1)
struct CBankSlotInfo
{
    int m_dwOffset;
    int m_dwLength;
    int field_8;
    int field_C;
    short m_nBankId;
    short m_nNumSoundInfos?;
    Unk12 m_aSoundsHeader[400];
};
#pragma pack(pop)