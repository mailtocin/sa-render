/*
    SA::Render source file
    TablEntry structure
*/
#pragma once

#pragma pack(push, 1)
struct TablEntry
{
    char name[8];
    int offset;
};
#pragma pack(pop)