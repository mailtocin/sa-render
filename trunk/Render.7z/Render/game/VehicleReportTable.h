/*
    SA::Render source file
    VehicleReportTable structure
*/
#pragma once
#include "CString.h"

#pragma pack(push, 1)
struct VehicleReportTable
{
    short field_0[4];
    short field_8[24];
    CString mapZones[194];
    short field_648[196];
    char field_7D0[200];
    short _vehicleReportSounds[46];
    char _flags[52];
    short _colors[128];
};
#pragma pack(pop)