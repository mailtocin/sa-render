/*
    SA::Render source file
    CAudioFileWindowsMedia structure
*/
#pragma once
#include "CAudioFile.h"

#pragma pack(push, 1)
struct CAudioFileWindowsMedia
{
    CAudioFile __parent;
};
#pragma pack(pop)