/*
    SA::Render source file
    CGrass structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CGrass
{
    int field_0;
    int field_4;
    int field_8;
    int field_C;
    int field_10;
    int field_14;
    int field_18;
    int field_1C;
    int field_20;
    RwV3D pos;
    unsigned short type;
    unsigned short field_32;
    float field_34;
    float field_38;
    RwTexture *m_pTexture;
    RwRGBA color;
    char colorIntensity;
    char field_45;
    char surface;
    char field_47;
    float randomSeed;
    unsigned int field_4C;
    unsigned int field_50;
    float field_54;
    unsigned int field_58;
};
#pragma pack(pop)