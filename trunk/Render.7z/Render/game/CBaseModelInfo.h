/*
    SA::Render source file
    CBaseModelInfo structure
*/
#pragma once
#include "CModelBaseVtbl.h"
#include "CColModel.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct CBaseModelInfo
{
    CModelBaseVtbl *vmt;
    int m_dwKey;
    short m_wUsageCount;
    short m_wTxdIndex;
    char field_C;
    char m_nbCount2dfx;
    short m_w2dfxIndex;
    short m_wObjectInfoIndex;
    short m_wFlags;
    CColModel *m_pColModel;
    int m_fDrawDistance;
    RpClump *m_pRwObject;
};
#pragma pack(pop)