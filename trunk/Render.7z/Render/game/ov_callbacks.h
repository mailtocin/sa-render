/*
    SA::Render source file
    ov_callbacks structure
*/
#pragma once

#pragma pack(push, 1)
struct ov_callbacks
{
    int read_func;
    int seek_func;
    int close_func;
    int tell_func;
};
#pragma pack(pop)