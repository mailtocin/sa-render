/*
    SA::Render source file
    CInputEvents structure
*/
#pragma once
#include "DIJOYSTATE2.h"
#include "CInputEvents__EventName.h"
#include "CInputEvents__Event.h"

#pragma pack(push, 1)
struct CInputEvents
{
    char field_0;
    char field_1;
    char field_2;
    char field_3;
    DIJOYSTATE2 prevPadState;
    DIJOYSTATE2 currPadState;
    CInputEvents__EventName eventNames[59];
    char field_B5C[17];
    char __pad2[3];
    CInputEvents__Event events[59];
    char field_12D0[16];
    char field_12E0;
    char __pad[3];
};
#pragma pack(pop)