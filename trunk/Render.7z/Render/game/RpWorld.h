/*
    SA::Render source file
    RpWorld structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpWorld
{
    RwObject object;
    int flags;
    int renderOrder;
    RpMaterialList matList;
    int rootSector;
    int numTexCoordSets;
    int numClumpsInWorld;
    int currentClumpLink;
    RwLinkList clumpList;
    RwLinkList lightList;
    RwLinkList directionalLightList;
    RwV3D worldOrigin;
    RwBBox boundingBox;
    int renderCallback;
    int pipeline;
};
#pragma pack(pop)