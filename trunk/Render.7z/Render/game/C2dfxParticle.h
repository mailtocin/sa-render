/*
    SA::Render source file
    C2dfxParticle structure
*/
#pragma once
#include "C2dfx.h"

#pragma pack(push, 1)
struct C2dfxParticle
{
    C2dfx base;
    char effectName[24];
};
#pragma pack(pop)