/*
    SA::Render source file
    CColTriangle structure
*/
#pragma once

#pragma pack(push, 1)
struct CColTriangle
{
    short a;
    short b;
    short c;
    char material;
    char light;
};
#pragma pack(pop)