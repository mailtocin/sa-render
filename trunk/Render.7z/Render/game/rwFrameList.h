/*
    SA::Render source file
    rwFrameList structure
*/
#pragma once

#pragma pack(push, 1)
struct rwFrameList
{
    int frames;
    int numFrames;
};
#pragma pack(pop)