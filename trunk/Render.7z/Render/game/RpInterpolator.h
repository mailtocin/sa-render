/*
    SA::Render source file
    RpInterpolator structure
*/
#pragma once

#pragma pack(push, 1)
struct RpInterpolator
{
    int flags;
    short startMorphTarget;
    short endMorphTarget;
    int time;
    int recipTime;
    int position;
};
#pragma pack(pop)