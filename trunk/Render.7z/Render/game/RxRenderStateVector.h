/*
    SA::Render source file
    RxRenderStateVector structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RxRenderStateVector
{
    int flags;
    int shadeMode;
    int srcBlend;
    int dstBlend;
    int textureRaster;
    int addressModeU;
    int addressModeV;
    int filterMode;
    RwRGBA borderColor;
    int fogType;
    RwRGBA fogColor;
};
#pragma pack(pop)