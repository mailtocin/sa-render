/*
    SA::Render source file
    CFxInfoAttractPtData structure
*/
#pragma once
#include "CFxInfoDataBase.h"
#include "CFxInfoAttractPtDataInternal.h"

#pragma pack(push, 1)
struct CFxInfoAttractPtData
{
    CFxInfoDataBase base;
    CFxInfoAttractPtDataInternal internal;
};
#pragma pack(pop)