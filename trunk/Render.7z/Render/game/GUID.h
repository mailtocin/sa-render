/*
    SA::Render source file
    GUID structure
*/
#pragma once

#pragma pack(push, 1)
struct GUID
{
    int Data1;
    short Data2;
    short Data3;
    char Data4[8];
};
#pragma pack(pop)