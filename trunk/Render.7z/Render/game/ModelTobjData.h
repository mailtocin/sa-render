/*
    SA::Render source file
    ModelTobjData structure
*/
#pragma once
#include "CModelTobj.h"

#pragma pack(push, 1)
struct ModelTobjData
{
    int count;
    CModelTobj objects[169];
};
#pragma pack(pop)