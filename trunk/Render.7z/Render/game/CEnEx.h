/*
    SA::Render source file
    CEnEx structure
*/
#pragma once
#include "CRect.h"
#include "CVector.h"
#include "CEnEx.h"

#pragma pack(push, 1)
struct CEnEx
{
    char m_acInteriorName[8];
    CRect m_rEnterRect;
    float m_fEnterZ;
    float m_fEnterAngle;
    CVector m_vExitPos;
    float m_fExitAngle;
    unsigned short m_wFlags;
    unsigned char m_bInteriorId;
    unsigned char m_bSkyColor;
    unsigned char m_bTimeOn;
    unsigned char m_bTimeOff;
    unsigned char byte36;
    unsigned char _padding[1];
    CEnEx *m_pAttachedEnex;
};
#pragma pack(pop)