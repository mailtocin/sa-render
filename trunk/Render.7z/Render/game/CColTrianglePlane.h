/*
    SA::Render source file
    CColTrianglePlane structure
*/
#pragma once
#include "CCompressedVector.h"

#pragma pack(push, 1)
struct CColTrianglePlane
{
    CCompressedVector normal;
    short distance;
    char field_8;
    char _pad;
};
#pragma pack(pop)