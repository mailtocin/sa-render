/*
    SA::Render source file
    ReflectionMaterialPlg structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct ReflectionMaterialPlg
{
    char m_bTransformParam[4];
    unsigned char m_bIntensity;
    char _pad;
    short m_wRenderFrame;
    RwTexture *m_pTexture;
};
#pragma pack(pop)