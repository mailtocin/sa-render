/*
    SA::Render source file
    CBulletInfo structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CBulletInfo
{
    int weaponType;
    int firedFrom;
    int destroyTime;
    char existFlag;
    char pad1[3];
    RwV3D position;
    RwV3D velocity;
    short damage;
    short pad2;
};
#pragma pack(pop)