/*
    SA::Render source file
    _2dfxParticle_rwStream structure
*/
#pragma once

#pragma pack(push, 1)
struct _2dfxParticle_rwStream
{
    char effectName[24];
};
#pragma pack(pop)