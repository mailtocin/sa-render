/*
    SA::Render source file
    Ped2dfxStream structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct Ped2dfxStream
{
    int type;
    RwV3D rotation[3];
    char m_acExternalScript[8];
    int pedExistingProbability;
    char flags1;
    char unknown35;
    char flags2;
    char unknown37;
};
#pragma pack(pop)