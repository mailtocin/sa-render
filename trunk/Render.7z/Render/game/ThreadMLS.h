/*
    SA::Render source file
    ThreadMLS structure
*/
#pragma once

#pragma pack(push, 1)
struct ThreadMLS
{
    int modelId;
    int pThread;
    int type;
};
#pragma pack(pop)