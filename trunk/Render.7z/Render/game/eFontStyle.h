/*
    SA::Render source file
    eFontStyle enumeration
*/
#pragma once

enum eFontStyle
{
    FONT_GOTHIC = 0x0,
    FONT_SUBTITLES = 0x1,
    FONT_MENU = 0x2,
    FONT_PRICEDOWN = 0x3,
};