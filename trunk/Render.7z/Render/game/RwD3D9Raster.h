/*
    SA::Render source file
    RwD3D9Raster structure
*/
#pragma once
#include "IDirect3DTexture9.h"
#include "IDirect3DSurface9.h"
#include "D3DLOCKED_RECT.h"
#include "D3DFORMAT.h"
#include "IDirect3DSwapChain9.h"
#include "HWND.h"

#pragma pack(push, 1)
struct RwD3D9Raster
{
    IDirect3DTexture9 *pTexture;
    unsigned int pPalette;
    char bAlpha;
    char bCubeTextureFlags;
    char bTextureFlags;
    char bLockFlags;
    IDirect3DSurface9 *pLockedSurface;
    D3DLOCKED_RECT sLockedRect;
    D3DFORMAT dwFormat;
    IDirect3DSwapChain9 *pSwapChain;
    HWND *pHWnd;
};
#pragma pack(pop)