/*
    SA::Render source file
    RwTexDictionary structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwTexDictionary
{
    RwObject object;
    RwLinkList texturesInDict;
    RwLLLink lInInstance;
};
#pragma pack(pop)