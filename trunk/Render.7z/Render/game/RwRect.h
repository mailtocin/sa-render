/*
    SA::Render source file
    RwRect structure
*/
#pragma once

#pragma pack(push, 1)
struct RwRect
{
    float x1;
    float y1;
    float x2;
    float y2;
};
#pragma pack(pop)