/*
    SA::Render source file
    CGlass structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CGlass
{
    RwMatrix matrix;
    int field_40;
    int field_44;
    int speed?;
    int field_4C;
    int field_50;
    RwV3D field_54;
    int createdTime;
    int field_64;
    int field_68;
    char field_6C;
    char existFlag;
    short field_6E;
};
#pragma pack(pop)