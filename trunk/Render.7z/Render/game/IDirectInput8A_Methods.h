/*
    SA::Render source file
    IDirectInput8A_Methods structure
*/
#pragma once

#pragma pack(push, 1)
struct IDirectInput8A_Methods
{
    int QueryInterface;
    int AddRef;
    int Release;
    int CreateDevice;
    int EnumDevices;
    int GetDeviceStatus;
    int RunControlPanel;
    int Initialize;
    int FindDevice;
    int EnumDevicesBySemantics;
    int ConfigureDevices;
};
#pragma pack(pop)