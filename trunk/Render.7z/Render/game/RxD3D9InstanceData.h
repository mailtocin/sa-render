/*
    SA::Render source file
    RxD3D9InstanceData structure
*/
#pragma once
#include "RenderWare.h"
#include "bool.h"

#pragma pack(push, 1)
struct RxD3D9InstanceData
{
    int numIndex;
    int minVert;
    RpMaterial *material;
    bool vertexAlpha;
    void *vertexShader;
    unsigned int baseIndex;
    unsigned int numVertices;
    unsigned int startIndex;
    unsigned int numPrimitives;
};
#pragma pack(pop)