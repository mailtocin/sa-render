/*
    SA::Render source file
    CPickupText structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CPickupText
{
    float x;
    float y;
    int field_8;
    float w;
    float h;
    RwRGBA color;
    char flags;
    char field_19;
    char __padding[2];
    int price;
    int textMessage;
};
#pragma pack(pop)