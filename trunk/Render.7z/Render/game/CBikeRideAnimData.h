/*
    SA::Render source file
    CBikeRideAnimData structure
*/
#pragma once

#pragma pack(push, 1)
struct CBikeRideAnimData
{
    unsigned int dword0;
    unsigned int dword4;
    unsigned int dword8;
    unsigned int dwordC;
    float dword10;
    float m_fHandlebarsAngle;
    unsigned int dword18;
};
#pragma pack(pop)