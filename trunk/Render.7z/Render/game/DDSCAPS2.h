/*
    SA::Render source file
    DDSCAPS2 structure
*/
#pragma once

#pragma pack(push, 1)
struct DDSCAPS2
{
    int dwCaps;
    int dwCaps2;
    int dwCaps3;
    int dwCaps4;
};
#pragma pack(pop)