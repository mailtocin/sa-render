/*
    SA::Render source file
    CMeshVertex structure
*/
#pragma once

#pragma pack(push, 1)
struct CMeshVertex
{
    short x;
    short y;
    short z;
};
#pragma pack(pop)