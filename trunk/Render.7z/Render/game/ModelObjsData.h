/*
    SA::Render source file
    ModelObjsData structure
*/
#pragma once
#include "CModelObjs.h"

#pragma pack(push, 1)
struct ModelObjsData
{
    int count;
    CModelObjs objects[14000];
};
#pragma pack(pop)