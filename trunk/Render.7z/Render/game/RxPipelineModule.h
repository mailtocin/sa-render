/*
    SA::Render source file
    RxPipelineModule structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RxPipelineModule
{
    int rxPipesFreeList;
    RxRenderStateVector vector;
    int field_30;
    int field_34;
    int maxNodes;
    int pPipeline;
    int field_40;
    int field_44;
    int field_48;
    int field_4C;
    int field_50;
    int field_54;
    int field_58;
    int field_5C;
};
#pragma pack(pop)