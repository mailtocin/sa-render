/*
    SA::Render source file
    CModelTobj structure
*/
#pragma once
#include "CBaseModelInfo.h"
#include "CModelTimeinfo.h"

#pragma pack(push, 1)
struct CModelTobj
{
    CBaseModelInfo __parent;
    CModelTimeinfo timeinfo;
};
#pragma pack(pop)