/*
    SA::Render source file
    RpGeometry structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpGeometry
{
    RwObject object;
    int flags;
    short lockedSinceLastInst;
    short refCount;
    int numTriangles;
    int numVertices;
    int numMorphTargets;
    int numTexCoordSets;
    RpMaterialList matList;
    int triangles;
    RwRGBA *preLitLum;
    int texCoords[8];
    RpMeshHeader *mesh;
    RwResEntry *resEntry;
    RpMorphTarget *morphTarget;
};
#pragma pack(pop)