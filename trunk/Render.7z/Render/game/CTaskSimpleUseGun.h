/*
    SA::Render source file
    CTaskSimpleUseGun structure
*/
#pragma once
#include "CTask.h"
#include "CEntity.h"
#include "RenderWare.h"
#include "CWeaponInfo.h"

#pragma pack(push, 1)
struct CTaskSimpleUseGun
{
    CTask __parent;
    char field_8;
    char field_9;
    char field_A;
    char field_B;
    char field_C;
    char m_cStateFlags;
    char field_E;
    char field_F;
    char field_10;
    char gap_11[3];
    int field_14;
    int field_18;
    CEntity *m_pEntity;
    RwV3D m_vTarget;
    int field_2C;
    CWeaponInfo *m_pWeaponInfo;
    short field_34;
    short field_36;
    char field_38;
    char field_39;
    char field_3A;
    char field_3B;
};
#pragma pack(pop)