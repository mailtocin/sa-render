/*
    SA::Render source file
    RwStreamFile structure
*/
#pragma once

#pragma pack(push, 1)
struct RwStreamFile
{
    int type;
    int accessType;
    int position;
    int fpFile;
    int field_10;
    int field_14;
    int field_18;
    int field_1C;
    int rwOwned;
};
#pragma pack(pop)