/*
    SA::Render source file
    _eh_funcinfo structure
*/
#pragma once

#pragma pack(push, 1)
struct _eh_funcinfo
{
    int magickNumber;
    int maxState;
    void *unwindMap;
    int nTryBlock;
    int pTryBlockMap;
    int nIPMapEntries;
    int pIPToStateMap;
};
#pragma pack(pop)