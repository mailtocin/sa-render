/*
    SA::Render source file
    CPedStats structure
*/
#pragma once

#pragma pack(push, 1)
struct CPedStats
{
    int nNum;
    char sName[24];
    int fFleeDistance;
    int fHeadingChangeRate;
    char bFear;
    char bTemper;
    char bLawfullness;
    char bSexiness;
    int fAttackStrenght;
    int fDefendWeakness;
    short wShootingRate;
    char bDecision;
    char field_33;
};
#pragma pack(pop)