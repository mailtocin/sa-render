/*
    SA::Render source file
    __m128i union
*/
#pragma once
