/*
    SA::Render source file
    CStencilShadowObject structure
*/
#pragma once
#include "CEntity.h"
#include "CStencilShadowObject.h"

#pragma pack(push, 1)
struct CStencilShadowObject
{
    CEntity *owner;
    short numShadowFaces;
    char type;
    char pad;
    unsigned int sizeOfShadowFacesData;
    unsigned int faceID;
    unsigned int shadowFacesData;
    CStencilShadowObject *next;
    CStencilShadowObject *prev;
};
#pragma pack(pop)