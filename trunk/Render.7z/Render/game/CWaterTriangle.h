/*
    SA::Render source file
    CWaterTriangle structure
*/
#pragma once

#pragma pack(push, 1)
struct CWaterTriangle
{
    short m_wFlags;
    char field_2[6];
};
#pragma pack(pop)