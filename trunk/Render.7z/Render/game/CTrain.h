/*
    SA::Render source file
    CTrain structure
*/
#pragma once
#include "CVehicle.h"
#include "CPed.h"
#include "CTrain.h"
#include "CAutomobileDoor.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct CTrain
{
    CVehicle _train;
    short m_sNodeIndex;
    char _pad1[2];
    float m_fCruiseSpeed;
    float m_fCurrentRailDistance;
    float m_fLength;
    int field_5B0;
    int field_5B4;
    char flags1;
    char m_cWreckedFlags;
    char field_5BA[2];
    int field_5BC;
    char m_cTrackId;
    char field_5C1;
    short field_5C2;
    int timeCreated;
    short field_5C8;
    char field_5CA;
    char m_cPassengerFlags;
    CPed *m_pPassenger;
    CTrain *m_pPrevCarriage;
    CTrain *m_pNextCarriage;
    CAutomobileDoor m_sDoor[6];
    RwFrame *m_pFrame[17];
};
#pragma pack(pop)