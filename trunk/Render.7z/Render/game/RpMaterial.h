/*
    SA::Render source file
    RpMaterial structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpMaterial
{
    RwTexture *texture;
    RwRGBA color;
    int pipeline;
    RwSurfaceProperties surfaceProps;
    short refCount;
    short pad;
};
#pragma pack(pop)