/*
    SA::Render source file
    CParticle structure
*/
#pragma once
#include "CFxSystem.h"
#include "RenderWare.h"
#include "CBoundingSphere.h"
#include "CParticlePrimData.h"

#pragma pack(push, 1)
struct CParticle
{
    int m_pNext;
    int m_pPrev;
    CFxSystem *m_pFxSystem;
    RwMatrix *m_pParentMatrix;
    RwMatrix m_mWorld;
    char status;
    char m_bDestroyAfterFinishing;
    char field_52;
    char field_53;
    int field_54;
    int m_fCameraDistance;
    short m_wBlackAmount;
    short m_wFrequency;
    short m_wSpeed;
    char flag;
    char field_63;
    float fUnkRandom;
    RwV3D m_vDirection;
    CBoundingSphere *m_pBoundingSphere;
    CParticlePrimData **m_pPrimsPtrList;
    int field_7C;
    int field_80;
    int field_84;
    int field_88;
    int field_8C;
    char field_90[112];
    int field_100;
};
#pragma pack(pop)