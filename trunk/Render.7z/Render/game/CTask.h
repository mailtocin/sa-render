/*
    SA::Render source file
    CTask structure
*/
#pragma once
#include "CTaskVMT.h"

#pragma pack(push, 1)
struct CTask
{
    CTaskVMT *vmt;
    int m_pParentTask;
};
#pragma pack(pop)