/*
    SA::Render source file
    CAudioWav structure
*/
#pragma once

#pragma pack(push, 1)
struct CAudioWav
{
    char field_0[32];
};
#pragma pack(pop)