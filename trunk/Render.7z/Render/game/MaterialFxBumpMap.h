/*
    SA::Render source file
    MaterialFxBumpMap structure
*/
#pragma once

#pragma pack(push, 1)
struct MaterialFxBumpMap
{
    unsigned int field_0;
    unsigned int texture1;
    unsigned int m_pBumpTexture;
    unsigned char fC[4];
    float float10;
    unsigned int dw14;
    unsigned int dw18;
};
#pragma pack(pop)