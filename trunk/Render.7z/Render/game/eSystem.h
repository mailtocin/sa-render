/*
    SA::Render source file
    eSystem enumeration
*/
#pragma once

enum eSystem
{
    NULL = 0x0,
};