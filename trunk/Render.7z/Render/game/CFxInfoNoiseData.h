/*
    SA::Render source file
    CFxInfoNoiseData structure
*/
#pragma once
#include "CFxInfoDataBase.h"
#include "CFxInfoNoiseDataInternal.h"

#pragma pack(push, 1)
struct CFxInfoNoiseData
{
    CFxInfoDataBase base;
    CFxInfoNoiseDataInternal internal;
};
#pragma pack(pop)