/*
    SA::Render source file
    RwTexCoords structure
*/
#pragma once

#pragma pack(push, 1)
struct RwTexCoords
{
    float u;
    float v;
};
#pragma pack(pop)