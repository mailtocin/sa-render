/*
    SA::Render source file
    _rwIm3DPoolStash structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct _rwIm3DPoolStash
{
    int flags;
    RwMatrix *ltm;
    int numVerts;
    RxObjSpace3dVertex *objVerts;
    RxCamSpace3DVertex *camVerts;
    RwD3D9Vertex *devVerts;
    RxMeshStateVector *meshState;
    RxRenderStateVector *renderState;
    RxPipeline *pipeline;
    int primType;
    short *indices;
    int numIndices;
};
#pragma pack(pop)