/*
    SA::Render source file
    CDummySound structure
*/
#pragma once
#include "CSound.h"

#pragma pack(push, 1)
struct CDummySound
{
    int field_0;
    CSound _;
};
#pragma pack(pop)