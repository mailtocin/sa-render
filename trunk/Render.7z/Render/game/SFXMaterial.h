/*
    SA::Render source file
    SFXMaterial structure
*/
#pragma once
#include "SFXEnvMapMaterial.h"

#pragma pack(push, 1)
struct SFXMaterial
{
    SFXEnvMapMaterial sEffect[2];
    int dwFlags;
};
#pragma pack(pop)