/*
    SA::Render source file
    CPedTaskAssignment structure
*/
#pragma once

#pragma pack(push, 1)
struct CPedTaskAssignment
{
    int nTaskId;
    int field_4;
    int field_8;
    int pPed;
    int _status;
};
#pragma pack(pop)