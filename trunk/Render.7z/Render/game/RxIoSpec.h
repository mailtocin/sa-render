/*
    SA::Render source file
    RxIoSpec structure
*/
#pragma once

#pragma pack(push, 1)
struct RxIoSpec
{
    int numClustersOfInterest;
    int clustersOfInterest;
    int inputRequirements;
    int numOutputs;
    int outputs;
};
#pragma pack(pop)