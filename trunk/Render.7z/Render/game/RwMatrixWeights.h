/*
    SA::Render source file
    RwMatrixWeights structure
*/
#pragma once

#pragma pack(push, 1)
struct RwMatrixWeights
{
    float w0;
    float w1;
    float w2;
    float w3;
};
#pragma pack(pop)