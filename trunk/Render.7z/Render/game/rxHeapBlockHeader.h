/*
    SA::Render source file
    rxHeapBlockHeader structure
*/
#pragma once

#pragma pack(push, 1)
struct rxHeapBlockHeader
{
    int prev;
    int next;
    int size;
    int freeEntry;
    int _pad[4];
};
#pragma pack(pop)