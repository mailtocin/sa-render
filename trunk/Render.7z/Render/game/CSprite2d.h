/*
    SA::Render source file
    CSprite2d structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CSprite2d
{
    RwTexture *texture;
};
#pragma pack(pop)