/*
    SA::Render source file
    CBulletTrack structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CBulletTrack
{
    RwV3D TransSide;
    RwV3D YellowSide;
    char ExistFlag;
    char pad1;
    char pad2;
    char pad3;
    int createdTime;
    int disappearTime;
    int Radius;
    char alpha;
    char pad4;
    char pad5;
    char pad6;
};
#pragma pack(pop)