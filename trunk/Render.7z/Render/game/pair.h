/*
    SA::Render source file
    pair structure
*/
#pragma once

#pragma pack(push, 1)
struct pair
{
    int keycode;
    int priority;
};
#pragma pack(pop)