/*
    SA::Render source file
    d3d_obj1 structure
*/
#pragma once

#pragma pack(push, 1)
struct d3d_obj1
{
    int field_0;
    int field_4;
    int field_8;
    int field_C;
    int field_10;
    int field_14;
    int field_18;
};
#pragma pack(pop)