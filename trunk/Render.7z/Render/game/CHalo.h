/*
    SA::Render source file
    CHalo structure
*/
#pragma once

#pragma pack(push, 1)
struct CHalo
{
    float DistanceToScreenCenter;
    int Size;
    short red;
    short green;
    short blue;
    short alpha;
    int numVertices?;
};
#pragma pack(pop)