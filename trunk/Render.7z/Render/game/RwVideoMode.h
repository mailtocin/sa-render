/*
    SA::Render source file
    RwVideoMode structure
*/
#pragma once

#pragma pack(push, 1)
struct RwVideoMode
{
    int width;
    int height;
    int depth;
    int flag;
    int refRate;
    int format;
};
#pragma pack(pop)