/*
    SA::Render source file
    RpSkinHeader structure
*/
#pragma once

#pragma pack(push, 1)
struct RpSkinHeader
{
    char numBones;
    char numBoneIds;
    short maxNumWeightsPerVertex;
};
#pragma pack(pop)