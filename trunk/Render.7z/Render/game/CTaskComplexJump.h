/*
    SA::Render source file
    CTaskComplexJump structure
*/
#pragma once
#include "CTaskComplex.h"

#pragma pack(push, 1)
struct CTaskComplexJump
{
    CTaskComplex __parent;
    int field_C;
    char field_10;
    char field_11[3];
};
#pragma pack(pop)