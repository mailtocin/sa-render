/*
    SA::Render source file
    IDirect3D9 structure
*/
#pragma once
#include "IDirect3D9Vtbl.h"

#pragma pack(push, 1)
struct IDirect3D9
{
    IDirect3D9Vtbl *lpVtbl;
};
#pragma pack(pop)