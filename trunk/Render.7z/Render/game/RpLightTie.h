/*
    SA::Render source file
    RpLightTie structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpLightTie
{
    RwLLLink lightInWorldSector;
    int light;
    RwLLLink worldSectorInLight;
    int sect;
};
#pragma pack(pop)