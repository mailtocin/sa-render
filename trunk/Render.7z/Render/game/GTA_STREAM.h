/*
    SA::Render source file
    GTA_STREAM structure
*/
#pragma once
#include "OVERLAPPED.h"

#pragma pack(push, 1)
struct GTA_STREAM
{
    int nSectorOffset;
    int nSectorsToRead;
    int lpBuffer;
    char field_C;
    char bLocked;
    char bInUse;
    char field_F;
    int status;
    int hSemaphore;
    int hFile;
    OVERLAPPED overlapped;
};
#pragma pack(pop)