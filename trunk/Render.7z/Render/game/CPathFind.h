/*
    SA::Render source file
    CPathFind structure
*/
#pragma once
#include "CNodeInfo.h"
#include "CPathNode.h"
#include "CNaviNode.h"
#include "CForbiddenArea.h"

#pragma pack(push, 1)
struct CPathFind
{
    CNodeInfo info;
    int field_4[512];
    CPathNode *pNodes[72];
    CNaviNode *pNaviNodes[72];
    CNodeInfo *pLinks[72];
    unsigned char *pLinkLengths[72];
    void *pSection7[72];
    unsigned short *pNaviLinks[72];
    char field_EC4[224];
    int NumNodes[72];
    int NumVehicleNodes[72];
    int NumPedNodes[72];
    int NumNaviNodes[72];
    int NumLinks[72];
    int field_1544[2048];
    int field_3544;
    char char3548[32];
    unsigned int m_dwNumForbiddenAreas;
    CForbiddenArea m_aForbiddenAreas[64];
    unsigned char m_bForbiddenForScriptedCarsEnabled;
    char _padding[3];
    float m_fForbiddenForScrCarsX1;
    float m_fForbiddenForScrCarsX2;
    float m_fForbiddenForScrCarsY1;
    float m_fForbiddenForScrCarsY2;
};
#pragma pack(pop)