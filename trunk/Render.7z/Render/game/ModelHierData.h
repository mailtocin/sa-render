/*
    SA::Render source file
    ModelHierData structure
*/
#pragma once
#include "CModelHier.h"

#pragma pack(push, 1)
struct ModelHierData
{
    int count;
    CModelHier objects[92];
};
#pragma pack(pop)