/*
    SA::Render source file
    eBlipType enumeration
*/
#pragma once

enum eBlipType
{
    BLIP_CAR = 1,
    BLIP_CHAR = 2,
    BLIP_OBJECT = 3,
    BLIP_COORD = 4,
    BLIP_CONTACT_POINT = 5,
};