/*
    SA::Render source file
    RxPipelineNodeParam structure
*/
#pragma once

#pragma pack(push, 1)
struct RxPipelineNodeParam
{
    int dataParam;
    int heap;
};
#pragma pack(pop)