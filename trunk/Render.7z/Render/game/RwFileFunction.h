/*
    SA::Render source file
    RwFileFunction structure
*/
#pragma once

#pragma pack(push, 1)
struct RwFileFunction
{
    int (__cdecl;
    int (__cdecl;
    int rwfclose;
    int rwfread;
    int rwfwrite;
    int rwfgets;
    int field_18;
    int rwfeof;
    int (__cdecl;
    int field_24;
    int (__cdecl;
};
#pragma pack(pop)