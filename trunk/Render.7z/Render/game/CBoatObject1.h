/*
    SA::Render source file
    CBoatObject1 structure
*/
#pragma once

#pragma pack(push, 1)
struct CBoatObject1
{
    float field_0;
    float field_4;
    short field_8;
    char field_A[14];
};
#pragma pack(pop)