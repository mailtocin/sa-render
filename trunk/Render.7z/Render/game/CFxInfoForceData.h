/*
    SA::Render source file
    CFxInfoForceData structure
*/
#pragma once
#include "CFxInfoDataBase.h"
#include "CFxInfoForceDataInternal.h"

#pragma pack(push, 1)
struct CFxInfoForceData
{
    CFxInfoDataBase base;
    CFxInfoForceDataInternal internal;
};
#pragma pack(pop)