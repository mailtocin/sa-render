/*
    SA::Render source file
    CModelTimeinfo structure
*/
#pragma once

#pragma pack(push, 1)
struct CModelTimeinfo
{
    char timeOn;
    char timeOff;
    short pairedModel;
};
#pragma pack(pop)