/*
    SA::Render source file
    MACRO_CS_VREDRAW enumeration
*/
#pragma once

enum MACRO_CS_VREDRAW
{
    CS_VREDRAW = 0x1,
    CS_HREDRAW = 0x2,
    CS_DBLCLKS = 0x8,
    CS_OWNDC = 0x20,
    CS_CLASSDC = 0x40,
    CS_PARENTDC = 0x80,
    CS_NOCLOSE = 0x200,
    CS_SAVEBITS = 0x800,
    CS_BYTEALIGNCLIENT = 0x1000,
    CS_BYTEALIGNWINDOW = 0x2000,
    CS_GLOBALCLASS = 0x4000,
    CS_IME = 0x10000,
};