/*
    SA::Render source file
    HudTextures structure
*/
#pragma once

#pragma pack(push, 1)
struct HudTextures
{
    int empty1;
    int empty2;
    int radar_centre;
    int arrow;
    int radar_north;
    int radar_airYard;
    int radar_ammugun;
    int radar_barbers;
    int radar_BIGSMOKE;
    int radar_boatyard;
    int radar_burgerShot;
    int radar_bulldozer;
    int radar_CATALINAPINK;
    int radar_CESARVIAPANDO;
    int radar_chicken;
    int radar_CJ;
    int radar_CRASH1;
    int radar_diner;
    int radar_emmetGun;
    int radar_enemyAttack;
    int radar_fire;
    int radar_girlfriend;
    int radar_hospitaL;
    int radar_LocoSyndicate;
    int radar_MADDOG;
    int radar_mafiaCasino;
    int radar_MCSTRAP;
    int radar_modGarage;
    int radar_OGLOC;
    int radar_pizza;
    int radar_police;
    int radar_propertyG;
    int radar_propertyR;
    int radar_race;
    int radar_RYDER;
    int radar_saveGame;
    int radar_school;
    int radar_qmark;
    int radar_SWEET;
    int radar_tattoo;
    int radar_THETRUTH;
    int radar_waypoint;
    int radar_TorenoRanch;
    int radar_triads;
    int radar_triadsCasino;
    int radar_tshirt;
    int radar_WOOZIE;
    int radar_ZERO;
    int radar_dateDisco;
    int radar_dateDrink;
    int radar_dateFood;
    int radar_truck;
    int radar_cash;
    int radar_flag;
    int radar_gym;
    int radar_impound;
    int radar_light;
    int radar_runway;
    int radar_gangB;
    int radar_gangP;
    int radar_gangY;
    int radar_gangN;
    int radar_gangG;
    int radar_spray;
};
#pragma pack(pop)