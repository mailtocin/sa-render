/*
    SA::Render source file
    CExternalScriptInfo structure
*/
#pragma once

#pragma pack(push, 1)
struct CExternalScriptInfo
{
    void *data;
    char status;
    char field_5;
    short wScmIndex;
    char name[20];
    int size;
};
#pragma pack(pop)