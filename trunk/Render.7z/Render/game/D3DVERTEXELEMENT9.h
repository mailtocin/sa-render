/*
    SA::Render source file
    D3DVERTEXELEMENT9 structure
*/
#pragma once

#pragma pack(push, 1)
struct D3DVERTEXELEMENT9
{
    unsigned short Stream;
    unsigned short Offset;
    char Type;
    char Method;
    char Usage;
    char UsageIndex;
};
#pragma pack(pop)