/*
    SA::Render source file
    c2dfx_rwStream structure
*/
#pragma once

#pragma pack(push, 1)
struct c2dfx_rwStream
{
    unsigned int color;
    float coronaFarClip;
    float pointlightRange;
    float coronaSize;
    float shadowSize;
    char coronaFlashType;
    char coronaEnableReflection;
    char coronaFlareType;
    char shadowColorMultiplier;
    char flags1;
    char coronaName[24];
    char shadowName[24];
    char shadowZDistance;
    char flags2;
    char offsetX;
    char offsetY;
    char offsetZ;
    char __pad[2];
};
#pragma pack(pop)