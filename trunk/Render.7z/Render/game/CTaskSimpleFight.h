/*
    SA::Render source file
    CTaskSimpleFight structure
*/
#pragma once
#include "CTask.h"

#pragma pack(push, 1)
struct CTaskSimpleFight
{
    CTask __parent;
    char field_8;
    char field_9;
    char field_A;
    char gap_B[1];
    int m_dwIfpIndex;
    short m_dwTime;
    short field_12;
    char field_14;
    char field_15;
    char gap_16[2];
    int m_pEntity;
    int field_1C;
    int field_20;
    char field_24;
    char field_25;
    char _paramA3;
    char field_27;
};
#pragma pack(pop)