/*
    SA::Render source file
    MaterialStructStream structure
*/
#pragma once

#pragma pack(push, 1)
struct MaterialStructStream
{
    int field_0;
    int color;
    int field_8;
    int numTextures;
    float ambient;
    float specular;
    float diffuse;
};
#pragma pack(pop)