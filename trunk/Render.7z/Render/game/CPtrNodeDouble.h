/*
    SA::Render source file
    CPtrNodeDouble structure
*/
#pragma once
#include "CEntity.h"

#pragma pack(push, 1)
struct CPtrNodeDouble
{
    CEntity *ptr;
    int next;
    int prev;
};
#pragma pack(pop)