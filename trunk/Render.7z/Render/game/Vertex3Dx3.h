/*
    SA::Render source file
    Vertex3Dx3 structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct Vertex3Dx3
{
    RwV3D vector1;
    RwV3D vector2;
    RwV3D vector3;
};
#pragma pack(pop)