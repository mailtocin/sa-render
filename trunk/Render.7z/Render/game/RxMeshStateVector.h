/*
    SA::Render source file
    RxMeshStateVector structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RxMeshStateVector
{
    int Flags;
    void *SourceObject;
    RwMatrix Obj2World;
    RwMatrix Obj2Cam;
    RwSurfaceProperties SurfaceProperties;
    RwTexture *Texture;
    RwRGBA MatCol;
    RxPipeline *Pipeline;
    int PrimType;
    unsigned int NumElements;
    unsigned int NumVertices;
    int ClipFlagsOr;
    int ClipFlagsAnd;
    void *SourceMesh;
    void *DataObject;
};
#pragma pack(pop)