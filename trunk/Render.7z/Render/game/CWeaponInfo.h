/*
    SA::Render source file
    CWeaponInfo structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CWeaponInfo
{
    int m_eFireType;
    int targetRange;
    float m_fWeaponRange;
    int dwModelId1;
    int dwModelId2;
    int nSlot;
    int flags;
    int AssocGroupId;
    short ammoClip;
    short damage;
    RwV3D fireOffset;
    int skillLevel;
    int reqStatLevelToGetThisWeaponSkilLevel;
    float m_fAccuracy;
    float moveSpeed;
    float animLoopStart;
    float animLoopEnd;
    int animLoopFire;
    int animLoop2Start;
    int animLoop2End;
    int animLoop2Fire;
    int breakoutTime;
    int speed;
    int radius;
    int lifespan;
    int spread;
    char AssocGroupId2;
    char field_6D;
    char baseCombo;
    char m_nNumCombos;
};
#pragma pack(pop)