/*
    SA::Render source file
    C2dfx structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct C2dfx
{
    RwV3D offset;
    int type;
};
#pragma pack(pop)