/*
    SA::Render source file
    HudTextures2 structure
*/
#pragma once

#pragma pack(push, 1)
struct HudTextures2
{
    int fist;
    int siteM16;
    int siterocket;
    int radardisc;
    int radarRingPlane;
    int skipIcon;
};
#pragma pack(pop)