/*
    SA::Render source file
    RwSurfaceProperties structure
*/
#pragma once

#pragma pack(push, 1)
struct RwSurfaceProperties
{
    float ambient;
    unsigned int flags;
    float diffuse;
};
#pragma pack(pop)