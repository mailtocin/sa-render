/*
    SA::Render source file
    CEffect9 structure
*/
#pragma once
#include "RenderWare.h"
#include "CEntity.h"

#pragma pack(push, 1)
struct CEffect9
{
    char entityType;
    char field_1;
    char field_2;
    char __pad;
    RwV3D pos;
    CEntity *entity;
    CEntity *entityReference;
    int field_18;
};
#pragma pack(pop)