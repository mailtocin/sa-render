/*
    SA::Render source file
    CPedAttractor structure
*/
#pragma once
#include "CEffect2d.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct CPedAttractor
{
    CEffect2d effect;
    RwV3D direction[3];
    unsigned char m_cEventType;
    unsigned char pedExistingProbability;
    char unknown34;
    char flags;
    char m_acExternalScript[8];
};
#pragma pack(pop)