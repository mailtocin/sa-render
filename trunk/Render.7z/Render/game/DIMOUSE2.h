/*
    SA::Render source file
    DIMOUSE2 structure
*/
#pragma once

#pragma pack(push, 1)
struct DIMOUSE2
{
    int lX;
    int lY;
    int lZ;
    char buttons[8];
};
#pragma pack(pop)