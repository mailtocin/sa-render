/*
    SA::Render source file
    CTaskSimpleCarSlowDragPedOut structure
*/
#pragma once
#include "CTask.h"
#include "CObject.h"

#pragma pack(push, 1)
struct CTaskSimpleCarSlowDragPedOut
{
    CTask char0;
    unsigned char byte8;
    unsigned char f9[3];
    unsigned int dwordC;
    CObject *m_pEntity;
    unsigned int dword14;
    unsigned int dword18;
    unsigned char byte1C;
    char _padding[3];
};
#pragma pack(pop)