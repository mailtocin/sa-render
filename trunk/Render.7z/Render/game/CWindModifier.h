/*
    SA::Render source file
    CWindModifier structure
*/
#pragma once

#pragma pack(push, 1)
struct CWindModifier
{
    int field_0;
    int field_4;
    int field_8;
    int field_C;
    int field_10;
};
#pragma pack(pop)