/*
    SA::Render source file
    RpHAnimNodeInfo structure
*/
#pragma once

#pragma pack(push, 1)
struct RpHAnimNodeInfo
{
    int nodeID;
    int nodeIndex;
    int flags;
    int pFrame;
};
#pragma pack(pop)