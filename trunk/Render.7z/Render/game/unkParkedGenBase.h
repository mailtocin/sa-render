/*
    SA::Render source file
    unkParkedGenBase structure
*/
#pragma once
#include "parkedGenText.h"

#pragma pack(push, 1)
struct unkParkedGenBase
{
    parkedGenText texts[15];
    int count;
};
#pragma pack(pop)