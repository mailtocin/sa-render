/*
    SA::Render source file
    struc_B1E128 structure
*/
#pragma once
#include "obj_85BCF0.h"

#pragma pack(push, 1)
struct struc_B1E128
{
    int count;
    obj_85BCF0 objects;
};
#pragma pack(pop)