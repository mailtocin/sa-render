/*
    SA::Render source file
    CHandlingBoat structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CHandlingBoat
{
    int index;
    int thrustY;
    int thrustZ;
    int thrustAppZ;
    int aqPlaneForce;
    int aqPlaneLimit;
    int aqPlaneOffset;
    int waveAudioMult;
    int look_L_R_BehindCamHeight;
    RwV3D moveRes;
    RwV3D turnRes;
};
#pragma pack(pop)