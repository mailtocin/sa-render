/*
    SA::Render source file
    CCullZoneReflection structure
*/
#pragma once
#include "CCullZoneBase.h"

#pragma pack(push, 1)
struct CCullZoneReflection
{
    CCullZoneBase __parent;
    int cm;
    char vx;
    char vy;
    char vz;
    char flags;
};
#pragma pack(pop)