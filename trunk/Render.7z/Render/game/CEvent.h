/*
    SA::Render source file
    CEvent structure
*/
#pragma once

#pragma pack(push, 1)
struct CEvent
{
    int __vmt__;
    int field_4;
    char field_8;
    char field_9;
    char field_A;
    char field_B;
    char field_C;
    char field_D;
    short field_E;
    short field_10;
    short field_12;
    int field_14;
    int field_18;
    int field_1C;
    int field_20;
    int field_24;
    int field_28;
    int field_2C;
    char field_30;
    char field_31;
    char field_32;
    char field_33;
    int field_34;
    int field_38;
    int field_3C;
    char field_40;
    char field_41;
    char field_42;
    char field_43;
};
#pragma pack(pop)