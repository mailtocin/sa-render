/*
    SA::Render source file
    CEntityParticle structure
*/
#pragma once
#include "CLink.h"
#include "CParticle.h"
#include "CEntity.h"

#pragma pack(push, 1)
struct CEntityParticle
{
    CLink link;
    CParticle *particle;
    CEntity *entity;
};
#pragma pack(pop)