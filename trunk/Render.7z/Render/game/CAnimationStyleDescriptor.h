/*
    SA::Render source file
    CAnimationStyleDescriptor structure
*/
#pragma once

#pragma pack(push, 1)
struct CAnimationStyleDescriptor
{
    char name[16];
    char ?baseName[16];
    int field_20;
    int nameCount;
    void *namesPtr;
    void *dataPtr;
};
#pragma pack(pop)