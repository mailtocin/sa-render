/*
    SA::Render source file
    RsKeyStatus structure
*/
#pragma once

#pragma pack(push, 1)
struct RsKeyStatus
{
    int keyScanCode;
    int keyCharCode;
};
#pragma pack(pop)