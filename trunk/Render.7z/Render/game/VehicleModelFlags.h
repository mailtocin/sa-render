/*
    SA::Render source file
    VehicleModelFlags enumeration
*/
#pragma once

enum VehicleModelFlags
{
    IS_VAN = 0x1,
    IS_BUS = 0x2,
    IS_BIG = 0x4,
    IS_LOW = 0x8,
};