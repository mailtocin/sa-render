/*
    SA::Render source file
    RpClump structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpClump
{
    RwObject object;
    RwLinkList atomicList;
    RwLinkList lightList;
    RwLinkList cameraList;
    RwLLLink inWorldLink;
    int callback;
};
#pragma pack(pop)