/*
    SA::Render source file
    MACRO_SPIF_SENDCHANGE enumeration
*/
#pragma once

enum MACRO_SPIF_SENDCHANGE
{
    SPIF_SENDCHANGE = 2,
    METRICS_USEDEFAULT = -1,
};