/*
    SA::Render source file
    RpMesh structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpMesh
{
    unsigned short *indices;
    int numIndices;
    RpMaterial *material;
};
#pragma pack(pop)