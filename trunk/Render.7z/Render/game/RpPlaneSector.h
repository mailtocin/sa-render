/*
    SA::Render source file
    RpPlaneSector structure
*/
#pragma once

#pragma pack(push, 1)
struct RpPlaneSector
{
    int type;
    float value;
    int leftSubTree;
    int rightSubTree;
    float leftValue;
    float rightValue;
};
#pragma pack(pop)