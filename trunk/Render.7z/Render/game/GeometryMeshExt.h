/*
    SA::Render source file
    GeometryMeshExt structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct GeometryMeshExt
{
    unsigned int m_uiPosRule;
    unsigned short m_usNumVertices;
    short _pad0;
    RwV3D *m_pVertexPos;
    RwTexCoords *m_pTexCoors;
    RwRGBA *m_pVertexColors;
    unsigned short m_usNumTriangles;
    short _pad1;
    RpTriangle *m_pTriangles;
    unsigned short *m_pMaterialAssignments;
    unsigned short m_usNumMaterials;
    short _pad2;
    RwTexture **m_pTextures;
    char *m_pTextureNames;
    char *m_pMaskNames;
    RwSurfaceProperties *m_pMaterialProperties;
};
#pragma pack(pop)