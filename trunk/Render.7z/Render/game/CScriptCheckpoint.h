/*
    SA::Render source file
    CScriptCheckpoint structure
*/
#pragma once

#pragma pack(push, 1)
struct CScriptCheckpoint
{
    char bUsed;
    char field_1;
    short wUniqueID;
    int field_4;
};
#pragma pack(pop)