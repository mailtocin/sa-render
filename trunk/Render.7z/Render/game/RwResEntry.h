/*
    SA::Render source file
    RwResEntry structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwResEntry
{
    RwLLLink link;
    int size;
    int owner;
    int ownerRef;
    int destroyNotify;
    RxD3D9ResEntryHeader header;
    RxD3D9InstanceData meshData;
};
#pragma pack(pop)