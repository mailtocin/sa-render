/*
    SA::Render source file
    RxCamSpace3DVertex structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RxCamSpace3DVertex
{
    RwV3D cameraVertex;
    char clipFlags;
    char pad[3];
    RwRGBAReal col;
    float u;
    float v;
};
#pragma pack(pop)