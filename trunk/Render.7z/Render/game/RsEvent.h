/*
    SA::Render source file
    RsEvent enumeration
*/
#pragma once

enum RsEvent
{
    rsCAMERASIZE = 0x0,
    rsCOMMANDLINE = 0x1,
    rsFILELOAD = 0x2,
    rsINPUTDEVICEATTACH = 0x4,
    rsPLUGINATTACH = 0x9,
    rsRWINITIALIZE = 0x15,
    rsRWTERMINATE = 0x16,
    rsSELECTDEVICE = 0x17,
    rsINITIALIZE = 0x18,
    rsTERMINATE = 0x19,
    rsIDLE = 0x1A,
    rsRENDER = 0x1B,
    rsKEYDOWN = 0x1C,
    rsKEYUP = 0x1D,
    rsQUITAPP = 0x1E,
    rsPADBUTTONDOWN = 0x1F,
    rsPADBUTTONUP = 0x20,
    rsPREINITCOMMANDLINE = 0x25,
    rsACTIVATE = 0x26,
};