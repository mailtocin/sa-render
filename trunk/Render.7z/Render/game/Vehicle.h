/*
    SA::Render source file
    Vehicle enumeration
*/
#pragma once

enum Vehicle Struct Offsets
{
    GUN_INDEX = 0xD,
};