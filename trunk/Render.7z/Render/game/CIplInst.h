/*
    SA::Render source file
    CIplInst structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CIplInst
{
    RwV3D position;
    RtQuat rotation;
    int modelID;
    int interiorID;
    int lod;
};
#pragma pack(pop)