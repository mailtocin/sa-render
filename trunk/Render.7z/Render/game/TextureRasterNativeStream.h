/*
    SA::Render source file
    TextureRasterNativeStream structure
*/
#pragma once

#pragma pack(push, 1)
struct TextureRasterNativeStream
{
    int rasterFormat;
    int d3d9Format;
    unsigned short width;
    unsigned short height;
    unsigned char stride;
    char mipMapCount;
    unsigned char rasterType;
    char creationFlags;
};
#pragma pack(pop)