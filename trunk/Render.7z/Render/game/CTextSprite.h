/*
    SA::Render source file
    CTextSprite structure
*/
#pragma once

#pragma pack(push, 1)
struct CTextSprite
{
    int type;
    char field_4;
    char field_5;
    short textureID;
    int cornerA_X;
    int cornerA_Y;
    int cornerB_X;
    int cornerB_Y;
    int angle;
    int transparentColor;
    char gxt[8];
    int field_28;
    int field_2C;
    int field_30;
    int field_34;
    char textboxStyle;
    char field_39[3];
};
#pragma pack(pop)