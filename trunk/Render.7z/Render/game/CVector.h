/*
    SA::Render source file
    CVector structure
*/
#pragma once
#include "RenderWare.h"
typedef RwV3d CVector;