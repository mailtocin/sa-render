/*
    SA::Render source file
    RwResources structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwResources
{
    int maxSize;
    int currentSize;
    int reusageSize;
    int memHeap;
    RwLinkList entriesA;
    RwLinkList entriesB;
    int freeEntries;
    int usedEntries;
};
#pragma pack(pop)