/*
    SA::Render source file
    CColSphere structure
*/
#pragma once
#include "RenderWare.h"
#include "CColSurface.h"

#pragma pack(push, 1)
struct CColSphere
{
    RwSphere sphere;
    CColSurface surface;
};
#pragma pack(pop)