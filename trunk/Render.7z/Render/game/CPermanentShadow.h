/*
    SA::Render source file
    CPermanentShadow structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CPermanentShadow
{
    RwV3D pos;
    float X1;
    float Y1;
    float X2;
    float Y2;
    float zDistance;
    float scale;
    int timeCreated;
    int timeDuration;
    RwTexture *texture;
    short intensity;
    char type;
    char red;
    char green;
    char blue;
    short flags;
};
#pragma pack(pop)