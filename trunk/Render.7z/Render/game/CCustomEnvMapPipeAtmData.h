/*
    SA::Render source file
    CCustomEnvMapPipeAtmData structure
*/
#pragma once

struct CCustomEnvMapPipeAtmData
{
    unsigned int dword0;
    unsigned int dword4;
    unsigned int dword8;
};