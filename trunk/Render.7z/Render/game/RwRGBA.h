/*
    SA::Render source file
    RwRGBA structure
*/
#pragma once

#pragma pack(push, 1)
struct RwRGBA
{
    unsigned char red;
    unsigned char green;
    unsigned char blue;
    unsigned char alpha;
};
#pragma pack(pop)