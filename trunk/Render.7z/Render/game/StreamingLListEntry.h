/*
    SA::Render source file
    StreamingLListEntry structure
*/
#pragma once

#pragma pack(push, 1)
struct StreamingLListEntry
{
    int field_0;
    int pPrev;
    int pNext;
};
#pragma pack(pop)