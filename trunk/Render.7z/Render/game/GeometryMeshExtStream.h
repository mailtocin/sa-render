/*
    SA::Render source file
    GeometryMeshExtStream structure
*/
#pragma once

#pragma pack(push, 1)
struct GeometryMeshExtStream
{
    int Always1;
    unsigned short VertexCount;
    short _pad1;
    int pVertices;
    int pTexCoors;
    int pVertexColors;
    unsigned short FaceCount;
    short _pad2;
    int pTriangles;
    int pMaterialAssignments;
    unsigned short MaterialCount;
    short _pad3;
    int pTextures;
    int pTextureNames;
    int pMaskNames;
    int pMaterialProperties;
};
#pragma pack(pop)