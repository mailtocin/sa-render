/*
    SA::Render source file
    TextureInfoStream structure
*/
#pragma once

#pragma pack(push, 1)
struct TextureInfoStream
{
    char textureFilterMode;
    char uvAddressing;
    char hasMipMaps;
    char __pad;
};
#pragma pack(pop)