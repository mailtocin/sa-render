/*
    SA::Render source file
    floats enumeration
*/
#pragma once

enum floats
{
    f1_0 = 0x3F800000,
};