/*
    SA::Render source file
    CPedEventList structure
*/
#pragma once

#pragma pack(push, 1)
struct CPedEventList
{
    int eventIds[96];
};
#pragma pack(pop)