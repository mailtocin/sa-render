/*
    SA::Render source file
    RpLight structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpLight
{
    RwObjectHasFrame object;
    int radius;
    RwRGBAReal color;
    int minusCosAngle;
    RwLinkList WorldSectorsInLight;
    RwLLLink inWorld;
    int lightFrame;
};
#pragma pack(pop)