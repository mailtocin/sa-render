/*
    SA::Render source file
    CTaskComplexSequence structure
*/
#pragma once

#pragma pack(push, 1)
struct CTaskComplexSequence
{
    int __vmt__;
    int field_4;
    int field_8;
    int field_C;
    int field_10[8];
    int field_30;
    int field_34;
    char field_38;
    char field_39;
    char field_3A;
    char field_3B;
    int field_3C;
};
#pragma pack(pop)