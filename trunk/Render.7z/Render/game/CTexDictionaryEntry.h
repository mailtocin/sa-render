/*
    SA::Render source file
    CTexDictionaryEntry structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CTexDictionaryEntry
{
    RwTexDictionary *dictionary;
    short usageCount;
    short parentIndex;
    int hash;
};
#pragma pack(pop)