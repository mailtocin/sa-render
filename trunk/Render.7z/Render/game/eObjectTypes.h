/*
    SA::Render source file
    eObjectTypes enumeration
*/
#pragma once

enum eObjectTypes
{
    OBJECT_TYPE_FLYING_COMPONENT = 0x3,
    OBJECT_TYPE_CUTSCENE = 0x4,
    OBJECT_TYPE_HAND = 0x5,
};