/*
    SA::Render source file
    CMenuItem structure
*/
#pragma once
#include "CEntryData.h"

#pragma pack(push, 1)
struct CMenuItem
{
    char name[8];
    char field_8;
    char field_9;
    CEntryData entryList[12];
};
#pragma pack(pop)