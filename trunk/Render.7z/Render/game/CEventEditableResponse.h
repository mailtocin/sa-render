/*
    SA::Render source file
    CEventEditableResponse structure
*/
#pragma once

#pragma pack(push, 1)
struct CEventEditableResponse
{
    unsigned int vmt;
    unsigned int dword4;
    unsigned char byte8;
    unsigned char f9[3];
    unsigned char byteC;
    unsigned char fD[1];
    unsigned short wordE;
    unsigned short word10;
    short field_12;
};
#pragma pack(pop)