/*
    SA::Render source file
    CStreamRepeatSector structure
*/
#pragma once

#pragma pack(push, 1)
struct CStreamRepeatSector
{
    int pEntities1;
    int pEntities2;
    int pEntities3;
};
#pragma pack(pop)