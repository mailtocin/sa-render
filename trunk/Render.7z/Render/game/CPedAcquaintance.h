/*
    SA::Render source file
    CPedAcquaintance structure
*/
#pragma once

#pragma pack(push, 1)
struct CPedAcquaintance
{
    int respect;
    int like;
    int field_8;
    int dislike;
    int hate;
};
#pragma pack(pop)