/*
    SA::Render source file
    RwRasterModule structure
*/
#pragma once

#pragma pack(push, 1)
struct RwRasterModule
{
    int field_0;
    int field_4;
    int field_8;
    int field_C;
    int field_10;
    int field_14;
    int field_18;
    int field_1C;
    int field_20;
    int field_24;
    int currentContext;
    int field_2C;
    int field_30;
    int field_34;
    int field_38;
    int field_3C;
    int field_40;
    int field_44;
    int field_48;
    char field_4C;
    char field_4D;
    char field_4E;
    char field_4F;
    int field_50;
    int field_54;
    int field_58;
    int field_5C;
    int rasterFreeList;
};
#pragma pack(pop)