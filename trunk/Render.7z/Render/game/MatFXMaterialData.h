/*
    SA::Render source file
    MatFXMaterialData structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct MatFXMaterialData
{
    RpMatFxDualPass m_Fx[2];
};
#pragma pack(pop)