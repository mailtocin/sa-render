/*
    SA::Render source file
    RxD3D9VertexStream structure
*/
#pragma once
#include "IDirect3DVertexBuffer9.h"

#pragma pack(push, 1)
struct RxD3D9VertexStream
{
    IDirect3DVertexBuffer9 *vertexBuffer;
    int offset;
    int stride;
    short geometryFlags;
    char managed;
    char dynamicLock;
};
#pragma pack(pop)