/*
    SA::Render source file
    CAudioFileQT structure
*/
#pragma once
#include "CAudioFile.h"

#pragma pack(push, 1)
struct CAudioFileQT
{
    CAudioFile __parent;
    int field_8;
    char field_C;
    char field_D;
    char field_E;
    char field_F;
    int field_10;
    int field_14;
    int field_18;
    int field_1C[7];
    int field_38;
    int field_3C;
    short field_40;
    short field_42;
    int field_44;
    int field_48;
    int field_4C;
    int field_50;
    int field_54;
    int field_58;
    int field_5C;
    int field_60;
    int field_64;
    int field_68;
    int field_6C;
    int field_70;
    int field_74;
    int field_78;
    int field_7C;
    int field_80;
    int field_84;
    int field_88;
    int field_8C;
    int field_90;
    int field_94;
    int field_98;
    int field_9C;
    int field_A0;
    int field_A4;
    int field_A8;
    char field_AC;
    char field_AD;
    char field_AE;
    char field_AF;
    int field_B0;
    int field_B4;
    int field_B8;
    int field_BC;
    int field_C0;
};
#pragma pack(pop)