/*
    SA::Render source file
    RwStreamAccessType enumeration
*/
#pragma once

enum RwStreamAccessType
{
    rwNASTREAMACCESS = 0x0,
    rwSTREAMREAD = 0x1,
    rwSTREAMWRITE = 0x2,
    rwSTREAMAPPEND = 0x3,
};