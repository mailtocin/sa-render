/*
    SA::Render source file
    ColFileHeader structure
*/
#pragma once

#pragma pack(push, 1)
struct ColFileHeader
{
    int fourcc;
    int dataSize;
    char modelname[20];
    int _unused;
};
#pragma pack(pop)