/*
    SA::Render source file
    _eh_unwindmapentry structure
*/
#pragma once

#pragma pack(push, 1)
struct _eh_unwindmapentry
{
    int toState;
    void *action;
};
#pragma pack(pop)