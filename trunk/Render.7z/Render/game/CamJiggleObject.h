/*
    SA::Render source file
    CamJiggleObject structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CamJiggleObject
{
    RwV3D field_0;
    RwV3D field_C;
    RwV3D field_18;
    RwV3D field_24;
    RwV3D field_30;
    RwMatrix field_3C;
    int field_7C;
    int field_80;
    int field_84;
    int field_88;
    int field_8C;
    int field_90;
};
#pragma pack(pop)