/*
    SA::Render source file
    ColModel_COL3 structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct ColModel_COL3
{
    RwV3D min;
    RwV3D max;
    RwV3D center;
    int radius;
    short numberOfSpheres;
    short numberOfBoxes;
    int numberOfFaces;
    int flags;
    int offsetSpheres;
    int offsetBoxes;
    int offsetSuspensionLines;
    int offsetMeshVertices;
    int offsetMeshFaces;
    int offset2;
    int numberOfShadowMeshFaces;
    int offsetShadowMeshVertices;
    int offsetShadowMeshFaces;
};
#pragma pack(pop)