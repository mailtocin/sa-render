/*
    SA::Render source file
    RwFreeList structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwFreeList
{
    int entrySize;
    int entriesPerBlock;
    int heapSize;
    int alignment;
    RwLinkList blockList;
    int flags;
    RwLLLink link;
};
#pragma pack(pop)