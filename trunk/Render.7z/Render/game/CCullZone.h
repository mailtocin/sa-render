/*
    SA::Render source file
    CCullZone structure
*/
#pragma once
#include "CCullZoneBase.h"

#pragma pack(push, 1)
struct CCullZone
{
    CCullZoneBase __parent;
    short flags;
};
#pragma pack(pop)