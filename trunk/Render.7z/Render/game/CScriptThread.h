/*
    SA::Render source file
    CScriptThread structure
*/
#pragma once

#pragma pack(push, 1)
struct CScriptThread
{
    int next;
    int prev;
    char threadName[8];
    int baseIp;
    int _ip;
    int stack[8];
    short _sp;
    short field_3A;
    int _tls[34];
    char isActive;
    char condResult;
    char field_C6;
    char external;
    char field_C8;
    char field_C9;
    char field_CA;
    char field_CB;
    int wakeTime;
    short logicalOp;
    char notFlag;
    char wastedBustedCheckEnabled;
    char wastedOrBusted;
    char field_D5;
    short field_D6;
    int ?sceneSkip;
    char field_DC;
    char field_DD;
    char field_DE;
    char field_DF;
};
#pragma pack(pop)