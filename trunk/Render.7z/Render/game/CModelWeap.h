/*
    SA::Render source file
    CModelWeap structure
*/
#pragma once
#include "CModelHier.h"

#pragma pack(push, 1)
struct CModelWeap
{
    CModelHier __parent;
    short field_24;
    short field_26;
};
#pragma pack(pop)