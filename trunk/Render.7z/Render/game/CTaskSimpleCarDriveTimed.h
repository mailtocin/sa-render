/*
    SA::Render source file
    CTaskSimpleCarDriveTimed structure
*/
#pragma once
#include "CTaskSimpleDriveCar.h"
#include "CAiTimer.h"

#pragma pack(push, 1)
struct CTaskSimpleCarDriveTimed
{
    CTaskSimpleDriveCar __parent;
    char gap_5d[3];
    int field_60;
    CAiTimer field_64;
};
#pragma pack(pop)