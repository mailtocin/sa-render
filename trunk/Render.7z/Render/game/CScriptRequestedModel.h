/*
    SA::Render source file
    CScriptRequestedModel structure
*/
#pragma once

#pragma pack(push, 1)
struct CScriptRequestedModel
{
    char szModelName[24];
    int dwModelIndex;
};
#pragma pack(pop)