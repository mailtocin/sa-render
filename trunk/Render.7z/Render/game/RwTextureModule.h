/*
    SA::Render source file
    RwTextureModule structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwTextureModule
{
    RwLLLink txdList;
    int textureFreeList;
    int texDictFreeList;
    int currentTxd;
    int readCB;
    int findCB;
    int enableMipmapping;
    int autoMipmapping;
    int field_24;
    int field_28;
    int rasterBuildMipmapCB;
    int mipmapNameCB;
};
#pragma pack(pop)