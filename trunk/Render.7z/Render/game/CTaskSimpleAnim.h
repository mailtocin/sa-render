/*
    SA::Render source file
    CTaskSimpleAnim structure
*/
#pragma once
#include "CTask.h"

#pragma pack(push, 1)
struct CTaskSimpleAnim
{
    CTask __parent;
    int field_8;
    char field_C;
    char field_D[3];
};
#pragma pack(pop)