/*
    SA::Render source file
    CImgDescriptor structure
*/
#pragma once

#pragma pack(push, 1)
struct CImgDescriptor
{
    char name[40];
    char isNotPlayerImg;
    char __align[3];
    int streamHandle;
};
#pragma pack(pop)