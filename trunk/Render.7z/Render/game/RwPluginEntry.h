/*
    SA::Render source file
    RwPluginEntry structure
*/
#pragma once

#pragma pack(push, 1)
struct RwPluginEntry
{
    int offset;
    int size;
    int pluginID;
    int readCB;
    int writeCB;
    int getSizeCB;
    int alwaysCB;
    int rightsCB;
    int constructCB;
    int destructCB;
    int copyCB;
    int errStrCB;
    int nextRegEntry;
    int prevRegEntry;
    int parentRegistry;
};
#pragma pack(pop)