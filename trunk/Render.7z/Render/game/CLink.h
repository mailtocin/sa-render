/*
    SA::Render source file
    CLink structure
*/
#pragma once

#pragma pack(push, 1)
struct CLink
{
    void *next;
    void *prev;
};
#pragma pack(pop)