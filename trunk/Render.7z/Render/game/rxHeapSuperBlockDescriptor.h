/*
    SA::Render source file
    rxHeapSuperBlockDescriptor structure
*/
#pragma once

#pragma pack(push, 1)
struct rxHeapSuperBlockDescriptor
{
    int start;
    int size;
    int next;
};
#pragma pack(pop)