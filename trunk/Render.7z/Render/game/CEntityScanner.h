/*
    SA::Render source file
    CEntityScanner structure
*/
#pragma once

#pragma pack(push, 1)
struct CEntityScanner
{
    int __vmt;
    int field_4;
    int m_dwCount;
    int m_apEntities[16];
    int field_4C;
};
#pragma pack(pop)