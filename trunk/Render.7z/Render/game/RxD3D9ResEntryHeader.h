/*
    SA::Render source file
    RxD3D9ResEntryHeader structure
*/
#pragma once
#include "RenderWare.h"
#include "bool.h"

#pragma pack(push, 1)
struct RxD3D9ResEntryHeader
{
    int serialNumber;
    unsigned int numMeshes;
    void *indexBuffer;
    int primType;
    RxD3D9VertexStream vertexStream[2];
    bool useOffsets;
    void *vertexDeclaration;
    int totalNumIndex;
    int totalNumVertex;
};
#pragma pack(pop)