/*
    SA::Render source file
    PadData structure
*/
#pragma once

#pragma pack(push, 1)
struct PadData
{
    short field_0;
    short field_2;
    short field_4;
    short field_6;
    short field_8;
    short field_A;
    short field_C;
    short field_E;
    short field_10;
    short field_12;
    short field_14;
    short field_16;
    short field_18;
    short field_1A;
    short field_1C;
    short field_1E;
    short field_20;
    short field_22;
    short field_24;
    short field_26;
    short field_28;
    short field_2A;
    short field_2C;
    short field_2E;
};
#pragma pack(pop)