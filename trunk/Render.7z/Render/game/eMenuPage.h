/*
    SA::Render source file
    eMenuPage enumeration
*/
#pragma once

enum eMenuPage
{
    MENUPAGE_MAP = 0x5,
};