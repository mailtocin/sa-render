/*
    SA::Render source file
    struct_v7_1 structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct struct_v7_1
{
    unsigned char m_bJustFaces;
    unsigned char byte1;
    unsigned char m_dwSparksOnImpact;
    unsigned char byte3;
    int numObjects;
    int field_8;
    unsigned int dwordC;
    unsigned int pointZ;
    RwV3D normal;
};
#pragma pack(pop)