/*
    SA::Render source file
    CHeliLight structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CHeliLight
{
    RwV3D startPoint;
    RwV3D targetPoint;
    float targetRadius;
    float shadowIntensity;
    int coronaIndex;
    char unkFlag;
    char bDrawShadow;
    short ?pad;
    RwV3D unkData[3];
};
#pragma pack(pop)