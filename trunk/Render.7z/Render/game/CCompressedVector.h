/*
    SA::Render source file
    CCompressedVector structure
*/
#pragma once

#pragma pack(push, 1)
struct CCompressedVector
{
    short x;
    short y;
    short z;
};
#pragma pack(pop)