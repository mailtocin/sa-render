/*
    SA::Render source file
    RsGlobalType structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RsGlobalType
{
    void *AppName;
    int MaximumWidth;
    int MaximumHeight;
    int frameLimit;
    int quit;
    int ps;
    RsInputDevice keyboard;
    RsInputDevice mouse;
    RsInputDevice pad;
};
#pragma pack(pop)