/*
    SA::Render source file
    RpMaterialList structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RpMaterialList
{
    RpMaterial **materials;
    int numMaterials;
    int space;
};
#pragma pack(pop)