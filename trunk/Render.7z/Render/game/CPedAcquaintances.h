/*
    SA::Render source file
    CPedAcquaintances structure
*/
#pragma once
#include "CPedAcquaintance.h"

#pragma pack(push, 1)
struct CPedAcquaintances
{
    int count;
    CPedAcquaintance objects[32];
};
#pragma pack(pop)