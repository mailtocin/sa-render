/*
    SA::Render source file
    CZoneExtraInfo structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CZoneExtraInfo
{
    char field_0;
    char field_1;
    char field_2;
    char field_3;
    int field_4;
    short field_8;
    char pedgroupWealth;
    RwRGBA color;
    char field_F;
    char field_10;
};
#pragma pack(pop)