/*
    SA::Render source file
    CPedEvent_DM_EventData structure
*/
#pragma once

#pragma pack(push, 1)
struct CPedEvent_DM_EventData
{
    int field_0[6];
    char field_18;
    char field_19;
    char field_1A;
    char field_1B;
    int field_1C[4];
    int field_2C;
    char field_30;
    char field_31;
    short field_32[4];
    short field_3A;
};
#pragma pack(pop)