/*
    SA::Render source file
    C2dfxInfoStore structure
*/
#pragma once
#include "C2dfxLight.h"

#pragma pack(push, 1)
struct C2dfxInfoStore
{
    int m_dwCount;
    C2dfxLight m_Objects[100];
};
#pragma pack(pop)