/*
    SA::Render source file
    EffectTypes enumeration
*/
#pragma once

enum EffectTypes
{
    EFFECT_LIGHT = 0x0,
    EFFECT_PARTICLE = 0x1,
    EFFECT_PEDS = 0x3,
    EFFECT_SUN_FLARE = 0x4,
    EFFECT_FURNITUR = 0x5,
    EFFECT_ENEX = 0x6,
    EFFECT_ROADSIGN = 0x7,
    EFFECT_SLOTMACHINE_WHEEL = 0x8,
    EFFECT_9 = 0x9,
    EFFECT_ESCALATOR = 0xA,
};