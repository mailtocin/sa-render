/*
    SA::Render source file
    CAnimBlendAssocGroup structure
*/
#pragma once

#pragma pack(push, 1)
struct CAnimBlendAssocGroup
{
    int pAnimBlock;
    int ppAssociations;
    int iNumAnimations;
    int iIDOffset;
    int groupID;
};
#pragma pack(pop)