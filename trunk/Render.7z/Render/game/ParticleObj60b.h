/*
    SA::Render source file
    ParticleObj60b structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct ParticleObj60b
{
    unsigned int vmt;
    unsigned char f4[4];
    float float8;
    unsigned int dwordC;
    RwV3D dword10;
    RwV3D m_vDirection;
    unsigned int m_pParticle;
    unsigned char byte2C;
    unsigned char byte2D;
    unsigned char byte2E;
    unsigned char byte2F;
    unsigned char byte30;
    unsigned char byte31;
    unsigned char byte32;
    unsigned char byte33;
    unsigned char byte34;
    unsigned char byte35;
    unsigned char byte36;
    unsigned char byte37;
    float float38;
};
#pragma pack(pop)