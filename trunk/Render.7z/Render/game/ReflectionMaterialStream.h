/*
    SA::Render source file
    ReflectionMaterialStream structure
*/
#pragma once

#pragma pack(push, 1)
struct ReflectionMaterialStream
{
    float transform[4];
    float intensity;
    int texture;
};
#pragma pack(pop)