/*
    SA::Render source file
    RendererInList structure
*/
#pragma once
#include "AtomicRenderer.h"
#include "AtomicRendererLink.h"

#pragma pack(push, 1)
struct RendererInList
{
    AtomicRenderer renderer;
    AtomicRendererLink link;
};
#pragma pack(pop)