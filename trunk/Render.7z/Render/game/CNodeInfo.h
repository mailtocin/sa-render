/*
    SA::Render source file
    CNodeInfo structure
*/
#pragma once

#pragma pack(push, 1)
struct CNodeInfo
{
    short areaId;
    short nodeId;
};
#pragma pack(pop)