/*
    SA::Render source file
    CTriggerEntity structure
*/
#pragma once

#pragma pack(push, 1)
struct CTriggerEntity
{
    int entity;
    short index;
    short __pad;
};
#pragma pack(pop)