/*
    SA::Render source file
    ColSphere1 structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct ColSphere1
{
    int radius;
    RwV3D center;
    char material;
    char flag;
    char field_12;
    char _f2;
};
#pragma pack(pop)