/*
    SA::Render source file
    CFxPrimEmitterData_VMT structure
*/
#pragma once

#pragma pack(push, 1)
struct CFxPrimEmitterData_VMT
{
    int ScalarDestructor;
    char (__thiscall;
    char (__thiscall;
    int CreateParticlePrimData;
    int field_10;
    int field_14;
};
#pragma pack(pop)