/*
    SA::Render source file
    RwRasterType enumeration
*/
#pragma once

enum RwRasterType
{
    rwRASTERTYPENORMAL = 0x0,
    rwRASTERTYPEZBUFFER = 0x1,
    rwRASTERTYPECAMERA = 0x2,
    rwRASTERTYPETEXTURE = 0x4,
    rwRASTERTYPECAMERATEXTURE = 0x5,
    rwRASTERTYPEMASK = 0x7,
    rwRASTERPALETTEVOLATILE = 0x40,
    rwRASTERDONTALLOCATE = 0x80,
};