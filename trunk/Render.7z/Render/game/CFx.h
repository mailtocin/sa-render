/*
    SA::Render source file
    CFx structure
*/
#pragma once
#include "CParticle.h"
#include "CParticleData__LListHead.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct CFx
{
    CParticle *prt_blood;
    CParticle *prt_boatsplash;
    CParticle *prt_bubble;
    CParticle *prt_cardebris;
    CParticle *prt_collisionsmoke;
    CParticle *prt_gunshell;
    CParticle *prt_sand;
    CParticle *prt_sand2;
    CParticle *prt_smoke_huge;
    CParticle *prt_smokeII_3_expand;
    CParticle *prt_spark;
    CParticle *prt_spark_2;
    CParticle *prt_splash;
    CParticle *prt_wake;
    CParticle *prt_watersplash;
    CParticle *prt_wheeldirt;
    CParticle *prt_glass;
    CParticleData__LListHead entityParticlesList;
    int numCreatedBloodPools;
    int visualFxQuality;
    int verticesCount2;
    int verticesCount;
    int transformRenderFlags;
    RwRaster *pRasterToRender;
    RwMatrix *transformLTM;
    int pVerts;
};
#pragma pack(pop)