/*
    SA::Render source file
    CColSurface structure
*/
#pragma once

#pragma pack(push, 1)
struct CColSurface
{
    char material;
    char flag;
    char lighting;
    char light;
};
#pragma pack(pop)