/*
    SA::Render source file
    OVERLAPPED structure
*/
#pragma once

#pragma pack(push, 1)
struct OVERLAPPED
{
    int Internal;
    int InternalHigh;
    int Offset;
    int OffetHigh;
    int hEvent;
};
#pragma pack(pop)