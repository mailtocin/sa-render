/*
    SA::Render source file
    CEventSoundQuiet structure
*/
#pragma once
#include "CEventEditableResponse.h"
#include "CEntity.h"
#include "CVector.h"

#pragma pack(push, 1)
struct CEventSoundQuiet
{
    CEventEditableResponse parent;
    CEntity *m_pEntity;
    float dword18;
    unsigned int m_dwStartTime;
    CVector m_vPosition;
};
#pragma pack(pop)