/*
    SA::Render source file
    RwPlane structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwPlane
{
    RwV3D normal;
    int distance;
};
#pragma pack(pop)