/*
    SA::Render source file
    RwDevice structure
*/
#pragma once

#pragma pack(push, 1)
struct RwDevice
{
    int gammaCorrection;
    int fpSystem;
    float zBufferNear;
    float zBufferFar;
    int (__cdecl;
    int (__cdecl;
    int (*fpIm2DRenderLine)(void);
    int (*fpIm2DRenderTriangle)(void);
    int (*fpIm2DRenderPrimitive)(void);
    int (*fpIm2DRenderIndexedPrimitive)(void);
    void *fpIm3DRenderLine;
    void *fpIm3DRenderTriangle;
    void *fpIm3DRenderPrimitive;
    void *fpIm3DRenderIndexedPrimitive;
};
#pragma pack(pop)