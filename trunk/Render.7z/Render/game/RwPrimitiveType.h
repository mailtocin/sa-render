/*
    SA::Render source file
    RwPrimitiveType enumeration
*/
#pragma once

enum RwPrimitiveType
{
    rwPRIMTYPENAPRIMTYPE = 0x0,
    rwPRIMTYPELINELIST = 0x1,
    rwPRIMTYPEPOLYLINE = 0x2,
    rwPRIMTYPETRILIST = 0x3,
    rwPRIMTYPETRISTRIP = 0x4,
    rwPRIMTYPETRIFAN = 0x5,
    rwPRIMTYPEPOINTLIST = 0x6,
};