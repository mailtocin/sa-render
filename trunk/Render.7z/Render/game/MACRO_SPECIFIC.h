/*
    SA::Render source file
    MACRO_SPECIFIC enumeration
*/
#pragma once

enum MACRO_SPECIFIC
{
    SPECIFIC_RIGHTS_ALL = 0xFFFF,
    ACCESS_SYSTEM_SECURITY = 0x1000000,
    MAXIMUM_ALLOWED = 0x2000000,
    GENERIC_READ = 0x80000000,
};