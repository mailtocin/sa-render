/*
    SA::Render source file
    CMissionCleanupList structure
*/
#pragma once
#include "CMissionCleanup.h"

#pragma pack(push, 1)
struct CMissionCleanupList
{
    CMissionCleanup objects[75];
    char count;
};
#pragma pack(pop)