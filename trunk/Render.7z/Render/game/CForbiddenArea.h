/*
    SA::Render source file
    CForbiddenArea structure
*/
#pragma once

#pragma pack(push, 1)
struct CForbiddenArea
{
    float x1;
    float x2;
    float y1;
    float y2;
    float z1;
    float z2;
    char bEnable;
    char type;
    char _padding[2];
};
#pragma pack(pop)