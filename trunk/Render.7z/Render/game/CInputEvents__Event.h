/*
    SA::Render source file
    CInputEvents__Event structure
*/
#pragma once
#include "pair.h"

#pragma pack(push, 1)
struct CInputEvents__Event
{
    pair data[4];
};
#pragma pack(pop)