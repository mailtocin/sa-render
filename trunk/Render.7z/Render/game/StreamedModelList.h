/*
    SA::Render source file
    StreamedModelList structure
*/
#pragma once
#include "StreamingLListEntry.h"

#pragma pack(push, 1)
struct StreamedModelList
{
    StreamingLListEntry usedListHead;
    StreamingLListEntry usedListTail;
    StreamingLListEntry freeListHead;
    StreamingLListEntry freeListTail;
    int pEntries;
};
#pragma pack(pop)