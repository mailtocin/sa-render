/*
    SA::Render source file
    CMouseState structure
*/
#pragma once

#pragma pack(push, 1)
struct CMouseState
{
    char lmb;
    char rmb;
    char mmb;
    char wheelUp;
    char wheelDown;
    char bmx1;
    char bmx2;
    char __align;
    int Z;
    int X;
    int Y;
};
#pragma pack(pop)