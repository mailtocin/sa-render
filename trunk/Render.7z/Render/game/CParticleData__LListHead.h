/*
    SA::Render source file
    CParticleData__LListHead structure
*/
#pragma once
#include "CFxSystem.h"

#pragma pack(push, 1)
struct CParticleData__LListHead
{
    CFxSystem *last;
    int first;
    int count;
};
#pragma pack(pop)