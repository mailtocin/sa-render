/*
    SA::Render source file
    CWaterVertex structure
*/
#pragma once

#pragma pack(push, 1)
struct CWaterVertex
{
    short m_sX;
    short m_sY;
    float m_fZ;
    float m_fUnknown;
    float m_fHeight;
    char m_cFlowX;
    char m_cFlowY;
    short m_wPadding;
};
#pragma pack(pop)