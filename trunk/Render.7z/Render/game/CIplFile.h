/*
    SA::Render source file
    CIplFile structure
*/
#pragma once

#pragma pack(push, 1)
struct CIplFile
{
    int field_0;
    int field_4;
    int field_8;
    int field_C;
    char name[16];
    short field_20;
    short field_22;
    short field_24;
    short field_26;
    short field_28;
    short iplId;
    char field_2C;
    char field_2D;
    char field_2E;
    char field_2F;
    char field_30;
    char field_31;
    char field_32;
    char field_33;
};
#pragma pack(pop)