/*
    SA::Render source file
    CFire structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CFire
{
    char flags;
    char field_1;
    short index;
    RwV3D position;
    int attachedTo;
    int creator;
    int m_dwDissappearTime;
    float m_fSize;
    char nNumGenerationsAllowed;
    char field_21;
    short field_22;
    int m_pParticle;
};
#pragma pack(pop)