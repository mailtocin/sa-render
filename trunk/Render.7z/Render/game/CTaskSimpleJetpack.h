/*
    SA::Render source file
    CTaskSimpleJetpack structure
*/
#pragma once
#include "RenderWare.h"
#include "CObject.h"

#pragma pack(push, 1)
struct CTaskSimpleJetpack
{
    void *dword0;
    unsigned char f4[4];
    unsigned char byte8;
    unsigned char byte9;
    unsigned char byteA;
    unsigned char byteB;
    unsigned char byteC;
    unsigned char byteD;
    unsigned char byteE;
    unsigned char fF[1];
    unsigned int dword10;
    unsigned int dword14;
    float dword18;
    unsigned int dword1C;
    unsigned int dword20;
    unsigned int dword24;
    unsigned int dword28;
    unsigned int dword2C;
    unsigned int dword30;
    unsigned int dword34;
    unsigned int dword38;
    float dword3C;
    RpClump *jetpackObject;
    unsigned int dword44;
    RwV3D dword48;
    unsigned int dword54;
    unsigned int dword58;
    unsigned int dword5C;
    CObject *pcobject60;
    unsigned int particleA;
    unsigned int particleB;
    float m_fParticleIntensity;
};
#pragma pack(pop)