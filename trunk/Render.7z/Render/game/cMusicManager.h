/*
    SA::Render source file
    cMusicManager structure
*/
#pragma once
#include "unkRadio2C.h"

#pragma pack(push, 1)
struct cMusicManager
{
    char f0;
    char field_1;
    char field_2;
    char field_3;
    unsigned char byte4;
    unsigned char byte5;
    unsigned char byte6;
    unsigned char byte7;
    unsigned char f8[14];
    unsigned char byte16;
    unsigned char byte17;
    int m_PlayerStats[14];
    unsigned int dword50;
    unsigned int m_dwTimeToDisplayRadioName;
    unsigned int dword58;
    unsigned int dword5C;
    unsigned int dword60;
    int f64;
    int field_68;
    unsigned int m_nStationsListed;
    unsigned int m_nStationsListDown;
    unsigned int dword74;
    unsigned int dword78;
    unsigned int dword7C;
    unsigned int dword80;
    unsigned int dword84;
    char char88;
    unsigned char f89[19];
    unsigned int dword9C;
    unsigned int dwordA0;
    unsigned int dwordA4;
    unsigned int dwordA8;
    unsigned char byteAC;
    unsigned char m_nCurrentRadioStation;
    unsigned char byteAE;
    unsigned char fAF[10];
    unsigned char byteB9;
    unsigned char byteBA;
    unsigned char fBB[5];
    unsigned char byteC0;
    unsigned char byteC1;
    unsigned char fC2[2];
    char charC4;
    char fC5;
    char gap_C6[24];
    char field_DE;
    char gap_DF[9];
    char field_E8;
    char m_nRadioStationState;
    char gap_EA[2];
    int field_EC;
    char field_F0;
    char gap_F1[1];
    char field_F2;
    char gap_F3[5];
    char field_F8;
    char gap_F9[15];
    char field_108;
    char gap_109[3];
    unkRadio2C field_10C[13];
    char field_348[32];
    unsigned int dword368;
    unsigned char byte36C;
};
#pragma pack(pop)