/*
    SA::Render source file
    RwSphere structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct RwSphere
{
    RwV3D center;
    float radius;
};
#pragma pack(pop)