/*
    SA::Render source file
    eBlipDisplay enumeration
*/
#pragma once

enum eBlipDisplay
{
    eBlipDisplay_0 = 0,
};