/*
    SA::Render source file
    CBoundingSphere structure
*/
#pragma once
#include "RenderWare.h"

#pragma pack(push, 1)
struct CBoundingSphere
{
    RwSphere sphere;
    int field_10;
};
#pragma pack(pop)