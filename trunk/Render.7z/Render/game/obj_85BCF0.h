/*
    SA::Render source file
    obj_85BCF0 structure
*/
#pragma once
#include "CBaseModelInfo.h"

#pragma pack(push, 1)
struct obj_85BCF0
{
    CBaseModelInfo __parent;
    short field_20;
    short field_22;
    short field_24;
    short field_26;
};
#pragma pack(pop)