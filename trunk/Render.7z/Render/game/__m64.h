/*
    SA::Render source file
    __m64 union
*/
#pragma once
