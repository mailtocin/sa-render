/*
    SA::Render source file
    CPedGroups structure
*/
#pragma once

#pragma pack(push, 1)
struct CPedGroups
{
    short m_awUniqueID[8];
    char m_abUsed[8];
};
#pragma pack(pop)