/*
    SA::Render source file
    WSADATA structure
*/
#pragma once

#pragma pack(push, 1)
struct WSADATA
{
    short wVersion;
    short wHighVersion;
    short iMaxSockets;
    short iMaxUdpDg;
    void *lpVendorInfo;
    char szDescription[257];
    char szSystemStatus[129];
    char _padding[2];
};
#pragma pack(pop)