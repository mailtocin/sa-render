/*
    SA::Render source file
    RGBword structure
*/
#pragma once

#pragma pack(push, 1)
struct RGBword
{
    short red;
    short green;
    short blue;
};
#pragma pack(pop)