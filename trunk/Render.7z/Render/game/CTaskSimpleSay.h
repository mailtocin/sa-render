/*
    SA::Render source file
    CTaskSimpleSay structure
*/
#pragma once
#include "CTask.h"
#include "CAiTimer.h"

#pragma pack(push, 1)
struct CTaskSimpleSay
{
    CTask __parent;
    int m_dwAudioId;
    int m_nTime;
    CAiTimer field_10;
};
#pragma pack(pop)