/*
    SA::Render source file
    obj_85BC70 structure
*/
#pragma once
#include "CBaseModelInfo.h"

#pragma pack(push, 1)
struct obj_85BC70
{
    CBaseModelInfo __parent;
    short field_20;
    short field_22;
};
#pragma pack(pop)