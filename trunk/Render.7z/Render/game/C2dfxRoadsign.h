/*
    SA::Render source file
    C2dfxRoadsign structure
*/
#pragma once
#include "C2dfx.h"
#include "RenderWare.h"

#pragma pack(push, 1)
struct C2dfxRoadsign
{
    C2dfx base;
    RwV2D size;
    RwV3D rotation;
    short flags;
    short __pad;
    char *text;
    RpAtomic *object;
};
#pragma pack(pop)