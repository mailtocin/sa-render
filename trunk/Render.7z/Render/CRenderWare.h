/********************************SA::Render source file*************************************/
/* File creator: DK22Pac                                                                   */
/* File editors: DK22Pac                                                                   */
/* File descrip: RenderWare structures/enumerations/functions/defines are represented here.*/
/* File created: 17.04.2013                                                                */
/* File last ed: 27.04.2013                                                                */
/*******************************************************************************************/
#pragma once

#ifndef _RW
#define _RW

#ifndef _IDA_EXPORT
#include <stdarg.h>
#include <d3dx9.h>
#endif
// defines
#define RWFORCEENUMSIZEINT ((int)((~((unsigned int)0))>>1))
#define RWRGBALONG(r,g,b,a) ((unsigned int) (((a) << 24) | ((r) << 16) | ((g) << 8) | (b)))
#define MAKECHUNKID(vendorID, chunkID) (((vendorID & 0xFFFFFF) << 8) | (chunkID & 0xFF))
#define GETOBJECTID(chunkID) (chunkID & 0xFF)
#define GETVENDORID(chunkID) ((chunkID >> 8) & 0xFFFFFF)
#define rwRASTERLOCKREADWRITE   (rwRASTERLOCKREAD|rwRASTERLOCKWRITE)
#define rwRASTERPIXELLOCKED     (rwRASTERPIXELLOCKEDREAD | rwRASTERPIXELLOCKEDWRITE)
#define rwRASTERPALETTELOCKED   (rwRASTERPALETTELOCKEDREAD | rwRASTERPALETTELOCKEDWRITE)
#define rwRASTERLOCKED          (rwRASTERPIXELLOCKED|rwRASTERPALETTELOCKED)
#define rwTEXTUREFILTERMODEMASK     0x000000FF
#define rwTEXTUREADDRESSINGUMASK    0x00000F00
#define rwTEXTUREADDRESSINGVMASK    0x0000F000
#define rwTEXTUREADDRESSINGMASK     (rwTEXTUREADDRESSINGUMASK | rwTEXTUREADDRESSINGVMASK)
#define rpLIGHTPOSITIONINGSTART 0x80
#define rtANIMGETINTERPFRAME( anim, nodeIndex ) ((void *)(((unsigned char *)&(anim[1]) + ((nodeIndex) * anim->currentInterpKeyFrameSize))))
#define rpHANIMPOPPARENTMATRIX      0x01
#define rpHANIMPUSHPARENTMATRIX     0x02
#define rpATOMIC 1
#define rpCLUMP 2
#define rpWORLD 7
// structures
typedef struct RwV2d RwV2d;
typedef struct RwV3d RwV3d;
typedef struct RwRect RwRect;
typedef struct RwSphere RwSphere;
typedef struct RwLine RwLine;
typedef struct RwTexCoords RwTexCoords;
typedef struct RwSLLink RwSLLink;
typedef struct RwSingleList RwSingleList;
typedef struct RwLLLink  RwLLLink;
typedef struct RwLinkList RwLinkList;
typedef struct RwSurfaceProperties RwSurfaceProperties;
typedef struct RwPlane RwPlane;
typedef struct RwObject RwObject;
typedef struct RwMemoryFunctions RwMemoryFunctions;
typedef struct RwFreeList RwFreeList;
typedef struct RwStreamMemory RwStreamMemory;
typedef struct RwStreamCustom RwStreamCustom;
typedef struct RwStream RwStream;
typedef struct RwMemory RwMemory;
typedef struct RwStringFunctions RwStringFunctions;
typedef struct RwMatrix RwMatrix;
typedef struct RwD3D9Vertex RwD3D9Vertex;
typedef struct RwDevice RwDevice;
typedef struct RwGlobals RwGlobals;
typedef struct RwMetrics RwMetrics;
typedef struct RwResEntry RwResEntry;
typedef struct RwRGBAReal RwRGBAReal;
typedef struct RwRGBA RwRGBA;
typedef struct RwChunkHeaderInfo RwChunkHeaderInfo;
typedef struct RxPipeline RxPipeline;
typedef struct RwRaster RwRaster;
typedef struct RxObjSpace3DVertex RxObjSpace3DVertex;
typedef struct RwImage RwImage;
typedef struct RwTexDictionary RwTexDictionary;
typedef struct RwTexture RwTexture;
typedef struct RxD3D9VertexStream RxD3D9VertexStream;
typedef struct RwFrame RwFrame;
typedef struct RpHAnimFrameExtension RpHAnimFrameExtension;
typedef struct RwBBox RwBBox;
typedef struct RwFrustumPlane RwFrustumPlane;
typedef struct RwObjectHasFrame RwObjectHasFrame;
typedef struct RwCamera RwCamera;
typedef struct RxD3D9ResEntryHeader RxD3D9ResEntryHeader;
typedef struct RxD3D9InstanceData RxD3D9InstanceData;
typedef struct RpMaterial RpMaterial;
typedef struct RpUVAnimMaterial RpUVAnimMaterial;
typedef struct RpMatFx RpMatFx;
typedef struct EnvMapFx EnvMapFx;
typedef struct RpMaterialList RpMaterialList;
typedef struct RpMeshHeader RpMeshHeader;
typedef struct RpMesh RpMesh;
typedef struct RpGeometry RpGeometry;
typedef struct RpMorphTarget RpMorphTarget;
typedef struct RpTriangle RpTriangle;
typedef struct RwMatrixWeights RwMatrixWeights;
typedef struct RpSkin RpSkin;
typedef struct RpLight RpLight;
typedef struct RpD3D9AttenuationParams RpD3D9AttenuationParams;
typedef struct RpAtomic RpAtomic;
typedef struct RpInterpolator RpInterpolator;
typedef struct RpClump RpClump;
typedef struct RtQuat RtQuat;
typedef struct RtAnimAnimation RtAnimAnimation;
typedef struct RtAnimInterpolatorInfo RtAnimInterpolatorInfo;
typedef struct RtAnimKeyFrameHeader RtAnimKeyFrameHeader;
typedef struct RtAnimInterpFrameHeader RtAnimInterpFrameHeader;
typedef struct RtAnimInterpolator RtAnimInterpolator;
typedef struct RpHAnimKeyFrame RpHAnimKeyFrame;
typedef struct RpHAnimInterpFrame RpHAnimInterpFrame;
typedef struct RpHAnimHierarchy RpHAnimHierarchy;
typedef struct RpHAnimNodeInfo RpHAnimNodeInfo;
typedef struct RpVertexNormal RpVertexNormal;
typedef struct RpWorldSector RpWorldSector;
typedef struct RpWorld RpWorld;
typedef struct RpSector RpSector;
typedef struct RxD3D9ResEntryHeader RxD3D9ResEntryHeader;
typedef struct RxD3D9InstanceData RxD3D9InstanceData;
typedef struct CPlaceable CPlaceable;
// classes
#ifndef _IDA_EXPORT
typedef class CEnvMapMaterial CEnvMapMaterial;
typedef class CSpecularMaterial CSpecularMaterial;
typedef class CNightVertexColors CNightVertexColors;
typedef class CBreakableGeometry CBreakableGeometry;
typedef class CHAnimIFrame CHAnimIFrame;
typedef class CBone CBone;
typedef class C2dfxStore C2dfxStore;
typedef class CHAnim CHAnim;
typedef class CClumpVisibility CClumpVisibility;
typedef class CXEnvMapInfo CXEnvMapInfo;
typedef class CAtomicVisibility CAtomicVisibility;
#endif
// unions
typedef union RwStreamFile RwStreamFile;
typedef union RwStreamUnion RwStreamUnion;
// enums
#ifndef _IDA_EXPORT
typedef enum RwTextureCoordinateIndex RwTextureCoordinateIndex;
typedef enum RwPlaneType RwPlaneType;
typedef enum RwPluginVendor RwPluginVendor;
typedef enum RwCorePluginID RwCorePluginID;
typedef enum RwCriterionCoreID RwCriterionCoreID;
typedef enum RwPlatformID RwPlatformID;
typedef enum RwStreamType RwStreamType;
typedef enum RwStreamAccessType RwStreamAccessType;
typedef enum RwOpCombineType RwOpCombineType;
typedef enum RwMatrixType RwMatrixType;
typedef enum RwMatrixFlag RwMatrixFlag;
typedef enum RwMatrixOptimizations RwMatrixOptimizations;
typedef enum RwRenderState RwRenderState;
typedef enum RwShadeMode RwShadeMode;
typedef enum RwTextureFilterMode RwTextureFilterMode;
typedef enum RwFogType RwFogType;
typedef enum RwBlendFunction RwBlendFunction;
typedef enum RwTextureAddressMode RwTextureAddressMode;
typedef enum RwStencilOperation RwStencilOperation;
typedef enum RwStencilFunction RwStencilFunction;
typedef enum RwAlphaTestFunction RwAlphaTestFunction;
typedef enum RwCullMode RwCullMode;
typedef enum RwPrimitiveType RwPrimitiveType;
typedef enum RwEngineStatus RwEngineStatus;
typedef enum rxEmbeddedPacketState rxEmbeddedPacketState;
typedef enum RwRasterLockMode RwRasterLockMode;
typedef enum RwRasterFlipMode RwRasterFlipMode;
typedef enum RwRasterType RwRasterType;
typedef enum RwRasterFormat RwRasterFormat;
typedef enum RwRasterPrivateFlag RwRasterPrivateFlag;
typedef enum RwImageFlag RwImageFlag;
typedef enum RwIm3DTransformFlags RwIm3DTransformFlags;
typedef enum RwCameraClearMode RwCameraClearMode;
typedef enum RwCameraProjection RwCameraProjection;
typedef enum RwFrustumTestResult RwFrustumTestResult;
typedef enum rwD3D9VertexShaderEffectType rwD3D9VertexShaderEffectType;
typedef enum rwD3D9VertexShaderFogMode rwD3D9VertexShaderFogMode;
typedef enum RpMeshHeaderFlags RpMeshHeaderFlags;
typedef enum RpGeometryFlag RpGeometryFlag;
typedef enum RpGeometryLockMode RpGeometryLockMode;
typedef enum RpLightType RpLightType;
typedef enum RpLightFlag RpLightFlag;
typedef enum rpLightPrivateFlag rpLightPrivateFlag;
typedef enum RpInterpolatorFlag rpInterpolatorFlag;
typedef enum RpAtomicFlag RpAtomicFlag;
typedef enum RpAtomicSetGeomFlag RpAtomicSetGeomFlag;
typedef enum RpAtomicPrivateFlag rpAtomicPrivateFlag;
typedef enum RpHAnimHierarchyFlag RpHAnimHierarchyFlag;
typedef enum RpMatFXMaterialFlags  RpMatFXMaterialFlags;
typedef enum RpMatFXD3D9Pipeline RpMatFXD3D9Pipeline;
typedef enum RpWorldPrivateFlag RpWorldPrivateFlag;
typedef enum RpWorldFlag RpWorldFlag;
typedef enum RpWorldRenderOrder RpWorldRenderOrder;
typedef enum RpD3D9GeometryUsageFlag RpD3D9GeometryUsageFlag;
typedef enum RpD3D9WorldSectorUsageFlag RpD3D9WorldSectorUsageFlag;
// other
typedef int(*rwCustomStreamFnClose) (void *data);
typedef unsigned int(*rwCustomStreamFnRead) (void *data, void *buffer, unsigned int length);
typedef int(*rwCustomStreamFnWrite) (void *data, const void *buffer, unsigned int length);
typedef int(*rwCustomStreamFnSkip) (void *data, unsigned int offset);
typedef int (*vecSprintfFunc)(char *buffer, const char *format, ...); 
typedef int (*vecVsprintfFunc)(char *buffer, const char *format, va_list argptr); 
typedef char *(*vecStrcpyFunc)(char *dest, const char *srce);
typedef char *(*vecStrncpyFunc)(char *dest, const char *srce, size_t size);
typedef char *(*vecStrcatFunc)(char *dest, const char *srce);
typedef char *(*vecStrncatFunc)(char *dest, const char *srce, size_t size);
typedef char *(*vecStrrchrFunc)(const char *string, int findThis);
typedef char *(*vecStrchrFunc)(const char *string, int findThis);
typedef char *(*vecStrstrFunc)(const char *string, const char *findThis);
typedef int (*vecStrcmpFunc)(const char *string1, const char *string2);
typedef int (*vecStrncmpFunc)(const char *string1, const char *string2, size_t max_size);
typedef int (*vecStricmpFunc)(const char *string1, const char *string2);
typedef size_t (*vecStrlenFunc)(const char *string);
typedef char *(*vecStruprFunc)(char *string);
typedef char *(*vecStrlwrFunc)(char *string);
typedef char *(*vecStrtokFunc)(char *string, const char *delimit);
typedef int (*vecSscanfFunc)(const char *buffer, const char *format, ...);
typedef RwD3D9Vertex    RwIm2DVertex;
typedef unsigned short  RxVertexIndex;
typedef RxVertexIndex   RwImVertexIndex;
typedef int(*RwSystemFunc)(int nOption, void *pOut, void *pInOut, int nIn);
typedef int(*RwRenderStateSetFunction)(RwRenderState nState,void *pParam);
typedef int(*RwRenderStateGetFunction)(RwRenderState nState,void *pParam);
typedef int(*RwIm2DRenderLineFunction)(RwIm2DVertex *vertices, int numVertices, int vert1, int vert2);
typedef int(*RwIm2DRenderTriangleFunction)(RwIm2DVertex *vertices, int numVertices, int vert1, int vert2, int vert3);
typedef int(*RwIm2DRenderPrimitiveFunction)(RwPrimitiveType primType, RwIm2DVertex *vertices, int numVertices);
typedef int(*RwIm2DRenderIndexedPrimitiveFunction)(RwPrimitiveType primType, RwIm2DVertex *vertices, int numVertices, RwImVertexIndex *indices, int numIndices);
typedef int(*RwIm3DRenderLineFunction)(int vert1, int vert2);
typedef int(*RwIm3DRenderTriangleFunction)(int vert1, int vert2, int vert3);
typedef int(*RwIm3DRenderPrimitiveFunction)(RwPrimitiveType primType);
typedef int(*RwIm3DRenderIndexedPrimitiveFunction)(RwPrimitiveType primtype, RwImVertexIndex *indices, int numIndices);
typedef int(*RwStandardFunc)(void *pOut, void *pInOut, int nI);
typedef void       *(*RwMemoryAllocFn)    (RwFreeList * fl, unsigned int hint);
typedef RwFreeList *(*RwMemoryFreeFn)     (RwFreeList * fl, void *pData);
typedef void        (*RwResEntryDestroyNotify) (RwResEntry * resEntry);
typedef RxObjSpace3DVertex RxObjSpace3DLitVertex;
typedef RxObjSpace3DLitVertex RwIm3DVertex;
typedef RwIm2DVertex RxScrSpace2DVertex;
typedef RwObjectHasFrame * (*RwObjectHasFrameSyncFunction)(RwObjectHasFrame *object);
typedef RwCamera   *(*RwCameraBeginUpdateFunc) (RwCamera * camera);
typedef RwCamera   *(*RwCameraEndUpdateFunc) (RwCamera * camera);
typedef RpClump    *(*RpClumpCallBack) (RpClump * clump, void *data);
typedef unsigned int (*VisibilityCallBack)(RpClump * clump);
typedef RpAtomic   *(*RpAtomicCallBackRender) (RpAtomic * atomic);
typedef void (*RtAnimKeyFrameApplyCallBack) (void *result, void *voidIFrame);
typedef void (*RtAnimKeyFrameBlendCallBack) (void *voidOut, void *voidIn1, void *voidIn2, float alpha);
typedef void (*RtAnimKeyFrameInterpolateCallBack) (void *voidOut, void *voidIn1, void *voidIn2, float time, void *customData);
typedef void (*RtAnimKeyFrameAddCallBack) (void *voidOut, void *voidIn1, void *voidIn2);
typedef void (*RtAnimKeyFrameMulRecipCallBack) (void *voidFrame, void *voidStart);
typedef RtAnimAnimation * (*RtAnimKeyFrameStreamReadCallBack) (RwStream *stream, RtAnimAnimation *animation);
typedef int (*RtAnimKeyFrameStreamWriteCallBack) (const RtAnimAnimation *animation, RwStream *stream);
typedef int (*RtAnimKeyFrameStreamGetSizeCallBack) (const RtAnimAnimation *animation);
typedef RtAnimInterpolator * (*RtAnimCallBack) (RtAnimInterpolator *animInstance, void *data);
typedef RpWorldSector *(*RpWorldSectorCallBackRender) (RpWorldSector *worldSector);
#endif
/******************************************Structures****************************************/
// RwV2d
struct RwV2d
{
    float x;
    float y;
};
// RwV3d
struct RwV3d
{
    float x;
    float y;
    float z;
};
// RwRect
struct RwRect
{
    float x;
    float y;
    float w;
    float h;
};
// RwSphere
struct RwSphere
{
    RwV3d center;
    float radius;
};
// RwLine
struct RwLine
{
    RwV3d start;
    RwV3d end;
};
// RwTexCoords
struct RwTexCoords
{
    float u;
    float v;
};
// RwSLLink
struct RwSLLink
{
    RwSLLink  *next;
};
// RwSingleList
struct RwSingleList
{
    RwSLLink link;
};
// RwLLLink
struct RwLLLink
{
    RwLLLink *next;
    RwLLLink *prev;
};
// RwLinkList
struct RwLinkList
{
    RwLLLink link;
};
// RwSurfaceProperties
struct RwSurfaceProperties
{
    float ambient;
	// GTA Flags
	union
	{
		float specular;
		unsigned int m_dwFlags; /* HAS_ENV_MAP   = 0x00000001,
							       HAS_ENV_MAP_X = 0x00000002,
							       HAS_SPECULAR  = 0x00000004 */
	};
    float diffuse;
};
// RwPlane
struct RwPlane
{
    RwV3d normal;
    float distance;
};
// RwObject
struct RwObject
{
    unsigned char  type;
    unsigned char  subType;
    unsigned char  flags;
    unsigned char  privateFlags;
	RwFrame       *parent;
};
// RwMemoryFunctions
struct RwMemoryFunctions
{
    void *(*rwmalloc)(size_t size, unsigned int hint);
    void  (*rwfree)(void *mem);
    void *(*rwrealloc)(void *mem, size_t newSize, unsigned int hint);
    void *(*rwcalloc)(size_t numObj, size_t sizeObj, unsigned int hint);
};
// RwFreeList
struct RwFreeList
{
    unsigned int   entrySize;
    unsigned int   entriesPerBlock;
    unsigned int   heapSize;
    unsigned int   alignment;
    RwLinkList     blockList;
    unsigned int   flags;
    RwLLLink       link;
};
// RwStreamMemory
struct RwStreamMemory
{
    unsigned int   position; 
    unsigned int   nSize;
    unsigned char *memBlock;
};
// RwStreamFile
union RwStreamFile
{
    void    *fpFile;
    const void    *constfpFile;
};
// RwStreamCustom
struct RwStreamCustom
{
#ifndef _IDA_EXPORT
    rwCustomStreamFnClose sfnclose;
    rwCustomStreamFnRead sfnread;
    rwCustomStreamFnWrite sfnwrite;
    rwCustomStreamFnSkip sfnskip;
#else
	int   sfnclose;
    int  sfnread;
    int   sfnwrite;
    int  sfnskip;
#endif
    void               *data;
};
// RwStreamUnion
union RwStreamUnion
{
    RwStreamMemory      memory;
    RwStreamFile        file;
    RwStreamCustom      custom;
};
// RwStream
struct RwStream
{
#ifndef _IDA_EXPORT
    RwStreamType        type;
    RwStreamAccessType  accessType;
#else
	int                 type;
	int                 accessType;
#endif
    int                 position;
    RwStreamUnion       Type;
    int                 rwOwned;
};
// RwMemory
struct RwMemory
{
    unsigned char *start;
    unsigned int   length;
};
// RwStringFunctions
struct RwStringFunctions
{
#ifndef _IDA_EXPORT
    vecSprintfFunc vecSprintf ;
    vecVsprintfFunc vecVsprintf;
    vecStrcpyFunc vecStrcpy;
    vecStrncpyFunc vecStrncpy;
    vecStrcatFunc vecStrcat;
    vecStrncatFunc vecStrncat;
    vecStrrchrFunc vecStrrchr;
    vecStrchrFunc vecStrchr;
    vecStrstrFunc vecStrstr;
    vecStrcmpFunc vecStrcmp;
    vecStrncmpFunc vecStrncmp;
    vecStricmpFunc vecStricmp;
    vecStrlenFunc vecStrlen;
    vecStruprFunc vecStrupr;
    vecStrlwrFunc vecStrlwr;
    vecStrtokFunc vecStrtok;
    vecSscanfFunc vecSscanf;
#else
	int   vecSprintf ;
    int   vecVsprintf;
    int  vecStrcpy;
    int   vecStrncpy;
    int  vecStrcat;
    int   vecStrncat;
    int   vecStrrchr;
    int  vecStrchr;
    int  vecStrstr;
    int  vecStrcmp;
    int   vecStrncmp;
    int   vecStricmp;
    int  vecStrlen;
    int  vecStrupr;
    int  vecStrlwr;
    int  vecStrtok;
    int  vecSscanf;
#endif
};
// RwMatrix
struct RwMatrix
{
    RwV3d        right;
    unsigned int flags;
    RwV3d        up;
    unsigned int pad1;
    RwV3d        at;
    unsigned int pad2;
    RwV3d        pos;
    unsigned int pad3;
};
// RwD3D9Vertex
struct RwD3D9Vertex
{
    float        x;
    float        y;
    float        z;
    float        rhw;
    unsigned int emissiveColor;
    float        u;
    float        v;
};
// RwDevice
struct RwDevice
{
    float                                gammaCorrection;
#ifndef _IDA_EXPORT
    RwSystemFunc                         fpSystem;
#else
	int                                  fpSystem;
#endif
    float                                zBufferNear;
    float                                zBufferFar;
#ifndef _IDA_EXPORT
    RwRenderStateSetFunction             fpRenderStateSet;
    RwRenderStateGetFunction             fpRenderStateGet;
    RwIm2DRenderLineFunction             fpIm2DRenderLine;
    RwIm2DRenderTriangleFunction         fpIm2DRenderTriangle;
    RwIm2DRenderPrimitiveFunction        fpIm2DRenderPrimitive;
    RwIm2DRenderIndexedPrimitiveFunction fpIm2DRenderIndexedPrimitive;
    RwIm3DRenderLineFunction             fpIm3DRenderLine;
    RwIm3DRenderTriangleFunction         fpIm3DRenderTriangle;
    RwIm3DRenderPrimitiveFunction        fpIm3DRenderPrimitive;
    RwIm3DRenderIndexedPrimitiveFunction fpIm3DRenderIndexedPrimitive;
#else
	int                                  fpRenderStateSet;
    int                                  fpRenderStateGet;
    int                                  fpIm2DRenderLine;
    int                                  fpIm2DRenderTriangle;
    int                                  fpIm2DRenderPrimitive;
    int                                  fpIm2DRenderIndexedPrimitive;
    int                                  fpIm3DRenderLine;
    int                                  fpIm3DRenderTriangle;
    int                                  fpIm3DRenderPrimitive;
    int                                  fpIm3DRenderIndexedPrimitive;
#endif
};
// RwGlobals
struct RwGlobals
{
	void               *curCamera;
	void               *curWorld;
	unsigned short      renderFrame;
	unsigned short      lightFrame;
	unsigned short      pad[2];
	RwDevice            dOpenDevice;
#ifndef _IDA_EXPORT
	RwStandardFunc      stdFunc[29];
#else
	int                 stdFunc[29];
#endif
	RwLinkList          dirtyFrameList;
	void               *fileFuncs[0xB];
	RwStringFunctions   stringFuncs;
	RwMemoryFunctions   memoryFuncs;
#ifndef _IDA_EXPORT
	RwMemoryAllocFn     memoryAlloc;
	RwMemoryFreeFn      memoryFree;
#else
	int                 memoryAlloc;
	int                 memoryFree;
#endif
	RwMetrics          *metrics;
#ifndef _IDA_EXPORT
	RwEngineStatus      engineStatus;
#else
	int                 engineStatus;
#endif
	unsigned int        resArenaInitSize;
};
// RwMetrics
struct RwMetrics
{
    unsigned int  numTriangles;
    unsigned int  numProcTriangles;
    unsigned int  numVertices;
    unsigned int  numTextureUploads;
    unsigned int  sizeTextureUploads;
    unsigned int  numResourceAllocs;
    void         *devSpecificMetrics;
};
// RxD3D9VertexStream
struct RxD3D9VertexStream
{
    void           *vertexBuffer;
    unsigned int    offset;
    unsigned int    stride;
    unsigned short  geometryFlags;
    unsigned char   managed;
    unsigned char   dynamicLock;
};
// RxD3D9ResEntryHeader
struct RxD3D9ResEntryHeader
{
    unsigned int        serialNumber;
    unsigned int        numMeshes;
    void               *indexBuffer;
    unsigned int        primType;
    RxD3D9VertexStream  vertexStream[2];
    int                 useOffsets;
    void               *vertexDeclaration;
    unsigned int        totalNumIndex;
    unsigned int        totalNumVertex;
};
// RxD3D9InstanceData
struct RxD3D9InstanceData
{
    unsigned int  numIndex;
    unsigned int  minVert;
    RpMaterial   *material;
    int           vertexAlpha;
    void         *vertexShader;
    unsigned int  baseIndex;
    unsigned int  numVertices;
    unsigned int  startIndex;
    unsigned int  numPrimitives;
};
// RwResEntry
struct RwResEntry
{
    RwLLLink            link;
    int                 size;
    void               *owner;
    RwResEntry        **ownerRef;
#ifndef _IDA_EXPORT
    RwResEntryDestroyNotify destroyNotify;
#else
	int destroyNotify;
#endif
	RxD3D9ResEntryHeader header;
	RxD3D9InstanceData   meshData;
};
// RwRGBAReal
struct RwRGBAReal
{
    float red;
    float green;
    float blue;
    float alpha;
};
// RwRGBA
struct RwRGBA
{
    unsigned char red; 
    unsigned char green;
    unsigned char blue;
    unsigned char alpha;
};
// RwChunkHeaderInfo
struct RwChunkHeaderInfo
{
    unsigned int type;
    unsigned int length;
    unsigned int version; 
    unsigned int buildNum;
    int isComplex;
};
// RxPipeline
struct RxPipeline
{
    int                   locked;
    unsigned int           numNodes;
    void                  *nodes;
    unsigned int           packetNumClusterSlots;
#ifndef _IDA_EXPORT
    rxEmbeddedPacketState  embeddedPacketState;
#else
	int                    embeddedPacketState;
#endif
    void                  *embeddedPacket;
    unsigned int           numInputRequirements;
    void                  *inputRequirements;
    void                  *superBlock;
    unsigned int           superBlockSize;
    unsigned int           entryPoint;
    unsigned int           pluginId;
    unsigned int           pluginData;
};
// RwRaster
struct RwRaster
{
    RwRaster      *parent;
    unsigned char *cpPixels;
    unsigned char *palette;
    int            width, height, depth;
    int            stride;
    short          nOffsetX, nOffsetY;
    unsigned char  cType;
    unsigned char  cFlags;
    unsigned char  privateFlags;
    unsigned char  cFormat;
    unsigned char *originalPixels;
    int            originalWidth;
    int            originalHeight;
    int            originalStride;
#ifndef _IDA_EXPORT
    // RenderWare plugin
    struct
    {
        union
        {
            IDirect3DTexture9 *texture;
            IDirect3DSurface9 *surface;
        };
        unsigned char       *palette;
        unsigned char        alpha;
        unsigned char        cubeTextureFlags; /* 0x01 IS_CUBEMAP_TEX */
        unsigned char        textureFlags;     /* 0x01 HAS_MIP_MAPS
                                                  0x10 IS_COMPRESSED */
        unsigned char        lockFlags;
        IDirect3DSurface9   *lockedSurface;
        D3DLOCKED_RECT       lockedRect;
        D3DFORMAT            format;
        IDirect3DSwapChain9 *swapChain;
        HWND                *hwnd;
    } RwD3D9Raster;
#endif
};
// RxObjSpace3DVertex
struct RxObjSpace3DVertex
{
    RwV3d        objVertex;
    RwV3d        objNormal;
    unsigned int color;
    float        u;
    float        v;
};
// RwImage
struct RwImage
{
    int            flags;
    int            width;
    int            height;
    int            depth;
    int            stride;
    unsigned char *cpPixels;
    RwRGBA        *palette;
};
// RwTexDictionary
struct RwTexDictionary
{
    RwObject         object;
    RwLinkList       texturesInDict;
    RwLLLink         lInInstance;
    // GTA plugin
	RwTexDictionary *parent;
};
// RwTexture
struct RwTexture
{
    RwRaster        *raster;
    RwTexDictionary *dict;
    RwLLLink        lInDictionary;
    char            name[32];
    char            mask[32];
    unsigned int    filterAddressing;
    int             refCount;
    // Renderware plugin
    unsigned char   maxAnisotropy;
    char            pad[3];
};
// RpHAnimFrameExtension
struct RpHAnimFrameExtension
{
    int               id;
    void             *hierarchy;
};
// RwFrame
struct RwFrame
{
    RwObject              object;
    RwLLLink              inDirtyListLink;
    RwMatrix              modelling;
    RwMatrix              ltm;
    RwLinkList            objectList;
    RwFrame              *child;
    RwFrame              *next;
    RwFrame              *root;
    // RenderWare plugins
    RpHAnimFrameExtension hAnimFrame;
    // GTA Plugins
    char                  nodeName[24];
    union
    {
        void             *model;
        int               hierId;
    };
};
// RwBBox
struct RwBBox
{
    RwV3d sup;
    RwV3d inf;
};
// RwFrustumPlane
struct RwFrustumPlane
{
    RwPlane       plane;
    unsigned char closestX;
    unsigned char closestY;
    unsigned char closestZ;
    unsigned char pad;
};
// RwObjectHasFrame
struct RwObjectHasFrame
{
    RwObject                     object;
    RwLLLink                     lFrame;
#ifndef _IDA_EXPORT
    RwObjectHasFrameSyncFunction sync;
#else
	int                          sync;
#endif
};
// RwCamera
struct RwCamera
{
    RwObjectHasFrame         object;
#ifndef _IDA_EXPORT
    RwCameraProjection       projectionType;
    RwCameraBeginUpdateFunc  beginUpdate;
    RwCameraEndUpdateFunc    endUpdate;
#else
	int                      projectionType;
    int                      beginUpdate;
    int                      endUpdate;
#endif
    RwMatrix                 viewMatrix;
    RwRaster                *frameBuffer;
    RwRaster                *zBuffer;
    RwV2d                    viewWindow;
    RwV2d                    recipViewWindow;
    RwV2d                    viewOffset;
    float                    nearPlane;
    float                    farPlane;
    float                    fogPlane;
    float                    zScale, zShift;
    RwFrustumPlane           frustumPlanes[6];
    RwBBox                   frustumBoundBox;
    RwV3d                    frustumCorners[8];
};
// RpUVAnimMaterial
struct RpUVAnimMaterial
{
    RwMatrix           *pMatrix[2];
    RtAnimInterpolator *pInterpolator[8];
};
// RpMaterial
struct RpMaterial
{
    RwTexture           *texture;
	union
	{
		RwRGBA               color;
		unsigned int         colorHex;
	};
    RxPipeline          *pipeline;
    RwSurfaceProperties  surfaceProps;
    short                refCount;
    short                pad;
    // RenderWare plugins
	RpMatFx             *matFx;
    RpUVAnimMaterial     UVAnim;
#ifndef _IDA_EXPORT
    // GTA plugins
    CEnvMapMaterial     *m_pReflection;
    CSpecularMaterial   *m_pSpecular;
#endif
};
// EnvMapFx
struct EnvMapFx
{
    RwFrame      *frame;
    RwTexture    *texture;
    float         coefficient;
    unsigned int  frameBufferAlpha;
    float         size;
    unsigned int  effectType;
};
// RpMatFx
struct RpMatFx
{
    EnvMapFx     effect[2];
    unsigned int flags;
};
// RpMaterialList
struct RpMaterialList
{
    RpMaterial **materials;
    int          numMaterials;
    int          space;
};
// RpMesh
struct RpMesh
{
#ifndef _IDA_EXPORT
    RxVertexIndex *indices;
#else
	short         *indices;
#endif
    unsigned int   numIndices;
    RpMaterial    *material;
};
// RpMeshHeader
struct RpMeshHeader
{
    unsigned int   flags;
    unsigned short numMeshes;
    unsigned short serialNum;
    unsigned int   totalIndicesInMesh;
    unsigned int   firstMeshOffset;
};
// RpMorphTarget
struct RpMorphTarget
{
    RpGeometry *parentGeom; 
    RwSphere    boundingSphere;
    RwV3d      *verts;
    RwV3d      *normals;
};
// RpTriangle
struct RpTriangle
{
    unsigned short vertIndex[3];
    unsigned short matIndex;
};
// CNightVertexColors
#ifndef _IDA_EXPORT
class CNightVertexColors
{
	RwRGBA *m_pNightColors;
	RwRGBA *m_pDayColors;
	float   m_fLightingState;
};
#endif
struct RsInputDevice
{
  int inputDeviceType;
  int used;
  int inputEventHandler;
};
struct VehAddonCtrl
{
	struct VehicleAdditional *additional;
	DWORD _pad[2];
};
struct Placement
{
	union
	{
		RwV3d pos;
		VehAddonCtrl ctrl;
	} base;
	float angle;
};
struct CMatrix
{
	RwMatrix m;
	RwMatrix *ptr;
	DWORD haveRw;
};
struct CPlaceable
{
	DWORD __vmt;
	Placement placement;
	RwMatrix *m_pCoords;
};
struct CCam
{
  char bBelowMinDist;
  char bBehindPlayerDesired;
  char m_bCamLookingAtVector;
  char m_bCollisionChecksOn;
  char m_bFixingBeta;
  char m_bTheHeightFixerVehicleIsATrain;
  char LookBehindCamWasInFront;
  char LookingBehind;
  char LookingLeft;
  char LookingRight;
  char ResetStatics;
  char Rotating;
  __int16 Mode;
  __int16 m_uiFinishTime;
  int m_iDoCollisionChecksOnFrameNum;
  int m_iDoCollisionCheckEveryNumOfFrames;
  int m_iFrameNumWereAt;
  int m_iRunningVectorArrayPos;
  int m_iRunningVectorCounter;
  int DirectionWasLooking;
  int f_max_role_angle;
  int f_Roll;
  int f_rollSpeed;
  int m_fSyphonModeTargetZOffSet;
  int m_fAmountFractionObscured;
  int m_fAlphaSpeedOverOneFrame;
  int m_fBetaSpeedOverOneFrame;
  int m_fBufferedTargetBeta;
  int m_fBufferedTargetOrientation;
  int m_fBufferedTargetOrientationSpeed;
  int m_fCamBufferedHeight;
  int m_fCamBufferedHeightSpeed;
  int m_fCloseInPedHeightOffset;
  int m_fCloseInPedHeightOffsetSpeed;
  int m_fCloseInCarHeightOffset;
  int m_fCloseInCarHeightOffsetSpeed;
  int m_fDimensionOfHighestNearCar;
  int m_fDistanceBeforeChanges;
  int m_fFovSpeedOverOneFrame;
  int m_fMinDistAwayFromCamWhenInterPolating;
  char m_fPedBetweenCameraHeightOffset;
  char m_fPlayerInFrontSyphonAngleOffSet;
  char m_fRadiusForDead;
  char m_fRealGroundDist;
  int m_fTargetBeta;
  int m_fTimeElapsedFloat;
  int m_fTilt;
  int m_fTiltSpeed;
  int field_8C;
  int field_90;
  int field_94;
  int field_98;
  int field_9C;
  int field_A0;
  int field_A4;
  int field_A8;
  int field_AC;
  int field_B0;
  int zoomFactor;
  int field_B8;
  int field_BC;
  int field_C0;
  int field_C4;
  int field_C8;
  int field_CC;
  int field_D0;
  int field_D4;
  int field_D8;
  int field_DC;
  int field_E0;
  int field_E4;
  int field_E8;
  int field_EC;
  int field_F0;
  int m_fTargetZoomZCloseIn;
  int m_fMinRealGroundDist;
  int m_fTargetCloseInDist;
  int Beta_Targeting;
  int X_Targetting;
  int Y_Targetting;
  int CarWeAreFocussingOn;
  int CarWeAreFocussingOnI;
  int m_fCamBumpedHorz;
  int m_fCamBumpedVert;
  int m_nCamBumpedTime;
  int CAM_BUMPED_SWING_PERIOD;
  int CAM_BUMPED_END_TIME;
  int CAM_BUMPED_DAMP_RATE;
  int CAM_BUMPED_MOVE_MULT;
  RwV3d m_cvecSourceSpeedOverOneFrame;
  RwV3d m_cvecTargetSpeedOverOneFrame;
  RwV3d m_cvecUpOverOneFrame;
  RwV3d m_cvecTargetCoorsForFudgeInter;
  RwV3d m_cvecCamFixedModeVector;
  RwV3d m_cvecCamFixedModeSource;
  RwV3d m_cvecCamFixedModeUpOffSet;
  RwV3d m_vecLastAboveWaterCamPosition;
  RwV3d camTarget;
  RwV3d camPos;
  RwV3d Source;
  RwV3d _f1B4;
  RwV3d Up;
  RwV3d m_arrPreviousVectors;
  RwV3d m_aTargetHistoryPos[4];
  int m_nTargetHistoryTime[4];
  int m_nCurrentHistoryPoints;
  int CamTargetEntity;
  int field_220;
  int field_224;
  int field_228;
  int field_22C;
  int field_230;
  int field_234;
};
struct CCamera_obj2
{
  int field_0;
  int field_4;
  int field_8;
  int field_C;
};
struct CCamera
{
  struct CPlaceable placeable;
  char gap_18[16];
  char m_bJustCameOutOfGarage;
  char m_bJustInitalised;
  char m_bJust_Switched;
  char m_bLookingAtPlayer;
  char m_bLookingAtVector;
  char m_bMoveCamToAvoidGeom;
  char m_bObbeCinematicPedCamOn;
  char m_bObbeCinematicCarCamOn;
  char m_bRestoreByJumpCut;
  char m_bUseNearClipScript;
  char m_bStartInterScript;
  char m_bStartingSpline;
  char m_bTargetJustBeenOnTrain;
  char m_bTargetJustCameOffTrain;
  char m_bUseSpecialFovTrain;
  char m_bUseTransitionBeta;
  char m_bUseScriptZoomValuePed;
  char m_bUseScriptZoomValueCa;
  char m_bWaitForInterpolToFinish;
  char m_bItsOkToLookJustAtThePlayer;
  char m_bWantsToSwitchWidescreenOff;
  char m_WideScreenOn;
  char m_1rstPersonRunCloseToAWall;
  char m_bHeadBob;
  char m_bVehicleSuspenHigh;
  char m_bEnable1rstPersonCamCntrlsScript;
  char m_bAllow1rstPersonWeaponsCamera;
  char m_bCooperativeCamMode;
  char m_bAllowShootingWith2PlayersInCar;
  char m_bDisableFirstPersonInCar;
  __int16 m_ModeForTwoPlayersSeparateCars;
  __int16 m_ModeForTwoPlayersSameCarShootingAllowed;
  __int16 m_ModeForTwoPlayersSameCarShootingNotAllowed;
  __int16 m_ModeForTwoPlayersNotBothInCar;
  char m_bGarageFixedCamPositionSet;
  char m_vecDoingSpecialInterPolation;
  char m_bScriptParametersSetForInterPol;
  char m_bFading;
  char m_bMusicFading;
  char m_bMusicFadedOut;
  char m_bFailedCullZoneTestPreviously;
  char m_FadeTargetIsSplashScreen;
  char WorldViewerBeingUsed;
  char m_uiTransitionJUSTStarted;
  char m_uiTransitionState;
  char ActiveCam;
  char field_5A;
  char field_5B;
  int m_uiCamShakeStart;
  int m_uiFirstPersonCamLastInputTime;
  int m_uiLongestTimeInMill;
  int m_uiNumberOfTrainCamNodes;
  int m_uiTimeLastChange;
  int m_uiTimeWeLeftIdle_StillNoInput;
  int m_uiTimeWeEnteredIdle;
  int m_uiTimeTransitionStart;
  int m_uiTransitionDuration;
  int m_uiTransitionDurationTargetCoors;
  int m_BlurBlue;
  int m_BlurGreen;
  int m_BlurRed;
  int m_BlurType;
  int m_iWorkOutSpeedThisNumFrames;
  int m_iNumFramesSoFar;
  int m_iCurrentTrainCamNode;
  int m_motionBlur;
  int m_imotionBlurAddAlpha;
  int m_iCheckCullZoneThisNumFrames;
  int m_iZoneCullFrameNumWereAt;
  int WhoIsInControlOfTheCamera;
  int m_nCarZoom;
  int m_fCarZoomBase;
  int m_fCarZoomTotal;
  int m_fCarZoomSmoothed;
  int m_fCarZoomValueScript;
  int field_C8;
  int field_CC;
  int field_D0;
  int field_D4;
  int field_D8;
  float field_DC;
  float field_E0;
  int field_E4;
  int field_E8;
  int field_EC;
  float farClip;
  int field_F4;
  int field_F8;
  int field_FC;
  int field_100;
  int field_104;
  int field_108;
  int field_10C;
  int field_110;
  int field_114;
  int field_118;
  int field_11C;
  int m_PedOrientForBehindOrInFront;
  int m_CameraAverageSpeed;
  int m_CameraSpeedSoFar;
  int m_fCamShakeForce;
  int m_fFovForTrain;
  int m_fFOV_Wide_Screen;
  int m_fNearClipScript;
  int m_fOldBetaDiff;
  int m_fPositionAlongSpline;
  float m_ScreenReductionPercentage;
  int m_ScreenReductionSpeed;
  int m_AlphaForPlayerAnim1rstPerson;
  int field_150;
  int field_154;
  int field_158;
  int field_15C;
  int field_160;
  int field_164;
  __int16 field_168;
  __int16 field_16A;
  int field_16C;
  int field_170;
  struct CCam cams[3];
  int pToGarageWeAreIn;
  int pToGarageWeAreInForHackAvoidFirstPerson;
  int field_824;
  int field_828;
  int field_82C;
  __int16 field_830;
  __int16 field_832;
  int field_834;
  __int16 field_838;
  __int16 field_83A;
  struct RwV3d m_PreviousCameraPosition;
  struct RwV3d m_RealPreviousCameraPosition;
  struct RwV3d field_854;
  struct RwV3d m_cvecAimingTargetCoors;
  struct RwV3d m_vecFixedModeVector;
  struct RwV3d m_vecFixedModeSource;
  struct RwV3d m_vecFixedModeUpOffSet;
  struct RwV3d m_vecCutSceneOffset;
  struct RwV3d m_cvecStartingSourceForInterPol;
  struct RwV3d m_cvecStartingTargetForInterPol;
  struct RwV3d m_cvecStartingUpForInterPol;
  struct RwV3d m_cvecSourceSpeedAtStartInter;
  struct RwV3d m_cvecTargetSpeedAtStartInter;
  struct RwV3d m_cvecUpSpeedAtStartInter;
  struct RwV3d m_vecSourceWhenInterPol;
  struct RwV3d m_vecTargetWhenInterPol;
  struct RwV3d m_vecUpWhenInterPol;
  struct RwV3d m_vecClearGeometryVec;
  struct RwV3d m_vecGameCamPos;
  struct RwV3d field_920;
  struct RwV3d field_92C;
  struct RwV3d m_vecAttachedCamOffset;
  struct RwV3d m_vecAttachedCamLookAt;
  int m_fAttachedCamAngle;
  struct RwCamera m_pRwCamera;
  char gap_AD8[4];
  struct CMatrix m_matMirror;
  struct RwV3d m_vecFrustumNormals[4];
  struct RwV3d m_vecFrustumWorldNormals[4];
  struct RwV3d m_vecFrustumWorldNormals_Mirror[4];
  int m_fFrustumPlaneOffsets[4];
  int m_fFrustumPlaneOffsets_Mirror[4];
  struct RwV3d m_vecRightFrustumNormal;
  struct RwV3d m_vecBottomFrustumNormal;
  struct RwV3d m_vecTopFrustumNormal;
  int field_BF8;
  int m_fFade;
  int m_fFadeMusic;
  int m_fTimeToFadeOut;
  int m_fTimeToFadeMusic;
  int m_fTimeToWaitToFadeMusic;
  int m_fFractionInterToStopMoving;
  int m_fFractionInterToStopCatchUp;
  int m_fFractionInterToStopMovingTarget;
  int m_fFractionInterToStopCatchUpTarget;
  int m_fGaitSwayBuffer;
  int m_fScriptPercentageInterToStopMoving;
  int m_fScriptPercentageInterToCatchUp;
  int m_fScriptTimeForInterPolation;
  __int16 _fadeInOutFlag;
  __int16 m_iFadingDirection;
  int m_iModeObbeCamIsInForCar;
  __int16 m_iModeToGoTo;
  __int16 m_iMusicFadingDirection;
  __int16 m_iTypeOfSwitch;
  __int16 field_C3E;
  int m_uiFadeTimeStarted;
  int m_uiFadeTimeStartedMusic;
  int field_C48;
  int field_C4C;
  int field_C50;
  int field_C54;
  int field_C58;
  int transverseStartTime;
  int transverseEndTime;
  struct RwV3d transverseEndPoint;
  struct RwV3d transverseStartPoint;
  char transverseMode;
  char field_C7D;
  char field_C7E;
  char field_C7F;
  struct RwV3d field_C80;
  char field_C8C;
  char field_C8D;
  char field_C8E;
  char field_C8F;
  float jiggleIntensity;
  __int32 startJiggleTime;
  __int32 endJiggleTime;
  int field_C9C;
  int jiggleType;
  int _startZoomTime;
  int _endZoomTime;
  int _zoomInFactor;
  int _zoomOutFactor;
  char _zoomMode;
  char field_CB5;
  char field_CB6;
  char field_CB7;
  int field_CB8;
  int field_CBC;
  int field_CC0;
  struct RwV3d field_CC4;
  struct RwV3d field_CD0;
  char field_CDC;
  char field_CDD;
  char field_CDE;
  char field_CDF;
  struct RwV3d field_CE0;
  char field_CEC;
  char field_CED;
  char field_CEE;
  char field_CEF;
  char field_CF0;
  char field_CF1;
  char field_CF2;
  char field_CF3;
  struct CCamera_obj2 field_CF4[5];
  int field_D44;
  int field_D48;
  int field_D4C;
  int field_D50;
  int field_D54;
  int field_D58;
  int field_D5C;
  int field_D60;
  int field_D64;
  int field_D68;
  int field_D6C;
  int field_D70;
  int field_D74;
};
struct RsGlobalType
{
  char *AppName;
  int MaximumWidth;
  int MaximumHeight;
  int frameLimit;
  int quit;
  int ps;
  RsInputDevice keyboard;
  RsInputDevice mouse;
  RsInputDevice pad;
};
#pragma pack(push, 1)
struct CMenuManager
{
  char field_0;
  char gap_1[3];
  int statsScrollSpeed;
  char field_8;
  char gap_9[23];
  char field_20;
  char field_21;
  char gap_22[2];
  int drawRadar;
  char gap_28[4];
  int field_2C;
  char field_30;
  char field_31;
  char field_32;
  char activateMenu;
  char menuAccessWidescreen;
  char field_35;
  char gap_36[2];
  int field_38;
  int brightness;
  int drawDistance;
  char subtitlesOn;
  int field_45;
  char field_49;
  char legend;
  char widescreenOn;
  char frameLimiterOn;
  char field_4D;
  char field_4E;
  char sfxVolume;
  char radioVolume;
  char radioEq;
  char radioStation;
  char gap_53[1];
  int field_54;
  char field_58;
  char drawRadarOrMap;
  char field_5A;
  char field_5B;
  char menuActive;
  char doGameReload;
  char field_5E;
  char isSaveDone;
  char field_60;
  char gap_61[3];
  int length;
  int xBase;
  int yBase;
  float field_70;
  int field_74;
  char field_78;
  char gap_79[3];
  int titleLanguage;
  int textLanguage;
  char language;
  char prevLanguage;
  char gap_86[2];
  int field_88;
  char field_8C;
  char gap_8D[3];
  int field_90;
  char gap_94[24];
  int field_AC;
  char field_B0;
  char invertPadX1;
  char invertPadY1;
  char invertPadX2;
  char invertPadY2;
  char swapPadAxis1;
  char swapPadAxis2;
  char field_B7;
  char field_B8;
  char gap_B9[3];
  int mousePosLeft;
  int mousePosTop;
  char field_C4;
  char field_C5;
  char gap_C6[2];
  int multisamplingLevels;
  int field_CC;
  char useKeyboardAndMouse;
  char gap_D1[3];
  int videoMode;
  int prevVideoMode;
  int field_DC;
  int mousePosLeftA;
  int mousePosTopA;
  char field_E8;
  char field_E9;
  char playerNumber;
  char field_EB;
  int field_EC;
  int field_F0;
  char field_F4;
  char gap_F5[3];
  int textures[25];
  char texturesLoaded;
  char currentMenuItem;
  char field_15E;
  char field_15F;
  char field_160;
  char field_161;
  char mpackName[8];
  char field_16A[6486];
  int field_1AC0;
  int field_1AC4;
  int field_1AC8;
  int field_1ACC;
  int field_1AD0;
  int field_1AD4;
  int field_1AD8;
  __int16 field_1ADC;
  char field_1ADE;
  char field_1ADF;
  int field_1AE0;
  int field_1AE4;
  char field_1AE8;
  char field_1AE9;
  char field_1AEA;
  char field_1AEB;
  int field_1AEC;
  char field_1AF0;
  char field_1AF1;
  char field_1AF2;
  char field_1AF3;
  int field_1AF4;
  int field_1AF8;
  int field_1AFC;
  int field_1B00;
  int field_1B04;
  char field_1B08;
  char field_1B09;
  char field_1B0A;
  char field_1B0B;
  int field_1B0C;
  char field_1B10;
  char field_1B11;
  char field_1B12;
  char field_1B13;
  char field_1B14;
  char field_1B15;
  char field_1B16;
  char field_1B17;
  int field_1B18;
  int field_1B1C;
  char field_1B20;
  char field_1B21;
  __int16 field_1B22;
  int field_1B24;
  char field_1B28;
  char field_1B29;
  __int16 field_1B2A;
  int field_1B2C;
  int field_1B30;
  __int16 field_1B34;
  __int16 field_1B36;
  int field_1B38;
  char field_1B3C;
  char field_1B3D;
  char field_1B3E;
  char field_1B3F;
  int field_1B40;
  char field_1B44;
  char field_1B45;
  __int16 field_1B46;
  int field_1B48;
  int field_1B4C;
  char field_1B50;
  char field_1B51;
  __int16 field_1B52;
  int field_1B54;
  int field_1B58;
  char field_1B5C;
  char field_1B5D;
  __int16 field_1B5E;
  int field_1B60;
  int field_1B64;
  int field_1B68;
  int field_1B6C;
  int field_1B70;
  int field_1B74;
};
#pragma pack(pop)
// RpGeometry
struct RpGeometry
{
    RwObject            object;
    unsigned int        flags;
    unsigned short      lockedSinceLastInst;
    short               refCount;
    int                 numTriangles;
    int                 numVertices;
    int                 numMorphTargets;
    int                 numTexCoordSets;
    RpMaterialList      matList;
    RpTriangle         *triangles;
    RwRGBA             *preLitLum;
    RwTexCoords        *texCoords[8];
    RpMeshHeader       *mesh;
    RwResEntry         *repEntry;
    RpMorphTarget      *morphTarget;
    // RenderWare plugins
	unsigned int        usageFlags;
    RpSkin             *skin;
    // GTA plugins
#ifndef _IDA_EXPORT
    CNightVertexColors  nightVertexColors;
    CBreakableGeometry *breakableGeometry;
    C2dfxStore         *_2dfxStore;
#endif
};
// RwMatrixWeights
struct RwMatrixWeights
{
    float w0;
    float w1;
    float w2;
    float w3;
};
// RpSkin
struct RpSkin
{
    unsigned int     numBones;
    unsigned int     numBoneIds;
    unsigned char   *boneIds;
    RwMatrix        *skinToBoneMatrices;
    unsigned int     maxNumWeightsForVertex;
    unsigned int    *vertexBoneIndices;
    RwMatrixWeights *vertexBoneWeights;
    char             field_1C[8];
    unsigned int     boneLimit;
    unsigned int     numMeshes;
    unsigned int     numRLE;
    unsigned char   *meshBoneRemapIndices;
    unsigned int     meshBoneRLECount;
    void            *meshBoneRLE;
    void            *field_3C;
};
#ifndef _IDA_EXPORT
// CBreakableGeometry
class CBreakableGeometry
{
public:
    unsigned int         m_uiPosRule;
    unsigned short       m_usNumVertices;
    char                 _pad0[2];
    RwV3d               *m_pVertexPos;
    RwTexCoords         *m_pTexCoors;
    RwRGBA              *m_pVertexColors;
    unsigned short       m_usNumTriangles;
    char                 _pad1[2];
    RpTriangle          *m_pTriangles;
    unsigned short      *m_pMaterialAssignments;
    unsigned short       m_usNumMaterials;
    char                 _pad2[2];
    RwTexture          **m_pTextures;
    char                *m_pTextureNames;
    char                *m_pMaskNames;
    RwSurfaceProperties *m_pMaterialProperties;
	/* some data here with random size
	RwV3d                m_avVertexPos[m_usNumVertices];
	RwTexCoords          m_asTexCoords[m_usNumVertices];
	RwRGBA               m_asVertexColors[m_usNumVertices];
	RpTriangle           m_asTriangles[m_usNumTriangles];
	unsigned short       m_ausMaterialAssignments[m_usNumTriangles];
	char                 m_acTextureNames[m_usNumMaterials][32];
	char                 m_acMaskNames[m_usNumMaterials][32];
	RwSurfaceProperties  m_asMaterialProperties[m_usNumMaterials];
	*/
};
// C2dfx
class C2dfxStore
{
public:
	unsigned int m_uiNum2dfx;
	/* Data with random size here
	C2dfx        m_as2dfx[m_uiNumEffects];
	*/
};
// CEnvMapMaterial
class CEnvMapMaterial
{
public:
    unsigned char   m_ucTransformParams[4];
    unsigned char   m_ucIntensity;
    char            _pad;
    unsigned short  m_usRenderFrame;
    RwTexture      *m_pTexture;
};
// CSpecularMaterial
class CSpecularMaterial
{
public:
	float      m_fLevel;
	RwTexture *m_pTexture;
};
#endif
// RpLight
struct RpLight
{
    RwObjectHasFrame object;
    float            radius;
    RwRGBAReal       color;
    float            minusCosAngle;
    RwLinkList       WorldSectorsInLight;
    RwLLLink         inWorld;
    unsigned short   lightFrame;
    unsigned short   pad;
};
// RpD3D9AttenuationParams
struct RpD3D9AttenuationParams
{
    float constant;
    float linear;
    float quadratic;
};
// RpInterpolator
struct RpInterpolator
{
    int   flags;
    short startMorphTarget;
    short endMorphTarget;
    float time;
    float recipTime;
    float position;
};
#ifndef _IDA_EXPORT
// CClumpVisibility
class CClumpVisibility
{
	VisibilityCallBack m_pVisibilityCB;
	unsigned int       m_uiClumpAlpha;
};
#endif
// RpClump
struct RpClump
{
    RwObject          object;
    RwLinkList        atomicList;
    RwLinkList        lightList;
    RwLinkList        cameraList;
    RwLLLink          inWorldLink;
#ifndef _IDA_EXPORT
    RpClumpCallBack   callback;
#else
	int               callback;
#endif
    // RenderWare plugins
    char              worldData[8];
#ifndef _IDA_EXPORT
    // GTA plugins
    CClumpVisibility  visibility;
    CHAnim           *anim;
#endif
};
// CBone
#ifndef _IDA_EXPORT
class CBone
{
public:
    unsigned char m_ucFlags;
	RwV3d         m_vOffset;
	CHAnimIFrame *m_pIFrame;
	int           m_iNodeId;
};
#endif
// RtQuat
struct RtQuat
{
    RwV3d imag;
    float real;
};
#ifndef _IDA_EXPORT
// CHAnimIFrame
class CHAnimIFrame
{
public:
	RtQuat m_qRotation;
	RwV3d  m_vTranslation;
};
// CHAnim
class CHAnim
{
public:
	void         *field_0;
	int           field_4;
	unsigned int  m_uiNumBones;
	int           field_C;
	CBone        *m_pBones;
};
// CAtomicVisibility
class CAtomicVisibility
{
public:
	short          m_sModelId;
	unsigned short m_usFlags;
};
#endif
// RpAtomic
struct RpAtomic
{
    RwObjectHasFrame        object;
    RwResEntry             *repEntry;
    RpGeometry             *geometry;
    RwSphere                boundingSphere;
    RwSphere                worldBoundingSphere;
    RpClump                *clump;
    RwLLLink                inClumpLink;
#ifndef _IDA_EXPORT
    RpAtomicCallBackRender  renderCallBack;
#else
	int                     renderCallBack;
#endif
    RpInterpolator          interpolator;
    unsigned short          renderFrame;
    unsigned short          pad;
    RwLinkList              llWorldSectorsInAtomic;
    RxPipeline             *pipeline;
#ifndef _IDA_EXPORT
	// RenderWare plugins
	char                    worldData[8];
	RpHAnimHierarchy       *animHierarchy;
	// GTA plugins
	CAtomicVisibility       visibility;
	// RenderWare plugins
	unsigned int            matFxEnabled;
	// GTA plugins
	CXEnvMapInfo           *xEnvMapInfo;
	unsigned int            customPipeline;
#endif
};
#ifndef _IDA_EXPORT
// CXEnvMapInfo
class CXEnvMapInfo
{
public:
	float data[3];
};
#endif
// RtAnimInterpolatorInfo
struct RtAnimInterpolatorInfo
{
    int                                 typeID;
    int                                 interpKeyFrameSize;
    int                                 animKeyFrameSize;
#ifndef _IDA_EXPORT
    RtAnimKeyFrameApplyCallBack         keyFrameApplyCB;
    RtAnimKeyFrameBlendCallBack         keyFrameBlendCB;
    RtAnimKeyFrameInterpolateCallBack   keyFrameInterpolateCB;
    RtAnimKeyFrameAddCallBack           keyFrameAddCB;
    RtAnimKeyFrameMulRecipCallBack      keyFrameMulRecipCB;
    RtAnimKeyFrameStreamReadCallBack    keyFrameStreamReadCB;
    RtAnimKeyFrameStreamWriteCallBack   keyFrameStreamWriteCB;
    RtAnimKeyFrameStreamGetSizeCallBack keyFrameStreamGetSizeCB;
#else
	int                                 keyFrameApplyCB;
    int                                 keyFrameBlendCB;
    int                                 keyFrameInterpolateCB;
    int                                 keyFrameAddCB;
    int                                 keyFrameMulRecipCB;
    int                                 keyFrameStreamReadCB;
    int                                 keyFrameStreamWriteCB;
    int                                 keyFrameStreamGetSizeCB;
#endif
    int                                 customDataSize;
};
// RtAnimAnimation
struct RtAnimAnimation
{
    RtAnimInterpolatorInfo *interpInfo;
    int                     numFrames;
    int                     flags;
    float                   duration;
    void                   *pFrames;
    void                   *customData;
};
// RtAnimKeyFrameHeader
struct RtAnimKeyFrameHeader
{
    void  *prevFrame;
    float  time;
};
// RtAnimInterpFrameHeader
struct RtAnimInterpFrameHeader
{
    RtAnimKeyFrameHeader *keyFrame1;
    RtAnimKeyFrameHeader *keyFrame2;
};
// RtAnimInterpolator
struct RtAnimInterpolator
{
    RtAnimAnimation                   *pCurrentAnim;
    float                              currentTime;
    void                              *pNextFrame;
#ifndef _IDA_EXPORT
    RtAnimCallBack                     pAnimCallBack;
#else
	int                                pAnimCallBack;
#endif
    void                              *pAnimCallBackData;
    float                              animCallBackTime;
#ifndef _IDA_EXPORT
    RtAnimCallBack                     pAnimLoopCallBack;
#else
	int                                pAnimLoopCallBack;
#endif
    void                              *pAnimLoopCallBackData;
    int                                maxInterpKeyFrameSize;
    int                                currentInterpKeyFrameSize;
    int                                currentAnimKeyFrameSize;
    int                                numNodes;
    int                                isSubInterpolator;
    int                                offsetInParent;
    RtAnimInterpolator                *parentAnimation;
#ifndef _IDA_EXPORT
    RtAnimKeyFrameApplyCallBack        keyFrameApplyCB;
    RtAnimKeyFrameBlendCallBack        keyFrameBlendCB;
    RtAnimKeyFrameInterpolateCallBack  keyFrameInterpolateCB;
    RtAnimKeyFrameAddCallBack          keyFrameAddCB;
#else
	int                                keyFrameApplyCB;
    int                                keyFrameBlendCB;
    int                                keyFrameInterpolateCB;
    int                                keyFrameAddCB;
#endif
};
// RpHAnimKeyFrame
struct RpHAnimKeyFrame
{
    RpHAnimKeyFrame *prevFrame;
    float            time;
    RtQuat           q;
    RwV3d            t;
};
// RpHAnimInterpFrame
struct RpHAnimInterpFrame
{
    RpHAnimKeyFrame *keyFrame1;
    RpHAnimKeyFrame *keyFrame2;
    RtQuat           q;
    RwV3d            t;
};
// RpHAnimNodeInfo
struct RpHAnimNodeInfo
{
    int      nodeID;
    int      nodeIndex;
    int      flags;
    RwFrame *pFrame;
};
// RpHAnimHierarchy
struct RpHAnimHierarchy
{
    int                 flags;
    int                 numNodes;
    RwMatrix           *pMatrixArray;
    void               *pMatrixArrayUnaligned;
    RpHAnimNodeInfo    *pNodeInfo;
    RwFrame            *parentFrame;
    RpHAnimHierarchy   *parentHierarchy;
    int                 rootParentOffset;
    RtAnimInterpolator *currentAnim;
};
// RpVertexNormal
struct RpVertexNormal
{
    char          x;
    char          y;
    char          z;
    unsigned char pad;
};
// RpWorldSector
struct RpWorldSector
{
    int                 type;
    RpTriangle         *triangles;
    RwV3d              *vertices;
    RpVertexNormal     *normals;
    RwTexCoords        *texCoords[8];
    RwRGBA             *preLitLum;
    RwResEntry         *repEntry;
    RwLinkList          collAtomicsInWorldSector;
    RwLinkList          lightsInWorldSector;
    RwBBox              boundingBox;
    RwBBox              tightBoundingBox;
    RpMeshHeader       *mesh;
    RxPipeline         *pipeline;
    unsigned short      matListWindowBase;
    unsigned short      numVertices;
    unsigned short      numTriangles;
    unsigned short      pad;
};
// RpWorld
struct RpWorld
{
    RwObject                     object;
    unsigned int                 flags;
#ifndef _IDA_EXPORT
    RpWorldRenderOrder           renderOrder;
#else
	int                          renderOrder;
#endif
    RpMaterialList               matList;
    RpSector                    *rootSector;
    int                          numTexCoordSets;
    int                          numClumpsInWorld;
    RwLLLink                    *currentClumpLink;
    RwLinkList                   clumpList;
    RwLinkList                   lightList;
    RwLinkList                   directionalLightList;
    RwV3d                        worldOrigin;
    RwBBox                       boundingBox;
#ifndef _IDA_EXPORT
    RpWorldSectorCallBackRender  renderCallBack;
#else
	int                          renderCallBack;
#endif
    RxPipeline                  *pipeline;
};
// RpSector
struct RpSector
{
    int type;
};

/****************************************Enumerations***************************************/
// RwTextureCoordinateIndex
enum RwTextureCoordinateIndex
{
    rwNARWTEXTURECOORDINATEINDEX = 0,
    rwTEXTURECOORDINATEINDEX0,
    rwTEXTURECOORDINATEINDEX1,
    rwTEXTURECOORDINATEINDEX2,
    rwTEXTURECOORDINATEINDEX3,
    rwTEXTURECOORDINATEINDEX4,
    rwTEXTURECOORDINATEINDEX5,
    rwTEXTURECOORDINATEINDEX6,
    rwTEXTURECOORDINATEINDEX7,
    rwTEXTURECOORDINATEINDEXFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwPlaneType
enum RwPlaneType
{
    rwXPLANE = 0,
    rwYPLANE = 4,
    rwZPLANE = 8,
    rwPLANETYPEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwPluginVendor
enum RwPluginVendor
{
    rwVENDORID_CORE             = 0x000000L,
    rwVENDORID_CRITERIONTK      = 0x000001L,
    rwVENDORID_REDLINERACER     = 0x000002L,
    rwVENDORID_CSLRD            = 0x000003L,
    rwVENDORID_CRITERIONINT     = 0x000004L,
    rwVENDORID_CRITERIONWORLD   = 0x000005L,
    rwVENDORID_BETA             = 0x000006L,
    rwVENDORID_CRITERIONRM      = 0x000007L,
    rwVENDORID_CRITERIONRWA     = 0x000008L,
    rwVENDORID_CRITERIONRWP     = 0x000009L,
    rwPLUGINVENDORFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
#ifndef _IDA_EXPORT
// RwCorePluginID
enum RwCorePluginID
{
    rwID_NAOBJECT               = MAKECHUNKID(rwVENDORID_CORE, 0x00),
    rwID_STRUCT                 = MAKECHUNKID(rwVENDORID_CORE, 0x01),
    rwID_STRING                 = MAKECHUNKID(rwVENDORID_CORE, 0x02),
    rwID_EXTENSION              = MAKECHUNKID(rwVENDORID_CORE, 0x03),
    rwID_CAMERA                 = MAKECHUNKID(rwVENDORID_CORE, 0x05),
    rwID_TEXTURE                = MAKECHUNKID(rwVENDORID_CORE, 0x06),
    rwID_MATERIAL               = MAKECHUNKID(rwVENDORID_CORE, 0x07),
    rwID_MATLIST                = MAKECHUNKID(rwVENDORID_CORE, 0x08),
    rwID_ATOMICSECT             = MAKECHUNKID(rwVENDORID_CORE, 0x09),
    rwID_PLANESECT              = MAKECHUNKID(rwVENDORID_CORE, 0x0A),
    rwID_WORLD                  = MAKECHUNKID(rwVENDORID_CORE, 0x0B),
    rwID_SPLINE                 = MAKECHUNKID(rwVENDORID_CORE, 0x0C),
    rwID_MATRIX                 = MAKECHUNKID(rwVENDORID_CORE, 0x0D),
    rwID_FRAMELIST              = MAKECHUNKID(rwVENDORID_CORE, 0x0E),
    rwID_GEOMETRY               = MAKECHUNKID(rwVENDORID_CORE, 0x0F),
    rwID_CLUMP                  = MAKECHUNKID(rwVENDORID_CORE, 0x10),
    rwID_LIGHT                  = MAKECHUNKID(rwVENDORID_CORE, 0x12),
    rwID_UNICODESTRING          = MAKECHUNKID(rwVENDORID_CORE, 0x13),
    rwID_ATOMIC                 = MAKECHUNKID(rwVENDORID_CORE, 0x14),
    rwID_TEXTURENATIVE          = MAKECHUNKID(rwVENDORID_CORE, 0x15),
    rwID_TEXDICTIONARY          = MAKECHUNKID(rwVENDORID_CORE, 0x16),
    rwID_ANIMDATABASE           = MAKECHUNKID(rwVENDORID_CORE, 0x17),
    rwID_IMAGE                  = MAKECHUNKID(rwVENDORID_CORE, 0x18),
    rwID_SKINANIMATION          = MAKECHUNKID(rwVENDORID_CORE, 0x19),
    rwID_GEOMETRYLIST           = MAKECHUNKID(rwVENDORID_CORE, 0x1A),
    rwID_ANIMANIMATION          = MAKECHUNKID(rwVENDORID_CORE, 0x1B),
    rwID_HANIMANIMATION         = MAKECHUNKID(rwVENDORID_CORE, 0x1B),
    rwID_TEAM                   = MAKECHUNKID(rwVENDORID_CORE, 0x1C),
    rwID_CROWD                  = MAKECHUNKID(rwVENDORID_CORE, 0x1D),
    rwID_DMORPHANIMATION        = MAKECHUNKID(rwVENDORID_CORE, 0x1E),
    rwID_RIGHTTORENDER          = MAKECHUNKID(rwVENDORID_CORE, 0x1f),
    rwID_MTEFFECTNATIVE         = MAKECHUNKID(rwVENDORID_CORE, 0x20),
    rwID_MTEFFECTDICT           = MAKECHUNKID(rwVENDORID_CORE, 0x21),
    rwID_TEAMDICTIONARY         = MAKECHUNKID(rwVENDORID_CORE, 0x22),
    rwID_PITEXDICTIONARY        = MAKECHUNKID(rwVENDORID_CORE, 0x23),
    rwID_TOC                    = MAKECHUNKID(rwVENDORID_CORE, 0x24),
    rwID_PRTSTDGLOBALDATA       = MAKECHUNKID(rwVENDORID_CORE, 0x25),
    rwID_ALTPIPE                = MAKECHUNKID(rwVENDORID_CORE, 0x26),
    rwID_PIPEDS                 = MAKECHUNKID(rwVENDORID_CORE, 0x27),
    rwID_PATCHMESH              = MAKECHUNKID(rwVENDORID_CORE, 0x28),
    rwID_CHUNKGROUPSTART        = MAKECHUNKID(rwVENDORID_CORE, 0x29),
    rwID_CHUNKGROUPEND          = MAKECHUNKID(rwVENDORID_CORE, 0x2A),
    rwID_UVANIMDICT             = MAKECHUNKID(rwVENDORID_CORE, 0x2B),
    rwID_COLLTREE               = MAKECHUNKID(rwVENDORID_CORE, 0x2C),
    rwID_ENVIRONMENT            = MAKECHUNKID(rwVENDORID_CORE, 0x2D),
    rwID_COREPLUGINIDMAX        = MAKECHUNKID(rwVENDORID_CORE, 0x2E),
    rwCOREPLUGINIDFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
#endif
// RwCriterionCoreID
enum RwCriterionCoreID
{
    rwID_NACOREID               = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x00),
    rwID_VECTORMODULE           = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x01),
    rwID_MATRIXMODULE           = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x02),
    rwID_FRAMEMODULE            = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x03),
    rwID_STREAMMODULE           = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x04),
    rwID_CAMERAMODULE           = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x05),
    rwID_IMAGEMODULE            = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x06),
    rwID_RASTERMODULE           = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x07),
    rwID_TEXTUREMODULE          = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x08),
    rwID_PIPEMODULE             = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x09),
    rwID_IMMEDIATEMODULE        = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x0A),
    rwID_RESOURCESMODULE        = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x0B),
    rwID_DEVICEMODULE           = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x0C),
    rwID_COLORMODULE            = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x0D),
    rwID_POLYPIPEMODULE         = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x0E),
    rwID_ERRORMODULE            = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x0F),
    rwID_METRICSMODULE          = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x10),
    rwID_DRIVERMODULE           = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x11),
    rwID_CHUNKGROUPMODULE       = MAKECHUNKID(rwVENDORID_CRITERIONINT, 0x12),
    rwCRITERIONCOREIDFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwPlatformID
enum RwPlatformID
{
    rwID_PCD3D7 = 1,
    rwID_PCOGL,
    rwID_MAC,
    rwID_PS2,
    rwID_XBOX,
    rwID_GAMECUBE,
    rwID_SOFTRAS,
    rwID_PCD3D8,
    rwID_PCD3D9,
    rwPLATFROMIDFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwStreamType
enum RwStreamType
{
    rwNASTREAM = 0,
    rwSTREAMFILE,
    rwSTREAMFILENAME,
    rwSTREAMMEMORY,
    rwSTREAMCUSTOM,
    rwSTREAMTYPEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwStreamAccessType
enum RwStreamAccessType
{
    rwNASTREAMACCESS = 0,
    rwSTREAMREAD,
    rwSTREAMWRITE,
    rwSTREAMAPPEND,
    rwSTREAMACCESSTYPEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwOpCombineType
enum RwOpCombineType
{
    rwCOMBINEREPLACE = 0,
    rwCOMBINEPRECONCAT,
    rwCOMBINEPOSTCONCAT,
    rwOPCOMBINETYPEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwMatrixType
enum RwMatrixType
{
    rwMATRIXTYPENORMAL = 0x00000001,
    rwMATRIXTYPEORTHOGONAL = 0x00000002,
    rwMATRIXTYPEORTHONORMAL = 0x00000003,
    rwMATRIXTYPEMASK = 0x00000003,
    rwMATRIXTYPEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwMatrixFlag
enum RwMatrixFlag
{
    rwMATRIXINTERNALIDENTITY = 0x00020000,
    rwMATRIXFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwMatrixOptimizations
enum RwMatrixOptimizations
{
    rwMATRIXOPTIMIZE_IDENTITY = 0x00020000,
    rwMATRIXOPTIMIZATIONSFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwRenderState
enum RwRenderState
{
    rwRENDERSTATENARENDERSTATE = 0,
    rwRENDERSTATETEXTURERASTER,
    rwRENDERSTATETEXTUREADDRESS,
    rwRENDERSTATETEXTUREADDRESSU,
    rwRENDERSTATETEXTUREADDRESSV,
    rwRENDERSTATETEXTUREPERSPECTIVE,
    rwRENDERSTATEZTESTENABLE,
    rwRENDERSTATESHADEMODE,
    rwRENDERSTATEZWRITEENABLE,
    rwRENDERSTATETEXTUREFILTER,
    rwRENDERSTATESRCBLEND,
    rwRENDERSTATEDESTBLEND,
    rwRENDERSTATEVERTEXALPHAENABLE,
    rwRENDERSTATEBORDERCOLOR,
    rwRENDERSTATEFOGENABLE,
    rwRENDERSTATEFOGCOLOR,
    rwRENDERSTATEFOGTYPE,
    rwRENDERSTATEFOGDENSITY,
    rwRENDERSTATECULLMODE = 20,
    rwRENDERSTATESTENCILENABLE,
    rwRENDERSTATESTENCILFAIL,
    rwRENDERSTATESTENCILZFAIL,
    rwRENDERSTATESTENCILPASS,
    rwRENDERSTATESTENCILFUNCTION,
    rwRENDERSTATESTENCILFUNCTIONREF,
    rwRENDERSTATESTENCILFUNCTIONMASK,
    rwRENDERSTATESTENCILFUNCTIONWRITEMASK,
    rwRENDERSTATEALPHATESTFUNCTION,
    rwRENDERSTATEALPHATESTFUNCTIONREF,
    rwRENDERSTATEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwShadeMode
enum RwShadeMode
{
    rwSHADEMODENASHADEMODE = 0,
    rwSHADEMODEFLAT,
    rwSHADEMODEGOURAUD,
    rwSHADEMODEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwTextureFilterMode
enum RwTextureFilterMode
{
    rwFILTERNAFILTERMODE = 0,
    rwFILTERNEAREST,
    rwFILTERLINEAR,
    rwFILTERMIPNEAREST,
    rwFILTERMIPLINEAR,
    rwFILTERLINEARMIPNEAREST,
    rwFILTERLINEARMIPLINEAR,
    rwTEXTUREFILTERMODEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwFogType
enum RwFogType
{
    rwFOGTYPENAFOGTYPE = 0,
    rwFOGTYPELINEAR,
    rwFOGTYPEEXPONENTIAL,
    rwFOGTYPEEXPONENTIAL2,
    rwFOGTYPEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwBlendFunction
enum RwBlendFunction
{
    rwBLENDNABLEND = 0,
    rwBLENDZERO,
    rwBLENDONE,
    rwBLENDSRCCOLOR,
    rwBLENDINVSRCCOLOR,
    rwBLENDSRCALPHA,
    rwBLENDINVSRCALPHA,
    rwBLENDDESTALPHA,
    rwBLENDINVDESTALPHA,
    rwBLENDDESTCOLOR,
    rwBLENDINVDESTCOLOR,
    rwBLENDSRCALPHASAT,
    rwBLENDFUNCTIONFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwTextureAddressMode
enum RwTextureAddressMode
{
    rwTEXTUREADDRESSNATEXTUREADDRESS = 0,
    rwTEXTUREADDRESSWRAP,
    rwTEXTUREADDRESSMIRROR,
    rwTEXTUREADDRESSCLAMP,
    rwTEXTUREADDRESSBORDER,
    rwTEXTUREADDRESSMODEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwStencilOperation
enum RwStencilOperation
{
    rwSTENCILOPERATIONNASTENCILOPERATION = 0,
    rwSTENCILOPERATIONKEEP,
    rwSTENCILOPERATIONZERO,
    rwSTENCILOPERATIONREPLACE,
    rwSTENCILOPERATIONINCRSAT,
    rwSTENCILOPERATIONDECRSAT,   
    rwSTENCILOPERATIONINVERT,
    rwSTENCILOPERATIONINCR,
    rwSTENCILOPERATIONDECR,
    rwSTENCILOPERATIONFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwStencilFunction
enum RwStencilFunction
{
    rwSTENCILFUNCTIONNASTENCILFUNCTION = 0,
    rwSTENCILFUNCTIONNEVER,
    rwSTENCILFUNCTIONLESS,
    rwSTENCILFUNCTIONEQUAL,
    rwSTENCILFUNCTIONLESSEQUAL,
    rwSTENCILFUNCTIONGREATER,
    rwSTENCILFUNCTIONNOTEQUAL,
    rwSTENCILFUNCTIONGREATEREQUAL,
    rwSTENCILFUNCTIONALWAYS,
    rwSTENCILFUNCTIONFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwAlphaTestFunction
enum RwAlphaTestFunction
{
    rwALPHATESTFUNCTIONNAALPHATESTFUNCTION = 0,
    rwALPHATESTFUNCTIONNEVER,
    rwALPHATESTFUNCTIONLESS,
    rwALPHATESTFUNCTIONEQUAL,
    rwALPHATESTFUNCTIONLESSEQUAL,
    rwALPHATESTFUNCTIONGREATER,
    rwALPHATESTFUNCTIONNOTEQUAL,
    rwALPHATESTFUNCTIONGREATEREQUAL,
    rwALPHATESTFUNCTIONALWAYS,
    rwALPHATESTFUNCTIONFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwCullMode
enum RwCullMode
{
    rwCULLMODENACULLMODE = 0,
    rwCULLMODECULLNONE,
    rwCULLMODECULLBACK,
    rwCULLMODECULLFRONT,
    rwCULLMODEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwPrimitiveType
enum RwPrimitiveType
{
    rwPRIMTYPENAPRIMTYPE = 0,
    rwPRIMTYPELINELIST = 1,
    rwPRIMTYPEPOLYLINE = 2,
    rwPRIMTYPETRILIST = 3,
    rwPRIMTYPETRISTRIP = 4,
    rwPRIMTYPETRIFAN = 5,
    rwPRIMTYPEPOINTLIST = 6,
    rwPRIMITIVETYPEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwEngineStatus
enum RwEngineStatus
{
    rwENGINESTATUSIDLE = 0,
    rwENGINESTATUSINITED = 1,
    rwENGINESTATUSOPENED = 2,
    rwENGINESTATUSSTARTED = 3,
    rwENGINESTATUSFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// rxEmbeddedPacketState
enum rxEmbeddedPacketState
{
    rxPKST_PACKETLESS = 0,
    rxPKST_UNUSED     = 1,
    rxPKST_INUSE      = 2,
    rxPKST_PENDING    = 3,
    rxEMBEDDEDPACKETSTATEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwRasterLockMode
enum RwRasterLockMode
{
    rwRASTERLOCKWRITE = 0x01,
    rwRASTERLOCKREAD = 0x02,
    rwRASTERLOCKNOFETCH = 0x04,
    rwRASTERLOCKRAW = 0x08,
    rwRASTERLOCKMODEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwRasterFlipMode
enum RwRasterFlipMode
{
    rwRASTERFLIPDONTWAIT = 0,
    rwRASTERFLIPWAITVSYNC = 1,
    rwRASTERFLIPMODEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwRasterType
enum RwRasterType
{
    rwRASTERTYPENORMAL = 0x00,
    rwRASTERTYPEZBUFFER = 0x01,
    rwRASTERTYPECAMERA = 0x02,
    rwRASTERTYPETEXTURE = 0x04,
    rwRASTERTYPECAMERATEXTURE = 0x05,
    rwRASTERTYPEMASK = 0x07,
    rwRASTERPALETTEVOLATILE = 0x40,
    rwRASTERDONTALLOCATE = 0x80,
    rwRASTERTYPEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwRasterFormat
enum RwRasterFormat
{
    rwRASTERFORMATDEFAULT = 0x0000,
    rwRASTERFORMAT1555 = 0x0100,
    rwRASTERFORMAT565 = 0x0200,
    rwRASTERFORMAT4444 = 0x0300,
    rwRASTERFORMATLUM8 = 0x0400,
    rwRASTERFORMAT8888 = 0x0500,
    rwRASTERFORMAT888 = 0x0600,
    rwRASTERFORMAT16 = 0x0700,
    rwRASTERFORMAT24 = 0x0800,
    rwRASTERFORMAT32 = 0x0900,
    rwRASTERFORMAT555 = 0x0a00,
    rwRASTERFORMATAUTOMIPMAP = 0x1000,
    rwRASTERFORMATPAL8 = 0x2000,
    rwRASTERFORMATPAL4 = 0x4000,
    rwRASTERFORMATMIPMAP = 0x8000,
    rwRASTERFORMATPIXELFORMATMASK = 0x0f00,
    rwRASTERFORMATMASK = 0xff00,
    rwRASTERFORMATFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwRasterPrivateFlag
enum RwRasterPrivateFlag
{
    rwRASTERGAMMACORRECTED = 0x01,
    rwRASTERPIXELLOCKEDREAD = 0x02,
    rwRASTERPIXELLOCKEDWRITE = 0x04,
    rwRASTERPALETTELOCKEDREAD = 0x08,
    rwRASTERPALETTELOCKEDWRITE = 0x10,
    rwRASTERPIXELLOCKEDRAW = 0x20,
    rwRASTERPRIVATEFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwImageFlag
enum RwImageFlag
{
    rwNAIMAGEFLAG = 0x00,
    rwIMAGEALLOCATED = 0x1,
    rwIMAGEGAMMACORRECTED = 0x2,
    rwIMAGEFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwIm3DTransformFlags
enum RwIm3DTransformFlags
{
    rwIM3D_VERTEXUV      = 1,
    rwIM3D_ALLOPAQUE     = 2,
    rwIM3D_NOCLIP        = 4,
    rwIM3D_VERTEXXYZ     = 8,
    rwIM3D_VERTEXRGBA    = 16,
    rwIM3DTRANSFORMFLAGSFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwCameraClearMode
enum RwCameraClearMode
{
    rwCAMERACLEARIMAGE = 0x1,
    rwCAMERACLEARZ = 0x2,
    rwCAMERACLEARSTENCIL = 0x4,
    rwCAMERACLEARMODEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwCameraProjection
enum RwCameraProjection
{
    rwNACAMERAPROJECTION = 0,
    rwPERSPECTIVE = 1,
    rwPARALLEL = 2,
    rwCAMERAPROJECTIONFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RwFrustumTestResult
enum RwFrustumTestResult
{
    rwSPHEREOUTSIDE = 0,
    rwSPHEREBOUNDARY = 1,
    rwSPHEREINSIDE = 2,
    rwFRUSTUMTESTRESULTFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// rwD3D9VertexShaderEffectType
enum rwD3D9VertexShaderEffectType
{
    rwD3D9VERTEXSHADEREFFECT_NONE = 0,
    rwD3D9VERTEXSHADEREFFECT_BUMPMAP = 1,
    rwD3D9VERTEXSHADEREFFECT_ENVMAP,
    rwD3D9VERTEXSHADEREFFECT_BUMPENVMAP,
    rwD3D9VERTEXSHADEREFFECT_DUAL,
    rwD3D9VERTEXSHADEREFFECT_DUALREPLICATE,
    rwD3D9VERTEXSHADEREFFECT_UVANIM,
    rwD3D9VERTEXSHADEREFFECT_DUALUVANIM,
    rwD3D9VERTEXSHADEREFFECT_NORMALMAP,
    rwD3D9VERTEXSHADEREFFECT_NORMALENVMAP,
    rwD3D9VERTEXSHADEREFFECT_CUBEMAP,
    rwD3D9VERTEXSHADEREFFECT_BUMPCUBEMAP,
    rwD3D9VERTEXSHADEREFFECT_MAX = (1 << 6),
};
// rwD3D9VertexShaderFogMode
enum rwD3D9VertexShaderFogMode
{
    rwD3D9VERTEXSHADERFOG_NONE = 0,
    rwD3D9VERTEXSHADERFOG_LINEAR = 1,
    rwD3D9VERTEXSHADERFOG_EXP,
    rwD3D9VERTEXSHADERFOG_EXP2,
    rwD3D9VERTEXSHADERFOG_MAX
};
// RpMeshHeaderFlags
enum RpMeshHeaderFlags
{
    rpMESHHEADERTRISTRIP  = 0x0001,
    rpMESHHEADERTRIFAN    = 0x0002,
    rpMESHHEADERLINELIST  = 0x0004,
    rpMESHHEADERPOLYLINE  = 0x0008,
    rpMESHHEADERPOINTLIST = 0x0010,
    rpMESHHEADERPRIMMASK  = 0x00FF,
    rpMESHHEADERUNINDEXED = 0x0100,
    rpMESHHEADERFLAGSFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpGeometryFlag
enum RpGeometryFlag
{
    rpGEOMETRYTRISTRIP  = 0x00000001,
    rpGEOMETRYPOSITIONS = 0x00000002,
    rpGEOMETRYTEXTURED  = 0x00000004,
    rpGEOMETRYPRELIT    = 0x00000008,
    rpGEOMETRYNORMALS   = 0x00000010,
    rpGEOMETRYLIGHT     = 0x00000020,
    rpGEOMETRYMODULATEMATERIALCOLOR = 0x00000040,
    rpGEOMETRYTEXTURED2 = 0x00000080,
    rpGEOMETRYNATIVE            = 0x01000000,
    rpGEOMETRYNATIVEINSTANCE    = 0x02000000,
    rpGEOMETRYFLAGSMASK         = 0x000000FF,
    rpGEOMETRYNATIVEFLAGSMASK   = 0x0F000000,
    rpGEOMETRYFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpGeometryLockMode
enum RpGeometryLockMode
{
    rpGEOMETRYLOCKPOLYGONS   =   0x01,
    rpGEOMETRYLOCKVERTICES   =   0x02,
    rpGEOMETRYLOCKNORMALS    =   0x04,
    rpGEOMETRYLOCKPRELIGHT   =   0x08,
    rpGEOMETRYLOCKTEXCOORDS  =   0x10,
    rpGEOMETRYLOCKTEXCOORDS1 =   0x10,
    rpGEOMETRYLOCKTEXCOORDS2 =   0x20,
    rpGEOMETRYLOCKTEXCOORDS3 =   0x40,
    rpGEOMETRYLOCKTEXCOORDS4 =   0x80,
    rpGEOMETRYLOCKTEXCOORDS5 = 0x0100,
    rpGEOMETRYLOCKTEXCOORDS6 = 0x0200,
    rpGEOMETRYLOCKTEXCOORDS7 = 0x0400,
    rpGEOMETRYLOCKTEXCOORDS8 = 0x0800,
    rpGEOMETRYLOCKTEXCOORDSALL = 0x0ff0,
    rpGEOMETRYLOCKALL        = 0x0fff,
    rpGEOMETRYLOCKMODEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpLightType
enum RpLightType
{
    rpNALIGHTTYPE = 0,
    rpLIGHTDIRECTIONAL,
    rpLIGHTAMBIENT,
    rpLIGHTPOINT = rpLIGHTPOSITIONINGSTART,
    rpLIGHTSPOT,
    rpLIGHTSPOTSOFT,
    rpLIGHTTYPEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpLightFlag
enum RpLightFlag
{
    rpLIGHTLIGHTATOMICS = 0x01,
    rpLIGHTLIGHTWORLD = 0x02,
    rpLIGHTFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// rpLightPrivateFlag
enum rpLightPrivateFlag
{
    rpLIGHTPRIVATENOCHROMA = 0x01,
    rpLIGHTPRIVATEFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpInterpolatorFlag
enum RpInterpolatorFlag
{
    rpINTERPOLATORDIRTYINSTANCE = 0x01,
    rpINTERPOLATORDIRTYSPHERE = 0x02,
    rpINTERPOLATORNOFRAMEDIRTY = 0x04,
    rpINTERPOLATORFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpAtomicFlag
enum RpAtomicFlag
{
    rpATOMICCOLLISIONTEST = 0x01,
    rpATOMICRENDER = 0x04,
    rpATOMICFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpAtomicSetGeomFlag
enum RpAtomicSetGeomFlag
{
    rpATOMICSAMEBOUNDINGSPHERE = 0x01,
    rpATOMICSETGEOMFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpAtomicPrivateFlag
enum RpAtomicPrivateFlag
{
    rpATOMICPRIVATEWORLDBOUNDDIRTY = 0x01,
    rpATOMICPRIVATEFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpHAnimHierarchyFlag
enum RpHAnimHierarchyFlag
{
    rpHANIMHIERARCHYSUBHIERARCHY =              0x01,
    rpHANIMHIERARCHYNOMATRICES =                0x02,
    rpHANIMHIERARCHYUPDATEMODELLINGMATRICES = 0x1000,
    rpHANIMHIERARCHYUPDATELTMS =              0x2000,
    rpHANIMHIERARCHYLOCALSPACEMATRICES =      0x4000,
    rpHANIMHIERARCHYFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpMatFXD3D9Pipeline
enum RpMatFXD3D9Pipeline
{
    rpNAMATFXD3D9PIPELINE          = 0,
    rpMATFXD3D9ATOMICPIPELINE      = 1,
    rpMATFXD3D9WORLDSECTORPIPELINE = 2,
    rpMATFXD3D9PIPELINEMAX,
    rpMATFXD3D9PIPELINEFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpMatFXMaterialFlags
enum RpMatFXMaterialFlags
{
    rpMATFXEFFECTNULL            = 0,
    rpMATFXEFFECTBUMPMAP         = 1,
    rpMATFXEFFECTENVMAP          = 2,
    rpMATFXEFFECTBUMPENVMAP      = 3,
    rpMATFXEFFECTDUAL            = 4,
    rpMATFXEFFECTUVTRANSFORM     = 5,
    rpMATFXEFFECTDUALUVTRANSFORM = 6,
    rpMATFXEFFECTMAX,
    rpMATFXNUMEFFECTS       = rpMATFXEFFECTMAX - 1,
    rpMATFXFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpWorldPrivateFlag
enum RpWorldPrivateFlag
{
    rpWORLDSINGLEMALLOC = 0x01,
    rpWORLDPRIVATEFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpWorldFlag
enum RpWorldFlag
{
    rpWORLDTRISTRIP  = 0x01,
    rpWORLDPOSITIONS = 0x02,
    rpWORLDTEXTURED  = 0x04,
    rpWORLDPRELIT    = 0x08,
    rpWORLDNORMALS   = 0x10,
    rpWORLDLIGHT     = 0x20,
    rpWORLDMODULATEMATERIALCOLOR = 0x40, 
    rpWORLDTEXTURED2 = 0x80,
    rpWORLDNATIVE               = 0x01000000,
    rpWORLDNATIVEINSTANCE       = 0x02000000,
    rpWORLDFLAGSMASK            = 0x000000FF,
    rpWORLDNATIVEFLAGSMASK      = 0x0F000000,
    rpWORLDSECTORSOVERLAP       = 0x40000000,
    rpWORLDFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpWorldRenderOrder
enum RpWorldRenderOrder
{
    rpWORLDRENDERNARENDERORDER = 0,
    rpWORLDRENDERFRONT2BACK,
    rpWORLDRENDERBACK2FRONT,
    rpWORLDRENDERORDERFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpD3D9GeometryUsageFlag
enum RpD3D9GeometryUsageFlag
{
    rpD3D9GEOMETRYUSAGE_DYNAMICPOSITIONS  =     0x02,
    rpD3D9GEOMETRYUSAGE_DYNAMICNORMALS    =     0x04,
    rpD3D9GEOMETRYUSAGE_DYNAMICPRELIT     =     0x08,
    rpD3D9GEOMETRYUSAGE_DYNAMICTEXCOORDS  =     0x10,
    rpD3D9GEOMETRYUSAGE_DYNAMICTEXCOORDS1 =     0x10,
    rpD3D9GEOMETRYUSAGE_DYNAMICTEXCOORDS2 =     0x20,
    rpD3D9GEOMETRYUSAGE_DYNAMICTEXCOORDS3 =     0x40,
    rpD3D9GEOMETRYUSAGE_DYNAMICTEXCOORDS4 =     0x80,
    rpD3D9GEOMETRYUSAGE_DYNAMICTEXCOORDS5 =   0x0100,
    rpD3D9GEOMETRYUSAGE_DYNAMICTEXCOORDS6 =   0x0200,
    rpD3D9GEOMETRYUSAGE_DYNAMICTEXCOORDS7 =   0x0400,
    rpD3D9GEOMETRYUSAGE_DYNAMICTEXCOORDS8 =   0x0800,
    rpD3D9GEOMETRYUSAGE_DYNAMICTEXCOORDSALL = 0x0ff0,
    rpD3D9GEOMETRYUSAGE_DYNAMICMASK       =   0x0fff,
    rpD3D9GEOMETRYUSAGE_CREATETANGENTS    =  0x10000,
    rpD3D9GEOMETRYUSAGEFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};
// RpD3D9WorldSectorUsageFlag
enum RpD3D9WorldSectorUsageFlag
{
    rpD3D9WORLDSECTORUSAGE_CREATETANGENTS    =  0x10000,
    rpD3D9WORLDSECTORUSAGEFLAGFORCEENUMSIZEINT = RWFORCEENUMSIZEINT
};

/******************************************Functions****************************************
deleted.

 *******************************************************************************************/
// TEXTURE
#define RwTextureRegisterPlugin(size, pluginId, ctor, dtor, copy) ((int (__cdecl *)(int, int, void *, void *, void *))0x7F3BB0)(size, pluginId, ctor, dtor, copy)
#define RpAnisotPluginAttach() ((signed int (__cdecl *)())0x748F70)()
#define RwStreamFindChunk(stream, type, lengthOut, versionOut) ((int (__cdecl *)(RwStream *, int, int *, int *))0x7ED2D0)(stream, type, lengthOut, versionOut)
#define RwTexDictionaryCreate() ((RwTexDictionary *(__cdecl *)())0x7F3600)()
#define readTextureNative(stream) ((RwTexture *(__cdecl *)(RwStream *))0x730E60)(stream)
#define RwTexDictionaryAddTexture(dict, texture) ((RwTexture *(__cdecl *)(RwTexDictionary *, RwTexture *))0x7F3980)(dict, texture)
#define RwTexDictionaryForAllTextures(dict, callback, data) ((RwTexDictionary *(__cdecl *)(RwTexDictionary *, void *, void *))0x7F3730)(dict, callback, data)
#define RwTexDictionaryDestroy(dict) ((int (__cdecl *)(RwTexDictionary *))0x7F36A0)(dict)
#define RwTexDictionaryFindNamedTexture(dict, name) ((RwTexture *(__cdecl *)(RwTexDictionary *, char *))0x7F39F0)(dict, name)
// STREAM
#define RwStreamReadReal(stream, buffer, length) ((RwStream *(__cdecl *)(RwStream *, void *, unsigned int))0x7ED4F0)(stream, buffer, length)
#define RwStreamRead(stream, space, size) ((int (__cdecl *)(RwStream *, void *, unsigned int))0x7EC9D0)(stream, space, size)
// GEOMETRY
#define RpGeometryCreate(numVerts, numTriangles, format) ((RpGeometry *(__cdecl *)(int, int, unsigned int))0x74CA90)(numVerts, numTriangles, format)
// VECTOR
void RwV3dCrossProduct(RwV3d *out, RwV3d *ina, RwV3d *inb);
void RwV3dCrossProduct(RwV3d *inaout, RwV3d *inb);
float RwV3dNormalize(RwV3d *out, RwV3d *in);
float RwV3dNormalize(RwV3d *inout);
void RwV3dAdd(RwV3d *out, RwV3d *ina, RwV3d *inb);
void RwV3dAdd(RwV3d *inaout, RwV3d *inb);
void RwV3dSub(RwV3d *out, RwV3d *ina, RwV3d *inb);
void RwV3dSub(RwV3d *inaout, RwV3d *inb);
void RwV3dNegate(RwV3d *out, RwV3d *in);
void RwV3dNegate(RwV3d *inout);
// FRAME
#define RwFrameGetLTM(frame) ((RwMatrix *(__cdecl *)(RwFrame *))0x7F0990)(frame)
// GEOMETRY
#define RpGeometryStreamRead(version) ((RpGeometry *(__cdecl *)(unsigned int))0x74D190)(version)
// D3D9
#define rwD3D9EnableClippingIfNeeded(object, type) ((int (__cdecl *)(RpAtomic *, int))0x756D90)(object, type)
#define RwD3D9GetRenderState(state, value) ((int (__cdecl *)(int, void *))0x7FC320)(state, value)
// VEHICLE PIPE RENDER
#define RwD3D9SetTexture(texture, stage) ((int (__cdecl *)(RwTexture *, int))0x7FDE70)(texture, stage)
#define rwD3D9SetRenderState(state, value) ((int (__cdecl *)(int, int))0x7FC2D0)(state, value)
#define rwD3D9SetTextureStageState(stage, type, value) ((int (__cdecl *)(int, int, int))0x7FC340)(stage, type, value)
#define rwD3D9SetIndices(indices) ((int (__cdecl *)(void *))0x7FA1C0)(indices)
#define rwD3D9SetStreams(streams, useOffsets) ((void (__cdecl *)(RxD3D9VertexStream *, int))0x7FA090)(streams, useOffsets)
#define rwD3D9SetVertexDeclaration(vertexDeclaration) ((int  (__cdecl *)(void *))0x7F9F70)(vertexDeclaration)
#define rwD3D9SetLight(index, light) ((int  (__cdecl *)(int, void *))0x7FA660)(index, light)
#define rwD3D9EnableLight(index, enable) ((int  (__cdecl *)(int, int))0x7FA860)(index, enable)
#define rwD3D9SetTransform(state, matrix) ((int (__cdecl *)(int, RwMatrix *))0x7FA390)(state, matrix)
#define rwD3D9RenderStateVertexAlphaEnable(enable) ((signed int (__cdecl *)(int))0x7FE0A0)(enable)
#define rwD3D9SetPixelShader(shader) ((int (__cdecl *)(void *))0x7F9FF0)(shader)
#define rwD3D9SetVertexShader(shader) ((int (__cdecl *)(void *))0x7F9FB0)(shader)
#define rwD3D9DrawIndexedPrimitive(primitiveType, baseVertexIndex, minIndex, numVertices, startIndex, primitiveCount) ((int (__cdecl *)(int, int, int, int, int, int))0x7FA320)(primitiveType, baseVertexIndex, minIndex, numVertices, startIndex, primitiveCount)
#define rwD3D9DrawPrimitive(primitiveType, startVertex, primitiveCount) ((int (__cdecl *)(int, int, int))0x7FA360)(primitiveType, startVertex, primitiveCount)
#define rwD3D9VSSetActiveWorldMatrix(matrix) ((int (__cdecl *)(RwMatrix *))0x764650)(matrix)
#define rwD3D9VSGetComposedTransformMatrix(m_out) ((D3DXMATRIX *(__cdecl *)(D3DXMATRIX *))0x7646E0)(m_out)
// IDLE FUNCS
#define getTimeFromRenderStart() ((DWORD (__cdecl *)())0x561A80)()
#define getTimerDivider() ((int (__cdecl *)())0x561A40)()
#define recalc_time() ((void (__cdecl *)())0x561B10)()
#define sub_727350() ((RwCamera *(__cdecl *)())0x727350)()
#define ResetFontValues() ((void *(__cdecl *)())0x719800)()
#define ProcessGame() ((void (__cdecl *)())0x53BEE0)()
#define sub_507750(audio) ((int (__fastcall *)(void *))0x507750)(audio)
#define UpdateSunLight ((RwFrame *(__cdecl *)())0x7354E0)
#define GetCameraFadeState(camera) ((signed int (__fastcall *)(CCamera *)) 0x50AE20)(camera)
#define SetScreenAspectRatio ((double (__cdecl *)()) 0x6FF420)
#define CameraSize ((void (__cdecl *)(RwCamera *, RwRect *, float, float)) 0x72FC70)
#define sub_7328C0 ((char *(__cdecl *)(RwCamera *)) 0x7328C0)
#define RsCameraBeginUpdate ((signed int (__cdecl *)()) 0x619450)
#define RsMouseSetPos(pos) ((int (__cdecl *)(RwV2d *)) 0x6194A0)(pos)
#define sub_5556E0 ((void (__cdecl *)()) 0x5556E0)
#define PreRenderVehicles ((void (__cdecl *)()) 0x553910)
#define sub_563430 ((char (__cdecl *)()) 0x563430)
#define PrepareCameraForRender ((char (__cdecl *)()) 0x53D7A0)
#define MainModelsRender ((char (__cdecl *)()) 0x53DF40)
#define sub_53E8D0 ((int (__fastcall *)(void *)) 0x53E8D0)
#define DrawScreen ((int (__cdecl *)()) 0x53E230)
#define DrawMenu ((char (__fastcall *)(CMenuManager *)) 0x57C290)
#define DoCameraFade ((unsigned __int8 (__cdecl *)()) 0x53E600)
#define DrawStyledText ((char (__cdecl *)()) 0x58D490)
#define RenderFormattedText ((void (__cdecl *)(char)) 0x69EFC0)
#define RenderFont ((int (__cdecl *)()) 0x71A210)
#define RsCameraShowRaster ((int (__cdecl *)(RwCamera *)) 0x619440)
#define RwCameraClear ((RwCamera *(__cdecl *)(RwCamera *, RwRGBA *, int)) 0x7EE340)
#define RwCameraEndUpdate ((RwCamera *(__cdecl *)(RwCamera *)) 0x7EE180)
#define RwCameraBeginUpdate(camera) ((RwCamera *(__cdecl *)(RwCamera *)) 0x7EE190)(camera)
#define RwCameraSetFarClipPlane(camera, farClip) ((RwCamera *(__cdecl *)(RwCamera *, float)) 0x7EE2A0)(camera, farClip)
#define SetupRenderStates ((int (__cdecl *)()) 0x734650)
void SetRenderState(int, int);
//----------------------------------------------------------------
#define g_Device (*(IDirect3DDevice9 **)0xC97C28)
#define g_DirLight ((RwV3d *)0xB7CB14)
#define g_LastTickTime ((int *) 0xB72CA8)
#define g_GameAudio ((void *)0xB6BC90)
#define g_Camera ((CCamera *)0xB6F028)
#define gtaCamera ((RwCamera **)0xC1703C)
#define g_ViewWindow ((float *) 0x8D5038)
#define g_ScreenAspectRatio ((float *) 0xC3EFA4)
#define g_CamClearColor ((RwRGBA *) 0xB72CA0)
#define g_Menu ((CMenuManager *)0xBA6748)
#define RsGlobal ((RsGlobalType *)0xC17040)
#define bC812CC ((BYTE *) 0xC812CC)
#define fogColor_Red ((WORD *) 0xB7C4CA)
#define fogColor_Green ((WORD *) 0xB7C4CC)
#define fogColor_Blue ((WORD *) 0xB7C4CE)
#define g_Unk ((void *) 0xC88224)
#define g_Flt_B7C4F4 ((float *) 0xB7C4F4)

#ifndef _IDA_EXPORT
class CRenderWare
{
};
#endif

#endif